import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from '../storage';
import { type Message, type User } from '@shared/schema';

interface WebSocketClient extends WebSocket {
  userId?: string;
  username?: string;
  roomId?: string;
  isAlive?: boolean;
}

interface TypingUser {
  userId: string;
  username: string;
  displayName: string;
  timestamp: number;
}

export class WebSocketService {
  private wss: WebSocketServer;
  private clients: Map<string, WebSocketClient> = new Map();
  private roomClients: Map<string, Set<string>> = new Map();
  private typingUsers: Map<string, Map<string, TypingUser>> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ 
      server, 
      path: '/ws',
      verifyClient: (info: any) => {
        // Add authentication verification here if needed
        return true;
      }
    });

    this.setupWebSocketServer();
    this.startHeartbeat();
  }

  private setupWebSocketServer(): void {
    this.wss.on('connection', (ws: WebSocketClient, request) => {
      ws.isAlive = true;
      
      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', async (data: Buffer) => {
        try {
          const message = JSON.parse(data.toString());
          await this.handleMessage(ws, message);
        } catch (error) {
          console.error('WebSocket message error:', error);
          ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
        }
      });

      ws.on('close', () => {
        this.handleDisconnection(ws);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
      });
    });
  }

  private async handleMessage(ws: WebSocketClient, message: any): Promise<void> {
    switch (message.type) {
      case 'auth':
        await this.handleAuth(ws, message);
        break;
      case 'join_room':
        await this.handleJoinRoom(ws, message);
        break;
      case 'leave_room':
        await this.handleLeaveRoom(ws, message);
        break;
      case 'send_message':
        await this.handleSendMessage(ws, message);
        break;
      case 'send_private_message':
        await this.handleSendPrivateMessage(ws, message);
        break;
      case 'typing_start':
        await this.handleTypingStart(ws, message);
        break;
      case 'typing_stop':
        await this.handleTypingStop(ws, message);
        break;
      default:
        ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type' }));
    }
  }

  private async handleAuth(ws: WebSocketClient, message: any): Promise<void> {
    const { userId, username } = message;
    
    if (!userId || !username) {
      ws.send(JSON.stringify({ type: 'error', message: 'Missing authentication data' }));
      return;
    }

    // Verify user exists
    const user = await storage.getUser(userId);
    if (!user) {
      ws.send(JSON.stringify({ type: 'error', message: 'User not found' }));
      return;
    }

    ws.userId = userId;
    ws.username = username;
    this.clients.set(userId, ws);

    // Update user's last active timestamp
    await storage.updateUserLastActive(userId);

    ws.send(JSON.stringify({ type: 'auth_success', message: 'Authenticated successfully' }));
  }

  private async handleJoinRoom(ws: WebSocketClient, message: any): Promise<void> {
    const { roomId } = message;
    
    if (!ws.userId || !roomId) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not authenticated or missing room ID' }));
      return;
    }

    // Verify user is member of the room
    const isMember = await storage.isRoomMember(roomId, ws.userId);
    if (!isMember) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not a member of this room' }));
      return;
    }

    // Leave previous room if any
    if (ws.roomId) {
      await this.handleLeaveRoom(ws, { roomId: ws.roomId });
    }

    ws.roomId = roomId;
    
    if (!this.roomClients.has(roomId)) {
      this.roomClients.set(roomId, new Set());
    }
    this.roomClients.get(roomId)!.add(ws.userId);

    // Get recent messages
    const messages = await storage.getRoomMessages(roomId, 50);
    
    ws.send(JSON.stringify({
      type: 'room_joined',
      roomId,
      messages: messages.reverse() // Show oldest first
    }));

    // Notify other room members
    this.broadcastToRoom(roomId, {
      type: 'user_joined',
      userId: ws.userId,
      username: ws.username
    }, [ws.userId]);
  }

  private async handleLeaveRoom(ws: WebSocketClient, message: any): Promise<void> {
    const { roomId } = message;
    const targetRoomId = roomId || ws.roomId;
    
    if (!targetRoomId || !ws.userId) return;

    if (this.roomClients.has(targetRoomId)) {
      this.roomClients.get(targetRoomId)!.delete(ws.userId);
      
      if (this.roomClients.get(targetRoomId)!.size === 0) {
        this.roomClients.delete(targetRoomId);
      }
    }

    // Clear typing indicator
    await this.handleTypingStop(ws, { roomId: targetRoomId });

    ws.roomId = undefined;

    // Notify other room members
    this.broadcastToRoom(targetRoomId, {
      type: 'user_left',
      userId: ws.userId,
      username: ws.username
    }, [ws.userId]);
  }

  private async handleSendMessage(ws: WebSocketClient, message: any): Promise<void> {
    const { roomId, content, messageType = 'text', fileName, fileSize } = message;
    
    if (!ws.userId || !roomId || !content) {
      ws.send(JSON.stringify({ type: 'error', message: 'Missing required fields' }));
      return;
    }

    // Verify user is member of the room
    const isMember = await storage.isRoomMember(roomId, ws.userId);
    if (!isMember) {
      ws.send(JSON.stringify({ type: 'error', message: 'Not a member of this room' }));
      return;
    }

    // Create message in database
    const newMessage = await storage.createMessage({
      roomId,
      senderId: ws.userId,
      content,
      messageType,
      fileName,
      fileSize,
      isPrivate: false
    });

    // Get sender info
    const sender = await storage.getUser(ws.userId);
    
    const messageData = {
      type: 'new_message',
      message: {
        ...newMessage,
        sender
      }
    };

    // Broadcast to all room members
    this.broadcastToRoom(roomId, messageData);
  }

  private async handleSendPrivateMessage(ws: WebSocketClient, message: any): Promise<void> {
    const { recipientId, content, messageType = 'text', fileName, fileSize } = message;
    
    if (!ws.userId || !recipientId || !content) {
      ws.send(JSON.stringify({ type: 'error', message: 'Missing required fields' }));
      return;
    }

    // Create private message in database
    const newMessage = await storage.createMessage({
      senderId: ws.userId,
      recipientId,
      content,
      messageType,
      fileName,
      fileSize,
      isPrivate: true
    });

    // Get sender info
    const sender = await storage.getUser(ws.userId);
    
    const messageData = {
      type: 'new_private_message',
      message: {
        ...newMessage,
        sender
      }
    };

    // Send to sender
    ws.send(JSON.stringify(messageData));

    // Send to recipient if online
    const recipientWs = this.clients.get(recipientId);
    if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
      recipientWs.send(JSON.stringify(messageData));
    }
  }

  private async handleTypingStart(ws: WebSocketClient, message: any): Promise<void> {
    const { roomId } = message;
    
    if (!ws.userId || !ws.username || !roomId) return;

    const user = await storage.getUser(ws.userId);
    if (!user) return;

    if (!this.typingUsers.has(roomId)) {
      this.typingUsers.set(roomId, new Map());
    }

    this.typingUsers.get(roomId)!.set(ws.userId, {
      userId: ws.userId,
      username: ws.username,
      displayName: user.displayName,
      timestamp: Date.now()
    });

    this.broadcastToRoom(roomId, {
      type: 'typing_start',
      userId: ws.userId,
      username: ws.username,
      displayName: user.displayName
    }, [ws.userId]);

    // Auto-clear typing after 3 seconds
    setTimeout(() => {
      this.handleTypingStop(ws, { roomId });
    }, 3000);
  }

  private async handleTypingStop(ws: WebSocketClient, message: any): Promise<void> {
    const { roomId } = message;
    
    if (!ws.userId || !roomId) return;

    if (this.typingUsers.has(roomId)) {
      const roomTyping = this.typingUsers.get(roomId)!;
      if (roomTyping.has(ws.userId)) {
        roomTyping.delete(ws.userId);
        
        this.broadcastToRoom(roomId, {
          type: 'typing_stop',
          userId: ws.userId
        }, [ws.userId]);
      }
    }
  }

  private broadcastToRoom(roomId: string, data: any, exclude: string[] = []): void {
    if (!this.roomClients.has(roomId)) return;

    const roomUsers = this.roomClients.get(roomId)!;
    
    roomUsers.forEach(userId => {
      if (exclude.includes(userId)) return;
      
      const client = this.clients.get(userId);
      if (client && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  }

  private handleDisconnection(ws: WebSocketClient): void {
    if (ws.userId) {
      this.clients.delete(ws.userId);
      
      if (ws.roomId) {
        this.handleLeaveRoom(ws, { roomId: ws.roomId });
      }
    }
  }

  private startHeartbeat(): void {
    setInterval(() => {
      this.wss.clients.forEach((ws: WebSocketClient) => {
        if (ws.isAlive === false) {
          ws.terminate();
          return;
        }
        
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000); // 30 seconds
  }

  public getConnectedUsers(): number {
    return this.clients.size;
  }

  public getRoomUserCount(roomId: string): number {
    return this.roomClients.get(roomId)?.size || 0;
  }
}

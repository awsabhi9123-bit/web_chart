import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Room, User } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Edit, Trash2, Users, Crown, Search, Hash, Code, Megaphone, Lock, Globe } from 'lucide-react';
import { format } from 'date-fns';

interface RoomWithStats extends Room {
  memberCount: number;
  members: Array<{
    id: string;
    displayName: string;
    username: string;
  }>;
}

export default function RoomManagement() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [privacyFilter, setPrivacyFilter] = useState('all');
  const [editingRoom, setEditingRoom] = useState<RoomWithStats | null>(null);
  const [transferringRoom, setTransferringRoom] = useState<RoomWithStats | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<RoomWithStats | null>(null);
  const [selectedNewOwner, setSelectedNewOwner] = useState('');

  // Form states for editing
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsPrivate, setEditIsPrivate] = useState(false);

  const { data: rooms = [], isLoading } = useQuery({
    queryKey: ['/api/admin/rooms'],
    queryFn: async () => {
      const response = await fetch('/api/admin/rooms', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch rooms');
      return response.json() as Promise<RoomWithStats[]>;
    },
    enabled: !!token
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<User[]>;
    },
    enabled: !!token && !!transferringRoom
  });

  const deleteRoomMutation = useMutation({
    mutationFn: async (roomId: string) => {
      const response = await fetch(`/api/admin/rooms/${roomId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to delete room');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      toast({
        title: "Success",
        description: "Room has been deleted"
      });
      setDeleteConfirm(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete room",
        variant: "destructive"
      });
    }
  });

  const updateRoomMutation = useMutation({
    mutationFn: async ({ roomId, updates }: { roomId: string; updates: any }) => {
      const response = await fetch(`/api/admin/rooms/${roomId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(updates)
      });
      if (!response.ok) throw new Error('Failed to update room');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      toast({
        title: "Success",
        description: "Room has been updated"
      });
      setEditingRoom(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update room",
        variant: "destructive"
      });
    }
  });

  const transferOwnershipMutation = useMutation({
    mutationFn: async ({ roomId, newOwnerId }: { roomId: string; newOwnerId: string }) => {
      const response = await fetch(`/api/admin/rooms/${roomId}/transfer-ownership`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ newOwnerId })
      });
      if (!response.ok) throw new Error('Failed to transfer ownership');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/rooms'] });
      toast({
        title: "Success",
        description: "Room ownership has been transferred"
      });
      setTransferringRoom(null);
      setSelectedNewOwner('');
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to transfer ownership",
        variant: "destructive"
      });
    }
  });

  const filteredRooms = rooms.filter((room) => {
    const matchesSearch = room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          room.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPrivacy = privacyFilter === 'all' || 
                          (privacyFilter === 'private' && room.isPrivate) ||
                          (privacyFilter === 'public' && !room.isPrivate);
    
    return matchesSearch && matchesPrivacy;
  });

  const getRoomIcon = (iconName?: string) => {
    switch (iconName) {
      case 'code':
        return <Code className="h-4 w-4" />;
      case 'bullhorn':
        return <Megaphone className="h-4 w-4" />;
      default:
        return <Hash className="h-4 w-4" />;
    }
  };

  const handleEditRoom = (room: RoomWithStats) => {
    setEditingRoom(room);
    setEditName(room.name);
    setEditDescription(room.description || '');
    setEditIsPrivate(room.isPrivate);
  };

  const handleSaveEdit = () => {
    if (!editingRoom) return;

    updateRoomMutation.mutate({
      roomId: editingRoom.id,
      updates: {
        name: editName,
        description: editDescription,
        isPrivate: editIsPrivate
      }
    });
  };

  const handleTransferOwnership = () => {
    if (!transferringRoom || !selectedNewOwner) return;

    transferOwnershipMutation.mutate({
      roomId: transferringRoom.id,
      newOwnerId: selectedNewOwner
    });
  };

  const getOwnerName = (createdBy: string) => {
    const owner = allUsers.find(user => user.id === createdBy);
    return owner ? owner.displayName : 'Unknown';
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-muted rounded-md"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Room Management</h2>
          <p className="text-muted-foreground">
            Manage all chat rooms in the system
          </p>
        </div>
        <Badge variant="secondary" className="text-sm">
          {filteredRooms.length} rooms
        </Badge>
      </div>

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search rooms..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={privacyFilter} onValueChange={setPrivacyFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Privacy" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Rooms</SelectItem>
            <SelectItem value="public">Public Only</SelectItem>
            <SelectItem value="private">Private Only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Rooms Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Room</TableHead>
              <TableHead>Privacy</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Members</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRooms.map((room) => (
              <TableRow key={room.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-muted rounded-md">
                      {getRoomIcon(room.icon)}
                    </div>
                    <div>
                      <div className="font-medium">{room.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {room.description || 'No description'}
                      </div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={room.isPrivate ? "secondary" : "outline"}>
                    {room.isPrivate ? (
                      <>
                        <Lock className="h-3 w-3 mr-1" />
                        Private
                      </>
                    ) : (
                      <>
                        <Globe className="h-3 w-3 mr-1" />
                        Public
                      </>
                    )}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Crown className="h-4 w-4 text-yellow-500" />
                    {getOwnerName(room.createdBy)}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    {room.memberCount}
                  </div>
                </TableCell>
                <TableCell>
                  {format(new Date(room.createdAt), 'MMM d, yyyy')}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleEditRoom(room)}
                      title="Edit Room"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => setTransferringRoom(room)}
                      title="Transfer Ownership"
                    >
                      <Crown className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => setDeleteConfirm(room)}
                      title="Delete Room"
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Edit Room Dialog */}
      <Dialog open={!!editingRoom} onOpenChange={() => setEditingRoom(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Room</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-name">Room Name</Label>
              <Input
                id="edit-name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Enter room name"
              />
            </div>
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Enter room description"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-private"
                checked={editIsPrivate}
                onCheckedChange={(checked) => setEditIsPrivate(!!checked)}
              />
              <Label htmlFor="edit-private">Private Room</Label>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditingRoom(null)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSaveEdit}
                disabled={updateRoomMutation.isPending}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Transfer Ownership Dialog */}
      <Dialog open={!!transferringRoom} onOpenChange={() => setTransferringRoom(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer Room Ownership</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>
              Transfer ownership of <strong>{transferringRoom?.name}</strong> to:
            </p>
            <Select value={selectedNewOwner} onValueChange={setSelectedNewOwner}>
              <SelectTrigger>
                <SelectValue placeholder="Select new owner" />
              </SelectTrigger>
              <SelectContent>
                {allUsers
                  .filter(user => user.isActive && !user.isBanned)
                  .map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.displayName} (@{user.username})
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setTransferringRoom(null)}>
                Cancel
              </Button>
              <Button 
                onClick={handleTransferOwnership}
                disabled={transferOwnershipMutation.isPending || !selectedNewOwner}
              >
                Transfer Ownership
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Room</AlertDialogTitle>
            <AlertDialogDescription>
              <div className="text-red-600 font-semibold mb-2">⚠️ WARNING: This action cannot be undone!</div>
              Are you sure you want to permanently delete <strong>{deleteConfirm?.name}</strong>?
              <br /><br />
              This will:
              <ul className="list-disc ml-4 mt-2">
                <li>Permanently remove the room and all its messages</li>
                <li>Remove all {deleteConfirm?.memberCount} members from the room</li>
                <li>Delete all associated chat history</li>
              </ul>
              <br />
              <strong>This action cannot be reversed.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteConfirm(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && deleteRoomMutation.mutate(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Permanently Delete Room
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { SystemStats } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, MessageSquare, FileText, Activity } from 'lucide-react';

export default function DashboardTab() {
  const { token } = useAuth();

  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json() as Promise<SystemStats>;
    },
    enabled: !!token,
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h3 className="text-lg font-semibold">System Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-16 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Active Rooms",
      value: stats?.activeRooms || 0,
      icon: MessageSquare,
      color: "text-green-600"
    },
    {
      title: "Messages Today",
      value: stats?.messagesToday || 0,
      icon: MessageSquare,
      color: "text-purple-600"
    },
    {
      title: "Files Uploaded",
      value: stats?.filesUploaded || 0,
      icon: FileText,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="space-y-6" data-testid="admin-dashboard">
      <h3 className="text-lg font-semibold">System Overview</h3>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value.toLocaleString()}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Real-time Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Real-time Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            <div className="flex items-center gap-3 text-sm py-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-muted-foreground">
                {new Date().toLocaleTimeString()}
              </span>
              <span>System monitoring active</span>
            </div>
            {stats?.connectedUsers && (
              <div className="flex items-center gap-3 text-sm py-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-muted-foreground">
                  {new Date().toLocaleTimeString()}
                </span>
                <span>{stats.connectedUsers} users currently online</span>
              </div>
            )}
            <div className="flex items-center gap-3 text-sm py-2 text-muted-foreground">
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
              <span>
                {new Date().toLocaleTimeString()}
              </span>
              <span>Automatic cleanup scheduled for 2:00 AM daily</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketService } from './services/websocket';
import { storage } from "./storage";
import { ldapService } from './services/ldap';
import { cleanupService } from './services/cleanup';
import { upload, uploadAvatar, uploadLogo, getFileUrl } from './services/fileUpload';
import { insertUserSchema, insertRoomSchema, insertMessageSchema, insertLdapConfigSchema, insertAppSettingsSchema } from '@shared/schema';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';

const JWT_SECRET = process.env.SESSION_SECRET || 'your-secret-key';

// Middleware to verify JWT token
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    
    if (!user || !user.isActive || user.isBanned) {
      return res.status(403).json({ message: 'User account is inactive or banned' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
};

// Admin middleware
const requireAdmin = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wsService = new WebSocketService(httpServer);

  // Initialize cleanup service
  cleanupService.startScheduledCleanup();

  // Initialize demo users
  await initializeDemoUsers();

  // Authentication routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password, useLDAP } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }

      let user;
      let authSuccess = false;

      if (useLDAP) {
        // Try LDAP authentication
        const ldapResult = await ldapService.authenticateUser(username, password);
        
        if (ldapResult.success && ldapResult.user) {
          await ldapService.syncUser(ldapResult.user);
          user = await storage.getUserByUsername(username);
          authSuccess = true;
        }
      } else {
        // Local authentication
        user = await storage.getUserByUsername(username);
        
        if (user && await bcrypt.compare(password, user.password)) {
          authSuccess = true;
        }
      }

      if (!authSuccess || !user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      if (!user.isActive || user.isBanned) {
        return res.status(403).json({ message: 'Account is inactive or banned' });
      }

      // Update last active
      await storage.updateUserLastActive(user.id);

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          email: user.email,
          avatar: user.avatar,
          role: user.role,
          department: user.department
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // User routes
  app.get('/api/users/me', authenticateToken, async (req: any, res) => {
    const { password, ...safeUser } = req.user;
    res.json(safeUser);
  });

  app.get('/api/users', authenticateToken, async (req: any, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users.map(u => ({
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        email: u.email,
        avatar: u.avatar,
        role: u.role,
        department: u.department,
        isActive: u.isActive,
        lastActive: u.lastActive
      })));
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  app.post('/api/users', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { username, password, displayName, email, role, department, ldapVerified } = req.body;
      
      // Validate required fields
      if (!username || !password || !displayName) {
        return res.status(400).json({ message: 'Username, password, and display name are required' });
      }
      
      // Validate password strength for manual users
      if (!ldapVerified) {
        if (password.length < 8) {
          return res.status(400).json({ message: 'Password must be at least 8 characters long' });
        }
        
        if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
          return res.status(400).json({ message: 'Password must contain at least one uppercase letter, one lowercase letter, and one number' });
        }
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user data
      const userData = insertUserSchema.parse({
        username: username.trim(),
        password: hashedPassword,
        displayName: displayName.trim(),
        email: email ? email.trim().toLowerCase() : undefined,
        role: role || 'user',
        department: department ? department.trim() : undefined,
        ldapVerified: Boolean(ldapVerified),
        isActive: true,
        isBanned: false
      });
      
      // Create user
      const newUser = await storage.createUser(userData);
      
      // Return user without password
      const { password: _, ...safeUser } = newUser;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error('Create user error:', error);
      res.status(500).json({ message: 'Failed to create user' });
    }
  });

  app.put('/api/users/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }
      
      const user = await storage.updateUser(id, updates);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  app.post('/api/users/:id/ban', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      await storage.banUser(req.params.id);
      res.json({ message: 'User banned successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to ban user' });
    }
  });

  app.post('/api/users/:id/unban', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      await storage.unbanUser(req.params.id);
      res.json({ message: 'User unbanned successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to unban user' });
    }
  });

  app.delete('/api/users/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Prevent admin from deleting themselves
      if (id === req.user.id) {
        return res.status(400).json({ message: 'You cannot delete your own account' });
      }
      
      await storage.deleteUser(id);
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      console.error('Delete user error:', error);
      res.status(500).json({ message: 'Failed to delete user' });
    }
  });

  // Room routes
  app.get('/api/rooms', authenticateToken, async (req: any, res) => {
    try {
      const rooms = await storage.getUserRooms(req.user.id);
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch rooms' });
    }
  });

  app.post('/api/rooms', authenticateToken, async (req: any, res) => {
    try {
      const roomData = insertRoomSchema.parse({ ...req.body, createdBy: req.user.id });
      const room = await storage.createRoom(roomData);
      
      // Add creator as member
      await storage.addRoomMember({ roomId: room.id, userId: req.user.id });
      
      res.json(room);
    } catch (error) {
      res.status(400).json({ message: 'Invalid room data' });
    }
  });

  app.post('/api/rooms/:id/join', authenticateToken, async (req: any, res) => {
    try {
      await storage.addRoomMember({ roomId: req.params.id, userId: req.user.id });
      res.json({ message: 'Joined room successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to join room' });
    }
  });

  app.post('/api/rooms/:id/leave', authenticateToken, async (req: any, res) => {
    try {
      await storage.removeRoomMember(req.params.id, req.user.id);
      res.json({ message: 'Left room successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to leave room' });
    }
  });

  app.get('/api/rooms/:id/members', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Check if user is a member of the room
      const isMember = await storage.isRoomMember(id, req.user.id);
      if (!isMember) {
        return res.status(403).json({ message: 'Not a member of this room' });
      }
      
      const members = await storage.getRoomMembers(id);
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch room members' });
    }
  });

  app.post('/api/rooms/:id/members', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      
      // Check if current user is the room owner
      const room = await storage.getRoom(id);
      if (!room || room.createdBy !== req.user.id) {
        return res.status(403).json({ message: 'Only room owner can add members' });
      }
      
      // Check if user is already a member
      const isAlreadyMember = await storage.isRoomMember(id, userId);
      if (isAlreadyMember) {
        return res.status(400).json({ message: 'User is already a member' });
      }
      
      await storage.addRoomMember({ roomId: id, userId });
      res.json({ message: 'Member added successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to add member' });
    }
  });

  app.delete('/api/rooms/:id/members/:userId', authenticateToken, async (req: any, res) => {
    try {
      const { id, userId } = req.params;
      
      // Check if current user is the room owner
      const room = await storage.getRoom(id);
      if (!room || room.createdBy !== req.user.id) {
        return res.status(403).json({ message: 'Only room owner can remove members' });
      }
      
      // Prevent owner from removing themselves
      if (userId === req.user.id) {
        return res.status(400).json({ message: 'Room owner cannot remove themselves' });
      }
      
      await storage.removeRoomMember(id, userId);
      res.json({ message: 'Member removed successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to remove member' });
    }
  });

  app.patch('/api/rooms/:id/transfer-ownership', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { newOwnerId } = req.body;
      
      // Check if current user is the room owner
      const room = await storage.getRoom(id);
      if (!room || room.createdBy !== req.user.id) {
        return res.status(403).json({ message: 'Only room owner can transfer ownership' });
      }
      
      // Check if new owner is a member of the room
      const isMember = await storage.isRoomMember(id, newOwnerId);
      if (!isMember) {
        return res.status(400).json({ message: 'New owner must be a member of the room' });
      }
      
      // Update room ownership
      await storage.updateRoom(id, { createdBy: newOwnerId });
      res.json({ message: 'Ownership transferred successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to transfer ownership' });
    }
  });

  app.get('/api/rooms/:id/messages', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const isMember = await storage.isRoomMember(id, req.user.id);
      if (!isMember) {
        return res.status(403).json({ message: 'Not a member of this room' });
      }
      
      const messages = await storage.getRoomMessages(id, limit);
      res.json(messages.reverse());
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  // Private message routes
  app.get('/api/private-chats', authenticateToken, async (req: any, res) => {
    try {
      const chats = await storage.getUserPrivateChats(req.user.id);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch private chats' });
    }
  });

  app.get('/api/private-messages/:userId', authenticateToken, async (req: any, res) => {
    try {
      const { userId } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const messages = await storage.getPrivateMessages(req.user.id, userId, limit);
      res.json(messages.reverse());
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch private messages' });
    }
  });

  // Change password for manual users
  app.put('/api/users/change-password', authenticateToken, async (req: any, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      // Validate required fields
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: 'Current password and new password are required' });
      }
      
      // Validate new password strength
      if (newPassword.length < 8) {
        return res.status(400).json({ message: 'New password must be at least 8 characters long' });
      }
      
      if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(newPassword)) {
        return res.status(400).json({ message: 'New password must contain at least one uppercase letter, one lowercase letter, and one number' });
      }
      
      // Get current user
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user is LDAP verified (they can't change password)
      if (user.ldapVerified) {
        return res.status(403).json({ message: 'LDAP users cannot change their password. Contact your system administrator.' });
      }
      
      // Verify current password
      const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
      if (!isCurrentPasswordValid) {
        return res.status(400).json({ message: 'Current password is incorrect' });
      }
      
      // Hash new password
      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      
      // Update password
      await storage.updateUser(req.user.id, { password: hashedNewPassword });
      
      res.json({ message: 'Password changed successfully' });
    } catch (error) {
      console.error('Change password error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // User profile update route (for logged in users to update their own profile)
  app.put('/api/users/profile', authenticateToken, async (req: any, res) => {
    try {
      const { displayName, email, department } = req.body;
      
      // Validate required fields
      if (!displayName || displayName.trim().length === 0) {
        return res.status(400).json({ message: 'Display name is required' });
      }
      
      if (displayName.length > 100) {
        return res.status(400).json({ message: 'Display name must be less than 100 characters' });
      }
      
      // Validate email if provided
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ message: 'Invalid email format' });
      }
      
      // Validate department if provided
      if (department && department.length > 100) {
        return res.status(400).json({ message: 'Department must be less than 100 characters' });
      }
      
      const updates = {
        displayName: displayName.trim(),
        ...(email && { email: email.trim().toLowerCase() }),
        ...(department && { department: department.trim() })
      };
      
      await storage.updateUser(req.user.id, updates);
      
      // Return updated user without sensitive fields
      const updatedUser = await storage.getUser(req.user.id);
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const { password, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update profile' });
    }
  });
  
  // Dedicated avatar update route
  app.put('/api/users/avatar', authenticateToken, uploadAvatar.single('avatar'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No avatar file provided' });
      }
      
      // Server-side validation
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(req.file.mimetype)) {
        return res.status(400).json({ message: 'Only image files (JPEG, PNG, GIF, WebP) are allowed' });
      }
      
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (req.file.size > maxSize) {
        return res.status(400).json({ message: 'File size must be less than 5MB' });
      }
      
      const avatarUrl = getFileUrl(req.file.path);
      await storage.updateUser(req.user.id, { avatar: avatarUrl });
      
      res.json({ avatar: avatarUrl });
    } catch (error) {
      res.status(500).json({ message: 'Avatar upload failed' });
    }
  });

  // File upload routes
  app.post('/api/upload', authenticateToken, upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      res.json({
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        url: getFileUrl(req.file.path)
      });
    } catch (error) {
      res.status(500).json({ message: 'File upload failed' });
    }
  });


  // Search routes
  app.get('/api/search', authenticateToken, async (req: any, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: 'Search query required' });
      }

      const results = await storage.globalSearch(q, req.user.id);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: 'Search failed' });
    }
  });

  // Admin routes
  app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getSystemStats();
      res.json({
        ...stats,
        connectedUsers: wsService.getConnectedUsers()
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch statistics' });
    }
  });

  // Admin room management routes
  app.get('/api/admin/rooms', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const rooms = await storage.getAllRooms();
      // Get room member counts for each room
      const roomsWithStats = await Promise.all(
        rooms.map(async (room) => {
          const members = await storage.getRoomMembers(room.id);
          return {
            ...room,
            memberCount: members.length,
            members: members.map(member => ({
              id: member.id,
              displayName: member.displayName,
              username: member.username
            }))
          };
        })
      );
      res.json(roomsWithStats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch rooms' });
    }
  });

  app.delete('/api/admin/rooms/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteRoom(id);
      res.json({ message: 'Room deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete room' });
    }
  });

  app.put('/api/admin/rooms/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { name, description, isPrivate } = req.body;
      
      const updateData: any = {};
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (isPrivate !== undefined) updateData.isPrivate = isPrivate;
      
      const updatedRoom = await storage.updateRoom(id, updateData);
      res.json(updatedRoom);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update room' });
    }
  });

  app.post('/api/admin/rooms/:id/transfer-ownership', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { newOwnerId } = req.body;
      
      if (!newOwnerId) {
        return res.status(400).json({ message: 'New owner ID is required' });
      }
      
      // Check if new owner exists and is active
      const newOwner = await storage.getUser(newOwnerId);
      if (!newOwner || !newOwner.isActive || newOwner.isBanned) {
        return res.status(400).json({ message: 'New owner must be an active user' });
      }
      
      // Check if new owner is already a room member
      const isMember = await storage.isRoomMember(id, newOwnerId);
      if (!isMember) {
        // Add them as a member first
        await storage.addRoomMember({ roomId: id, userId: newOwnerId });
      }
      
      // Transfer ownership
      await storage.updateRoom(id, { createdBy: newOwnerId });
      res.json({ message: 'Ownership transferred successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to transfer ownership' });
    }
  });

  // Admin message management routes
  app.get('/api/admin/messages', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const search = req.query.search as string;

      let messages;
      if (search && search.trim()) {
        messages = await storage.searchAllMessages(search.trim(), limit);
      } else {
        messages = await storage.getAllMessages(limit, offset);
      }

      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  app.get('/api/admin/messages/stats', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getMessageStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch message statistics' });
    }
  });

  app.delete('/api/admin/messages/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteMessage(id);
      res.json({ message: 'Message deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete message' });
    }
  });

  app.get('/api/admin/cleanup/preview', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const months = parseInt(req.query.months as string) || 3;
      const preview = await cleanupService.getCleanupPreview(months);
      res.json(preview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get cleanup preview' });
    }
  });

  app.post('/api/admin/cleanup', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      if (cleanupService.isCleanupRunning()) {
        return res.status(409).json({ message: 'Cleanup is already in progress' });
      }

      const result = await cleanupService.performAutoCleanup();
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: 'Cleanup failed' });
    }
  });

  // LDAP configuration routes
  app.get('/api/admin/ldap', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const config = await storage.getLdapConfig();
      if (config) {
        // Don't send password in response
        const { bindPassword, ...safeConfig } = config;
        res.json(safeConfig);
      } else {
        res.json(null);
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch LDAP config' });
    }
  });

  app.post('/api/admin/ldap', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const configData = insertLdapConfigSchema.parse(req.body);
      const config = await storage.updateLdapConfig(configData);
      
      // Don't send password in response
      const { bindPassword, ...safeConfig } = config;
      res.json(safeConfig);
    } catch (error) {
      res.status(400).json({ message: 'Invalid LDAP configuration' });
    }
  });

  app.post('/api/admin/ldap/test', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const result = await ldapService.testConnection(req.body);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: 'LDAP test failed' });
    }
  });

  app.post('/api/admin/ldap/sync-users', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const result = await ldapService.syncAllUsers();
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: 'LDAP user sync failed' });
    }
  });

  // App settings routes
  app.get('/api/admin/settings', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch app settings' });
    }
  });

  app.post('/api/admin/settings', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const settingsData = insertAppSettingsSchema.parse(req.body);
      const settings = await storage.updateAppSettings(settingsData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: 'Invalid app settings' });
    }
  });

  app.post('/api/admin/upload/logo', authenticateToken, requireAdmin, uploadLogo.single('logo'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No logo uploaded' });
      }

      const logoUrl = getFileUrl(req.file.path);
      await storage.updateAppSettings({ logoPath: logoUrl });

      res.json({ logoPath: logoUrl });
    } catch (error) {
      res.status(500).json({ message: 'Logo upload failed' });
    }
  });

  // File management routes
  app.get('/api/admin/files/stats', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getFileStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch file statistics' });
    }
  });

  app.get('/api/admin/files', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { search, type, limit, offset } = req.query;
      const files = await storage.getFilesList({
        search: search as string,
        type: type as string,
        limit: parseInt(limit as string) || 50,
        offset: parseInt(offset as string) || 0
      });
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch files' });
    }
  });

  app.delete('/api/admin/files/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const result = await storage.deleteFileAndMessage(id);
      res.json({ message: 'File deleted successfully', result });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete file' });
    }
  });

  // File serving route
  app.get('/api/files/*', (req, res) => {
    const relativePath = (req.params as any)['0'] || '';
    const filePath = path.join(process.cwd(), 'uploads', relativePath);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    res.sendFile(filePath);
  });

  return httpServer;
}

// Initialize demo users
async function initializeDemoUsers() {
  try {
    // Check if admin user exists
    const adminUser = await storage.getUserByUsername('admin');
    
    if (!adminUser) {
      // Create admin user
      const hashedPassword = await bcrypt.hash('admin@!0', 10);
      await storage.createUser({
        username: 'admin',
        password: hashedPassword,
        displayName: 'Administrator',
        email: 'admin@sunchats.local',
        role: 'admin',
        department: 'IT'
      });
      console.log('Admin user created');
    }

    // Create demo users
    const demoUsers = [
      { username: 'user1', password: 'password', displayName: 'John Doe', email: 'john@company.com', department: 'Engineering' },
      { username: 'user2', password: 'password', displayName: 'Sarah Wilson', email: 'sarah@company.com', department: 'Engineering' },
      { username: 'user3', password: 'password', displayName: 'Mike Chen', email: 'mike@company.com', department: 'Engineering' },
      { username: 'user4', password: 'password', displayName: 'Emily Davis', email: 'emily@company.com', department: 'Marketing' }
    ];

    for (const demoUser of demoUsers) {
      const existingUser = await storage.getUserByUsername(demoUser.username);
      if (!existingUser) {
        const hashedPassword = await bcrypt.hash(demoUser.password, 10);
        await storage.createUser({
          username: demoUser.username,
          password: hashedPassword,
          displayName: demoUser.displayName,
          email: demoUser.email,
          role: 'user',
          department: demoUser.department
        });
      }
    }

    // Create default rooms
    const generalRoom = await storage.createRoom({
      name: 'General',
      description: 'General discussions',
      icon: 'hashtag',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    const devRoom = await storage.createRoom({
      name: 'Development',
      description: 'Engineering team discussions',
      icon: 'code',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    const announcementsRoom = await storage.createRoom({
      name: 'Announcements',
      description: 'Company announcements',
      icon: 'bullhorn',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    // Add all users to all rooms as members
    const allUsers = await storage.getAllUsers();
    const rooms = [generalRoom, devRoom, announcementsRoom];
    
    for (const room of rooms) {
      for (const user of allUsers) {
        try {
          // Check if user is already a member to avoid duplicates
          const isMember = await storage.isRoomMember(room.id, user.id);
          if (!isMember) {
            await storage.addRoomMember({
              roomId: room.id,
              userId: user.id
            });
          }
        } catch (error) {
          // Continue if membership already exists
          console.log(`User ${user.username} already member of room ${room.name} or error adding:`, error);
        }
      }
    }

    console.log('Demo data initialized with room memberships');
  } catch (error) {
    console.error('Failed to initialize demo data:', error);
  }
}

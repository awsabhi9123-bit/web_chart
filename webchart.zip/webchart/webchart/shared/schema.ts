import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, serial } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email"),
  avatar: text("avatar"),
  role: text("role").notNull().default("user"), // admin, user
  department: text("department"),
  isActive: boolean("is_active").notNull().default(true),
  isBanned: boolean("is_banned").notNull().default(false),
  ldapVerified: boolean("ldap_verified").notNull().default(false),
  lastActive: timestamp("last_active"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Rooms table
export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon"),
  isPrivate: boolean("is_private").notNull().default(false),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Room members table
export const roomMembers = pgTable("room_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").notNull().references(() => rooms.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  joinedAt: timestamp("joined_at").notNull().default(sql`now()`),
});

// Messages table
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => rooms.id),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  recipientId: varchar("recipient_id").references(() => users.id), // for private messages
  content: text("content"),
  filePath: text("file_path"),
  fileName: text("file_name"),
  fileSize: integer("file_size"),
  messageType: text("message_type").notNull().default("text"), // text, file, system
  isPrivate: boolean("is_private").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Private chats table
export const privateChats = pgTable("private_chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  user1Id: varchar("user1_id").notNull().references(() => users.id),
  user2Id: varchar("user2_id").notNull().references(() => users.id),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// App settings table
export const appSettings = pgTable("app_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  logoPath: text("logo_path"),
  appName: text("app_name").notNull().default("Sun Chats"),
  primaryColor: text("primary_color").notNull().default("#FFEB3B"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// LDAP config table
export const ldapConfig = pgTable("ldap_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serverUrl: text("server_url"),
  port: integer("port").default(389),
  bindDn: text("bind_dn"),
  bindPassword: text("bind_password"),
  baseDn: text("base_dn"),
  searchFilter: text("search_filter").default("(&(objectClass=user)(sAMAccountName={username}))"),
  usernameAttribute: text("username_attribute").default("sAMAccountName"),
  emailAttribute: text("email_attribute").default("mail"),
  displayNameAttribute: text("display_name_attribute").default("displayName"),
  departmentAttribute: text("department_attribute").default("department"),
  sslEnabled: boolean("ssl_enabled").default(false),
  connectionTimeout: integer("connection_timeout").default(5000),
  isEnabled: boolean("is_enabled").default(false),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  sentMessages: many(messages, { relationName: "sender" }),
  receivedMessages: many(messages, { relationName: "recipient" }),
  roomMemberships: many(roomMembers),
  createdRooms: many(rooms),
}));

export const roomsRelations = relations(rooms, ({ one, many }) => ({
  creator: one(users, { fields: [rooms.createdBy], references: [users.id] }),
  members: many(roomMembers),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, { fields: [messages.senderId], references: [users.id], relationName: "sender" }),
  recipient: one(users, { fields: [messages.recipientId], references: [users.id], relationName: "recipient" }),
  room: one(rooms, { fields: [messages.roomId], references: [rooms.id] }),
}));

export const roomMembersRelations = relations(roomMembers, ({ one }) => ({
  room: one(rooms, { fields: [roomMembers.roomId], references: [rooms.id] }),
  user: one(users, { fields: [roomMembers.userId], references: [users.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertRoomMemberSchema = createInsertSchema(roomMembers).omit({ id: true, joinedAt: true });
export const insertPrivateChatSchema = createInsertSchema(privateChats).omit({ id: true, createdAt: true });
export const insertAppSettingsSchema = createInsertSchema(appSettings).omit({ id: true, createdAt: true, updatedAt: true });
export const insertLdapConfigSchema = createInsertSchema(ldapConfig).omit({ id: true, updatedAt: true });

// Types
export type User = typeof users.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type RoomMember = typeof roomMembers.$inferSelect;
export type PrivateChat = typeof privateChats.$inferSelect;
export type AppSettings = typeof appSettings.$inferSelect;
export type LdapConfig = typeof ldapConfig.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertRoomMember = z.infer<typeof insertRoomMemberSchema>;
export type InsertPrivateChat = z.infer<typeof insertPrivateChatSchema>;
export type InsertAppSettings = z.infer<typeof insertAppSettingsSchema>;
export type InsertLdapConfig = z.infer<typeof insertLdapConfigSchema>;

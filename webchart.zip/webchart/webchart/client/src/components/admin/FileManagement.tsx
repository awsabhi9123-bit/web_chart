import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { User, Room } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Search, Download, Trash2, FileText, Image, HardDrive, Users, Calendar, Eye, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

interface FileInfo {
  id: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  messageType: string;
  createdAt: string;
  sender: User;
  recipient: User | null;
  room: Room | null;
  isPrivate: boolean;
}

interface FileStats {
  totalFiles: number;
  totalSize: number;
  imageFiles: number;
  documentFiles: number;
  otherFiles: number;
  todayFiles: number;
}

export default function FileManagement() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [fileTypeFilter, setFileTypeFilter] = useState('all');
  const [deleteConfirm, setDeleteConfirm] = useState<FileInfo | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const filesPerPage = 50;

  // Fetch file statistics
  const { data: fileStats } = useQuery({
    queryKey: ['/api/admin/files/stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/files/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch file statistics');
      return response.json() as Promise<FileStats>;
    },
    enabled: !!token
  });

  // Fetch files
  const { data: files = [], isLoading } = useQuery({
    queryKey: ['/api/admin/files', searchTerm, fileTypeFilter, currentPage],
    queryFn: async () => {
      const params = new URLSearchParams({
        limit: filesPerPage.toString(),
        offset: (currentPage * filesPerPage).toString(),
      });
      
      if (searchTerm) params.append('search', searchTerm);
      if (fileTypeFilter !== 'all') params.append('type', fileTypeFilter);

      const response = await fetch(`/api/admin/files?${params}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch files');
      return response.json() as Promise<FileInfo[]>;
    },
    enabled: !!token
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await fetch(`/api/admin/files/${fileId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to delete file');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/files/stats'] });
      toast({
        title: "File Deleted",
        description: "The file has been permanently deleted"
      });
      setDeleteConfirm(null);
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete the file",
        variant: "destructive"
      });
    }
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileTypeIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    
    if (imageExts.includes(ext || '')) {
      return <Image className="h-4 w-4 text-blue-500" />;
    }
    return <FileText className="h-4 w-4 text-gray-500" />;
  };

  const getFileUrl = (filePath: string) => {
    return `/api/files/${filePath.replace(/^uploads\//, '')}`;
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = !searchTerm || 
      file.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      file.sender.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      file.sender.username.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = fileTypeFilter === 'all' || 
      (fileTypeFilter === 'images' && file.fileName.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)) ||
      (fileTypeFilter === 'documents' && file.fileName.match(/\.(pdf|doc|docx|xls|xlsx|txt)$/i)) ||
      (fileTypeFilter === 'other' && !file.fileName.match(/\.(jpg|jpeg|png|gif|webp|svg|pdf|doc|docx|xls|xlsx|txt)$/i));
    
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      {fileStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Files</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fileStats.totalFiles.toLocaleString()}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Storage</CardTitle>
              <HardDrive className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatFileSize(fileStats.totalSize)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Images</CardTitle>
              <Image className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fileStats.imageFiles.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Uploads</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{fileStats.todayFiles.toLocaleString()}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>File Management</CardTitle>
          <CardDescription>
            Manage and monitor all uploaded files in the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search files, usernames..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <Select value={fileTypeFilter} onValueChange={setFileTypeFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Files</SelectItem>
                <SelectItem value="images">Images</SelectItem>
                <SelectItem value="documents">Documents</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Files Table */}
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">File</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Uploaded By</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell colSpan={6}>
                        <div className="flex items-center space-x-2">
                          <div className="animate-pulse h-4 w-4 bg-muted rounded"></div>
                          <div className="animate-pulse h-4 bg-muted rounded flex-1"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : filteredFiles.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No files found matching your criteria
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFiles.map((file) => (
                    <TableRow key={file.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          {getFileTypeIcon(file.fileName)}
                          <div className="min-w-0">
                            <p className="font-medium truncate">{file.fileName}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{formatFileSize(file.fileSize)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={file.sender.avatar || undefined} />
                            <AvatarFallback className="text-xs">
                              {file.sender.displayName.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{file.sender.displayName}</p>
                            <p className="text-xs text-muted-foreground truncate">@{file.sender.username}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          {file.isPrivate ? (
                            <>
                              <Users className="h-3 w-3 text-blue-500" />
                              <span className="text-sm text-blue-600">Private</span>
                            </>
                          ) : (
                            <>
                              <Badge variant="secondary" className="text-xs">
                                {file.room?.name || 'Unknown Room'}
                              </Badge>
                            </>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-muted-foreground">
                          {format(new Date(file.createdAt), 'MMM dd, yyyy HH:mm')}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            asChild
                          >
                            <a
                              href={getFileUrl(file.filePath)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center space-x-1"
                            >
                              <ExternalLink className="h-3 w-3" />
                              <span className="sr-only">View file</span>
                            </a>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            asChild
                          >
                            <a
                              href={getFileUrl(file.filePath)}
                              download={file.fileName}
                              className="inline-flex items-center space-x-1"
                            >
                              <Download className="h-3 w-3" />
                              <span className="sr-only">Download</span>
                            </a>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDeleteConfirm(file)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-3 w-3" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {filteredFiles.length >= filesPerPage && (
            <div className="flex items-center justify-between mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                disabled={currentPage === 0}
              >
                Previous
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {currentPage + 1}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={filteredFiles.length < filesPerPage}
              >
                Next
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete File</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to permanently delete "{deleteConfirm?.fileName}"? 
              This action cannot be undone and will remove the file from the server and all related messages.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && deleteFileMutation.mutate(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete File
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
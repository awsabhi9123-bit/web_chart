# Sun Chats - Replit Import Status

## Project Overview
Sun Chats is a local, offline-hosted team communication platform with:
- Real-time messaging using WebSockets (Socket.IO)
- LDAP authentication for Active Directory
- Admin panel for user and room management
- File sharing with image previews
- Group chat rooms and private messaging

## Technology Stack
- **Backend**: Node.js with Express (port 3001)
- **Frontend**: React with Vite
- **Database**: SQLite
- **Real-time**: Socket.IO
- **Styling**: Tailwind CSS
- **Authentication**: LDAP integration

## Import Status ✅ COMPLETED

### Completed Setup Tasks:
1. ✅ Extracted project from Qoder_test.zip
2. ✅ Installed Node.js 20 and dependencies
3. ✅ Fixed Tailwind CSS configuration issues
4. ✅ Updated PostCSS configuration (removed @tailwindcss/postcss)
5. ✅ Fixed dark mode CSS classes in index.css
6. ✅ Built frontend successfully
7. ✅ Backend running on port 3001 (serves built frontend)
8. ✅ WebSocket connections working (users connecting/disconnecting)
9. ✅ Workflow configured: "Sun Chats" running `npm run dev`

### Current Configuration:
- **Backend**: http://localhost:3001 (main application entry)
- **Frontend**: Built files served by backend
- **Vite Dev Server**: Configured for port 5000 but currently serving through backend
- **Database**: SQLite (sun_chats.db)

### Application Access:
The application is accessible through the backend server on port 3001, which serves the built React frontend and handles API routes and WebSocket connections.

## Recent Changes:
- **2025-09-24**: Initial import and setup completed
- Fixed Tailwind CSS v4 compatibility issues by downgrading to v3.4.0
- Replaced custom dark mode classes with standard Tailwind classes
- PostCSS configuration updated to use standard tailwindcss plugin

## User Preferences:
- Application configured for Replit environment
- Frontend configured to allow all hosts for proxy compatibility
- WebSocket CORS enabled for development

## Architecture:
- **Monorepo structure**: frontend/ and backend/ directories
- **Development**: Uses concurrently to run both servers
- **Production**: Backend serves built frontend static files
- **Real-time**: Socket.IO for WebSocket communication
- **Authentication**: LDAP integration with admin setup flow
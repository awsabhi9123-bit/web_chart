# Sun Chats

A local, offline-hosted team communication platform with real-time messaging, LDAP authentication, and admin capabilities.

## Features

### Core Functionality
- Real-time messaging using WebSockets
- Group-based chat rooms
- One-on-one private messaging
- File sharing with image previews
- Message history (last 50 messages)
- Typing indicators

### User Management
- LDAP Authentication for Active Directory
- User profiles with display names and avatars
- Role-based access (Admin/User)

### Admin Panel
- LDAP configuration GUI
- User management (activate/deactivate)
- Room management
- Message and file monitoring
- Auto-cleanup of old messages/files
- Custom branding with uploadable logo

### Technical Specifications
- Backend: Node.js with Express
- Frontend: React with Vite
- Database: SQLite
- Real-time: Socket.IO
- Authentication: LDAP integration
- Deployment: Offline, local server

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Build the frontend:
   ```bash
   npm run build
   ```
4. Start the server:
   ```bash
   npm run server
   ```
5. Access the application at http://localhost:3000

## Usage

1. Login with your LDAP credentials
2. Join existing rooms or create new ones
3. Start chatting in real-time
4. Upload files and images
5. Customize your profile

Admin users can access additional features through the Admin Panel, including LDAP configuration, user management, and system cleanup.

## Configuration

### LDAP Setup
Admin users can configure LDAP settings through the Admin Panel:
- LDAP Server URL
- Base DN
- Bind DN
- Bind Password
- User Search Filter
- Group Search Filter

### Branding
Upload a custom logo through the Admin Panel to brand the application.

## Security

- All WebSocket connections are authenticated
- LDAP authentication ensures secure user verification
- User roles control access to admin features
- Messages and files older than 3 months are automatically deleted

## Development

To run in development mode with hot reloading:
```bash
npm run dev
```

This will start both the backend server and frontend development server.

## License

MIT License
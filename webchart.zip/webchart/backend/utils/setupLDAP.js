const { db } = require('../config/database');

// Setup initial LDAP configuration
const setupInitialLDAP = () => {
  return new Promise((resolve, reject) => {
    // Check if LDAP config already exists
    db.get('SELECT * FROM ldap_config WHERE id = 1', (err, existingConfig) => {
      if (err) {
        return reject(err);
      }
      
      if (existingConfig) {
        console.log('LDAP configuration already exists');
        return resolve(existingConfig);
      }
      
      // Insert default LDAP configuration template
      const defaultConfig = {
        server_url: 'ldap://your-ldap-server:389',
        base_dn: 'dc=example,dc=com',
        bind_dn: 'cn=admin,dc=example,dc=com',
        bind_password: 'admin-password',
        user_filter: '(&(objectClass=user)(sAMAccountName={username}))',
        group_filter: '(&(objectClass=group)(member={userdn}))'
      };
      
      const query = `
        INSERT INTO ldap_config 
        (id, server_url, base_dn, bind_dn, bind_password, user_filter, group_filter) 
        VALUES (1, ?, ?, ?, ?, ?, ?)
      `;
      
      const params = [
        defaultConfig.server_url,
        defaultConfig.base_dn,
        defaultConfig.bind_dn,
        defaultConfig.bind_password,
        defaultConfig.user_filter,
        defaultConfig.group_filter
      ];
      
      db.run(query, params, function(err) {
        if (err) {
          return reject(err);
        }
        
        console.log('Initial LDAP configuration created');
        console.log('Please update these settings in the Admin Panel with your actual LDAP configuration');
        resolve({ id: this.lastID, ...defaultConfig });
      });
    });
  });
};

// If run directly, setup initial LDAP config
if (require.main === module) {
  setupInitialLDAP()
    .then(config => {
      console.log('LDAP configuration ready for setup:');
      console.log(`Server URL: ${config.server_url}`);
      console.log(`Base DN: ${config.base_dn}`);
      console.log(`Bind DN: ${config.bind_dn}`);
      console.log('Update these values in the Admin Panel after logging in');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error setting up LDAP configuration:', err.message);
      process.exit(1);
    });
}

module.exports = setupInitialLDAP;
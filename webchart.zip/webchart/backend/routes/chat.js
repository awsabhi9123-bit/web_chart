const express = require('express');
const multer = require('multer');
const path = require('path');
const { db } = require('../config/database');
const router = express.Router();

// Configure file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Get rooms for a user
router.get('/rooms', (req, res) => {
  const userId = req.user.id;
  
  const query = `
    SELECT r.*, COUNT(m.id) as message_count
    FROM rooms r
    JOIN room_members rm ON r.id = rm.room_id
    LEFT JOIN messages m ON r.id = m.room_id
    WHERE rm.user_id = ?
    GROUP BY r.id
  `;
  
  db.all(query, [userId], (err, rooms) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve rooms' });
    }
    res.json(rooms);
  });
});

// Create a new room
router.post('/rooms', (req, res) => {
  const { name, isPrivate } = req.body;
  const userId = req.user.id;
  
  if (!name) {
    return res.status(400).json({ error: 'Room name is required' });
  }
  
  // Insert room
  const insertRoomQuery = `
    INSERT INTO rooms (name, is_private) 
    VALUES (?, ?)
  `;
  
  db.run(insertRoomQuery, [name, isPrivate ? 1 : 0], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to create room' });
    }
    
    const roomId = this.lastID;
    
    // Add creator as room member
    const insertMemberQuery = `
      INSERT INTO room_members (room_id, user_id) 
      VALUES (?, ?)
    `;
    
    db.run(insertMemberQuery, [roomId, userId], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to add user to room' });
      }
      
      res.status(201).json({ 
        id: roomId, 
        name, 
        is_private: isPrivate ? 1 : 0,
        created_at: new Date().toISOString()
      });
    });
  });
});

// Join a room
router.post('/rooms/:roomId/join', (req, res) => {
  const roomId = req.params.roomId;
  const userId = req.user.id;
  
  // Check if room exists
  db.get('SELECT id FROM rooms WHERE id = ?', [roomId], (err, room) => {
    if (err || !room) {
      return res.status(404).json({ error: 'Room not found' });
    }
    
    // Check if already a member
    db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId], (err, membership) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      
      if (membership) {
        return res.status(400).json({ error: 'Already a member of this room' });
      }
      
      // Add user to room
      const query = `
        INSERT INTO room_members (room_id, user_id) 
        VALUES (?, ?)
      `;
      
      db.run(query, [roomId, userId], (err) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to join room' });
        }
        
        res.json({ message: 'Successfully joined room' });
      });
    });
  });
});

// Leave a room
router.post('/rooms/:roomId/leave', (req, res) => {
  const roomId = req.params.roomId;
  const userId = req.user.id;
  
  // Check if room exists
  db.get('SELECT id FROM rooms WHERE id = ?', [roomId], (err, room) => {
    if (err || !room) {
      return res.status(404).json({ error: 'Room not found' });
    }
    
    // Remove user from room
    const query = `
      DELETE FROM room_members 
      WHERE room_id = ? AND user_id = ?
    `;
    
    db.run(query, [roomId, userId], function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to leave room' });
      }
      
      if (this.changes === 0) {
        return res.status(400).json({ error: 'Not a member of this room' });
      }
      
      res.json({ message: 'Successfully left room' });
    });
  });
});

// Get last 50 messages for a room
router.get('/rooms/:roomId/messages', (req, res) => {
  const roomId = req.params.roomId;
  const userId = req.user.id;
  
  // Check if user is member of room
  db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId], (err, membership) => {
    if (err || !membership) {
      return res.status(403).json({ error: 'Not authorized to view this room' });
    }
    
    const query = `
      SELECT m.*, u.username, u.display_name, u.avatar
      FROM messages m
      JOIN users u ON m.user_id = u.id
      WHERE m.room_id = ?
      ORDER BY m.created_at DESC
      LIMIT 50
    `;
    
    db.all(query, [roomId], (err, messages) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to retrieve messages' });
      }
      
      // Reverse to show oldest first
      res.json(messages.reverse());
    });
  });
});

// Send a message to a room
router.post('/rooms/:roomId/messages', upload.single('file'), (req, res) => {
  const roomId = req.params.roomId;
  const userId = req.user.id;
  const { content } = req.body;
  const filePath = req.file ? req.file.path : null;
  
  // Check if user is member of room
  db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId], (err, membership) => {
    if (err || !membership) {
      return res.status(403).json({ error: 'Not authorized to send messages to this room' });
    }
    
    // Insert message
    const query = `
      INSERT INTO messages (room_id, user_id, content, file_path) 
      VALUES (?, ?, ?, ?)
    `;
    
    db.run(query, [roomId, userId, content, filePath], function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to send message' });
      }
      
      const message = {
        id: this.lastID,
        room_id: roomId,
        user_id: userId,
        content: content,
        file_path: filePath,
        created_at: new Date().toISOString()
      };
      
      res.status(201).json(message);
    });
  });
});

// Get users in a room
router.get('/rooms/:roomId/users', (req, res) => {
  const roomId = req.params.roomId;
  const userId = req.user.id;
  
  // Check if user is member of room
  db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId], (err, membership) => {
    if (err || !membership) {
      return res.status(403).json({ error: 'Not authorized to view room members' });
    }
    
    const query = `
      SELECT u.id, u.username, u.display_name, u.avatar, u.role
      FROM users u
      JOIN room_members rm ON u.id = rm.user_id
      WHERE rm.room_id = ?
    `;
    
    db.all(query, [roomId], (err, users) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to retrieve room members' });
      }
      
      res.json(users);
    });
  });
});

module.exports = router;
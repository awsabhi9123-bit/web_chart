const express = require('express');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { authenticateUser, testLdapConnection, saveLdapConfig, getLdapConfig } = require('../services/ldap');
const { db } = require('../config/database');
const router = express.Router();

// Login endpoint
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }
    
    // Authenticate against LDAP
    const ldapUser = await authenticateUser(username, password);
    
    // Check if user exists in our database, create if not
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      
      if (!user) {
        // Create new user
        const insertQuery = `
          INSERT INTO users (username, display_name, role) 
          VALUES (?, ?, 'user')
        `;
        
        db.run(insertQuery, [username, ldapUser.displayName || username], function(err) {
          if (err) {
            return res.status(500).json({ error: 'Failed to create user' });
          }
          
          const newUser = {
            id: this.lastID,
            username: username,
            display_name: ldapUser.displayName || username,
            role: 'user'
          };
          
          // Generate JWT token
          const token = jwt.sign(
            { id: newUser.id, username: newUser.username, role: newUser.role },
            process.env.JWT_SECRET || 'sun_chats_secret',
            { expiresIn: '24h' }
          );
          
          res.json({ 
            token, 
            user: newUser 
          });
        });
      } else {
        // User exists, update last login?
        // Generate JWT token
        const token = jwt.sign(
          { id: user.id, username: user.username, role: user.role },
          process.env.JWT_SECRET || 'sun_chats_secret',
          { expiresIn: '24h' }
        );
        
        res.json({ 
          token, 
          user: {
            id: user.id,
            username: user.username,
            display_name: user.display_name,
            avatar: user.avatar,
            role: user.role
          }
        });
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(401).json({ error: error.message });
  }
});

// Get LDAP configuration (admin only)
router.get('/ldap-config', (req, res) => {
  getLdapConfig()
    .then(config => {
      if (config) {
        // Don't send password to frontend
        const { bind_password, ...safeConfig } = config;
        res.json(safeConfig);
      } else {
        res.json({});
      }
    })
    .catch(err => {
      res.status(500).json({ error: 'Failed to retrieve LDAP configuration' });
    });
});

// Save LDAP configuration (admin only)
router.post('/ldap-config', (req, res) => {
  const config = req.body;
  
  saveLdapConfig(config)
    .then(() => {
      res.json({ message: 'LDAP configuration saved successfully' });
    })
    .catch(err => {
      res.status(500).json({ error: 'Failed to save LDAP configuration' });
    });
});

// Test LDAP connection (admin only)
router.post('/test-ldap', async (req, res) => {
  try {
    await testLdapConnection();
    res.json({ message: 'LDAP connection successful' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
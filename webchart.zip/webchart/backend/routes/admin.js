const express = require('express');
const multer = require('multer');
const path = require('path');
const { db } = require('../config/database');
const { authorizeAdmin } = require('../middleware/auth');
const router = express.Router();

// Configure logo upload
const logoStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/logos/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'logo-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const uploadLogo = multer({ storage: logoStorage });

// Apply admin authorization middleware to all routes
router.use(authorizeAdmin);

// Get all users
router.get('/users', (req, res) => {
  const query = `
    SELECT id, username, display_name, avatar, role, is_active, created_at
    FROM users
    ORDER BY created_at DESC
  `;
  
  db.all(query, [], (err, users) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve users' });
    }
    res.json(users);
  });
});

// Deactivate/ban user
router.post('/users/:userId/deactivate', (req, res) => {
  const userId = req.params.userId;
  
  // Prevent admin from deactivating themselves
  if (parseInt(userId) === req.user.id) {
    return res.status(400).json({ error: 'Cannot deactivate your own account' });
  }
  
  const query = `
    UPDATE users 
    SET is_active = 0 
    WHERE id = ?
  `;
  
  db.run(query, [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to deactivate user' });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ message: 'User deactivated successfully' });
  });
});

// Activate user
router.post('/users/:userId/activate', (req, res) => {
  const userId = req.params.userId;
  
  const query = `
    UPDATE users 
    SET is_active = 1 
    WHERE id = ?
  `;
  
  db.run(query, [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to activate user' });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ message: 'User activated successfully' });
  });
});

// Get all rooms
router.get('/rooms', (req, res) => {
  const query = `
    SELECT r.*, COUNT(rm.id) as member_count
    FROM rooms r
    LEFT JOIN room_members rm ON r.id = rm.room_id
    GROUP BY r.id
    ORDER BY r.created_at DESC
  `;
  
  db.all(query, [], (err, rooms) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve rooms' });
    }
    res.json(rooms);
  });
});

// Delete a room
router.delete('/rooms/:roomId', (req, res) => {
  const roomId = req.params.roomId;
  const fs = require('fs');
  
  // First get file paths from messages in this room
  db.all('SELECT file_path FROM messages WHERE room_id = ? AND file_path IS NOT NULL', [roomId], (err, filesToDelete) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve files for room deletion' });
    }
    
    // Delete room members
    db.run('DELETE FROM room_members WHERE room_id = ?', [roomId], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to delete room members' });
      }
      
      // Delete messages
      db.run('DELETE FROM messages WHERE room_id = ?', [roomId], (err) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to delete room messages' });
        }
        
        // Delete physical files
        let filesDeleted = 0;
        let fileErrors = 0;
        
        if (filesToDelete.length > 0) {
          let processedFiles = 0;
          filesToDelete.forEach((file) => {
            if (file.file_path) {
              fs.unlink(file.file_path, (fsErr) => {
                if (fsErr && fsErr.code !== 'ENOENT') {
                  fileErrors++;
                  console.error('Error deleting file during room deletion:', file.file_path, fsErr);
                } else {
                  filesDeleted++;
                }
                processedFiles++;
                
                if (processedFiles === filesToDelete.length) {
                  deleteRoom();
                }
              });
            } else {
              processedFiles++;
              if (processedFiles === filesToDelete.length) {
                deleteRoom();
              }
            }
          });
        } else {
          deleteRoom();
        }
        
        function deleteRoom() {
          // Finally delete room
          db.run('DELETE FROM rooms WHERE id = ?', [roomId], function(err) {
            if (err) {
              return res.status(500).json({ error: 'Failed to delete room' });
            }
            
            if (this.changes === 0) {
              return res.status(404).json({ error: 'Room not found' });
            }
            
            res.json({ 
              message: 'Room deleted successfully',
              deletedFiles: filesDeleted,
              fileErrors: fileErrors > 0 ? `${fileErrors} files could not be deleted from filesystem` : null
            });
          });
        }
      });
    });
  });
});

// Get message logs
router.get('/messages', (req, res) => {
  const query = `
    SELECT m.*, u.username, u.display_name, r.name as room_name
    FROM messages m
    JOIN users u ON m.user_id = u.id
    JOIN rooms r ON m.room_id = r.id
    ORDER BY m.created_at DESC
    LIMIT 100
  `;
  
  db.all(query, [], (err, messages) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve messages' });
    }
    res.json(messages);
  });
});

// Delete a message
router.delete('/messages/:messageId', (req, res) => {
  const messageId = req.params.messageId;
  const fs = require('fs');
  
  // Get file path before deleting
  db.get('SELECT file_path FROM messages WHERE id = ?', [messageId], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    
    if (!row) {
      return res.status(404).json({ error: 'Message not found' });
    }
    
    const filePath = row.file_path;
    
    // First try to delete the physical file if it exists
    if (filePath) {
      fs.unlink(filePath, (fsErr) => {
        if (fsErr && fsErr.code !== 'ENOENT') {
          // File exists but couldn't be deleted - this is a failure
          console.error('Error deleting physical file:', fsErr);
          return res.status(500).json({ error: 'Failed to delete physical file' });
        }
        
        // File deleted successfully or didn't exist, now delete from database
        deleteFromDatabase();
      });
    } else {
      // No file path, just delete from database
      deleteFromDatabase();
    }
    
    function deleteFromDatabase() {
      db.run('DELETE FROM messages WHERE id = ?', [messageId], function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to delete message record' });
        }
        
        if (this.changes === 0) {
          return res.status(404).json({ error: 'Message not found' });
        }
        
        res.json({ message: 'Message deleted successfully' });
      });
    }
  });
});

// Get uploaded files
router.get('/files', (req, res) => {
  const query = `
    SELECT m.id, m.file_path, m.created_at, u.username, u.display_name, r.name as room_name
    FROM messages m
    JOIN users u ON m.user_id = u.id
    JOIN rooms r ON m.room_id = r.id
    WHERE m.file_path IS NOT NULL
    ORDER BY m.created_at DESC
    LIMIT 100
  `;
  
  db.all(query, [], (err, files) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve files' });
    }
    res.json(files);
  });
});

// Delete a file
router.delete('/files/:messageId', (req, res) => {
  const messageId = req.params.messageId;
  const fs = require('fs');
  
  // Get file path before deleting
  db.get('SELECT file_path FROM messages WHERE id = ?', [messageId], (err, row) => {
    if (err || !row) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    const filePath = row.file_path;
    
    // First try to delete the physical file if it exists
    if (filePath) {
      fs.unlink(filePath, (fsErr) => {
        if (fsErr && fsErr.code !== 'ENOENT') {
          // File exists but couldn't be deleted - this is a failure
          console.error('Error deleting physical file:', fsErr);
          return res.status(500).json({ error: 'Failed to delete physical file' });
        }
        
        // File deleted successfully or didn't exist, now delete from database
        deleteFromDatabase();
      });
    } else {
      // No file path, just delete from database
      deleteFromDatabase();
    }
    
    function deleteFromDatabase() {
      db.run('DELETE FROM messages WHERE id = ?', [messageId], function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to delete file record' });
        }
        
        if (this.changes === 0) {
          return res.status(404).json({ error: 'File not found' });
        }
        
        res.json({ message: 'File deleted successfully' });
      });
    }
  });
});

// Upload app logo
router.post('/logo', uploadLogo.single('logo'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No logo file provided' });
  }
  
  // Save logo path in settings
  const query = `
    INSERT OR REPLACE INTO app_settings (id, logo_path) 
    VALUES (1, ?)
  `;
  
  db.run(query, [req.file.path], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to save logo' });
    }
    
    res.json({ 
      message: 'Logo uploaded successfully',
      logo_path: req.file.path
    });
  });
});

// Get app settings
router.get('/settings', (req, res) => {
  db.get('SELECT * FROM app_settings WHERE id = 1', (err, settings) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve settings' });
    }
    res.json(settings || {});
  });
});

// Auto-cleanup: Delete messages and files older than 3 months
router.post('/cleanup', (req, res) => {
  const fs = require('fs');
  const path = require('path');
  
  // Calculate date 3 months ago
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
  const threeMonthsAgoStr = threeMonthsAgo.toISOString();
  
  // First, get file paths for messages that will be deleted
  db.all('SELECT file_path FROM messages WHERE created_at < ? AND file_path IS NOT NULL', [threeMonthsAgoStr], (err, filesToDelete) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve files for cleanup' });
    }
    
    // Delete old messages from database
    db.run('DELETE FROM messages WHERE created_at < ?', [threeMonthsAgoStr], function(messagesErr) {
      if (messagesErr) {
        return res.status(500).json({ error: 'Failed to delete old messages' });
      }
      
      const deletedMessages = this.changes;
      let filesDeleted = 0;
      let fileErrors = 0;
      
      // Delete physical files
      if (filesToDelete.length > 0) {
        let processedFiles = 0;
        filesToDelete.forEach((file) => {
          if (file.file_path) {
            fs.unlink(file.file_path, (fsErr) => {
              if (fsErr && fsErr.code !== 'ENOENT') {
                fileErrors++;
                console.error('Error deleting file during cleanup:', file.file_path, fsErr);
              } else {
                filesDeleted++;
              }
              processedFiles++;
              
              // Check if all files have been processed
              if (processedFiles === filesToDelete.length) {
                sendResponse();
              }
            });
          } else {
            processedFiles++;
            if (processedFiles === filesToDelete.length) {
              sendResponse();
            }
          }
        });
      } else {
        sendResponse();
      }
      
      function sendResponse() {
        res.json({ 
          message: `Cleanup completed. Deleted ${deletedMessages} messages and ${filesDeleted} files.`,
          deletedMessages,
          deletedFiles: filesDeleted,
          fileErrors: fileErrors > 0 ? `${fileErrors} files could not be deleted from filesystem` : null
        });
      }
    });
  });
});

module.exports = router;
const ldap = require('ldapjs');
const { db } = require('../config/database');

// Get LDAP configuration from database
const getLdapConfig = () => {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM ldap_config WHERE id = 1', (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row);
      }
    });
  });
};

// Test LDAP connection with current configuration
const testLdapConnection = async () => {
  try {
    const config = await getLdapConfig();
    if (!config) {
      throw new Error('LDAP configuration not found');
    }

    // Check if we're in setup mode (using default values)
    if (config.server_url === 'ldap://your-ldap-server:389') {
      console.log('Using default LDAP configuration - skipping connection test');
      return true;
    }

    return new Promise((resolve, reject) => {
      const client = ldap.createClient({
        url: config.server_url
      });

      client.bind(config.bind_dn, config.bind_password, (err) => {
        if (err) {
          client.destroy();
          reject(err);
        } else {
          client.unbind((err) => {
            if (err) {
              console.error('Error unbinding LDAP client:', err);
            }
          });
          resolve(true);
        }
      });
    });
  } catch (error) {
    throw new Error(`LDAP test failed: ${error.message}`);
  }
};

// Authenticate user against LDAP
const authenticateUser = async (username, password) => {
  try {
    const config = await getLdapConfig();
    if (!config) {
      throw new Error('LDAP configuration not found');
    }

    // Check if we're in setup mode (using default values)
    if (config.server_url === 'ldap://your-ldap-server:389') {
      console.log('Using default LDAP configuration - allowing setup access');
      return {
        username: username,
        displayName: username
      };
    }

    return new Promise((resolve, reject) => {
      const client = ldap.createClient({
        url: config.server_url
      });

      // First bind with service account
      client.bind(config.bind_dn, config.bind_password, async (err) => {
        if (err) {
          client.destroy();
          reject(new Error('LDAP service account authentication failed'));
          return;
        }

        // Search for user
        const searchOptions = {
          filter: config.user_filter.replace('{username}', username),
          scope: 'sub',
          attributes: ['dn', 'cn', 'mail']
        };

        client.search(config.base_dn, searchOptions, (err, res) => {
          if (err) {
            client.destroy();
            reject(new Error('LDAP search failed'));
            return;
          }

          let userDn = null;
          
          res.on('searchEntry', (entry) => {
            userDn = entry.object.dn;
          });

          res.on('error', (err) => {
            client.destroy();
            reject(new Error('LDAP search error'));
          });

          res.on('end', () => {
            if (!userDn) {
              client.destroy();
              reject(new Error('User not found'));
              return;
            }

            // Try to bind with user credentials
            client.bind(userDn, password, (err) => {
              client.destroy();
              if (err) {
                reject(new Error('Invalid credentials'));
              } else {
                resolve({
                  username: username,
                  displayName: username // In a real implementation, this would come from LDAP attributes
                });
              }
            });
          });
        });
      });
    });
  } catch (error) {
    throw new Error(`LDAP authentication failed: ${error.message}`);
  }
};

// Save LDAP configuration
const saveLdapConfig = (config) => {
  return new Promise((resolve, reject) => {
    const query = `
      INSERT OR REPLACE INTO ldap_config 
      (id, server_url, base_dn, bind_dn, bind_password, user_filter, group_filter) 
      VALUES (1, ?, ?, ?, ?, ?, ?)
    `;
    
    const params = [
      config.server_url,
      config.base_dn,
      config.bind_dn,
      config.bind_password,
      config.user_filter,
      config.group_filter
    ];
    
    db.run(query, params, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this.lastID);
      }
    });
  });
};

module.exports = {
  testLdapConnection,
  authenticateUser,
  saveLdapConfig,
  getLdapConfig
};
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Create database connection
const db = new sqlite3.Database(path.join(__dirname, '../../sun_chats.db'), (err) => {
  if (err) {
    console.error('Error opening database:', err.message);
  } else {
    console.log('Connected to SQLite database');
  }
});

// Initialize database tables
const initialize = () => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT,
    avatar TEXT,
    role TEXT DEFAULT 'user',
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Rooms table
  db.run(`CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    icon TEXT,
    is_private BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Room members table
  db.run(`CREATE TABLE IF NOT EXISTS room_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER,
    user_id INTEGER,
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms (id),
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Messages table
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER,
    user_id INTEGER,
    content TEXT,
    file_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms (id),
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // LDAP configuration table
  db.run(`CREATE TABLE IF NOT EXISTS ldap_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_url TEXT,
    base_dn TEXT,
    bind_dn TEXT,
    bind_password TEXT,
    user_filter TEXT,
    group_filter TEXT
  )`);

  // App settings table
  db.run(`CREATE TABLE IF NOT EXISTS app_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    logo_path TEXT,
    theme TEXT DEFAULT 'light-yellow'
  )`);

  console.log('Database tables initialized');
  
  // Initialize default rooms and admin user
  initializeDefaultData();
};

const initializeDefaultData = () => {
  // Create default admin user if it doesn't exist
  db.get('SELECT id FROM users WHERE username = ?', ['admin'], (err, row) => {
    if (err) {
      console.error('Error checking for admin user:', err);
      return;
    }
    
    if (!row) {
      db.run('INSERT INTO users (username, display_name, role) VALUES (?, ?, ?)', 
        ['admin', 'Administrator', 'admin'], function(err) {
        if (err) {
          console.error('Error creating admin user:', err);
        } else {
          console.log('Default admin user created');
          ensureDefaultRooms(this.lastID);
        }
      });
    } else {
      // Admin exists, ensure default rooms
      ensureDefaultRooms(row.id);
    }
  });
};

const ensureDefaultRooms = (adminUserId) => {
  const defaultRooms = [
    { name: 'General', is_private: 0 },
    { name: 'Development', is_private: 0 },
    { name: 'Random', is_private: 0 }
  ];
  
  defaultRooms.forEach(room => {
    db.get('SELECT id FROM rooms WHERE name = ?', [room.name], (err, existingRoom) => {
      if (err) {
        console.error('Error checking for room:', err);
        return;
      }
      
      if (!existingRoom) {
        // Create room
        db.run('INSERT INTO rooms (name, is_private) VALUES (?, ?)', 
          [room.name, room.is_private], function(err) {
          if (err) {
            console.error('Error creating room:', err);
          } else {
            console.log(`Default room '${room.name}' created`);
            // Add admin to room
            db.run('INSERT INTO room_members (room_id, user_id) VALUES (?, ?)', 
              [this.lastID, adminUserId], (err) => {
              if (err) {
                console.error('Error adding admin to room:', err);
              }
            });
          }
        });
      } else {
        // Room exists, ensure admin is a member
        db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', 
          [existingRoom.id, adminUserId], (err, membership) => {
          if (err) {
            console.error('Error checking room membership:', err);
            return;
          }
          
          if (!membership) {
            db.run('INSERT INTO room_members (room_id, user_id) VALUES (?, ?)', 
              [existingRoom.id, adminUserId], (err) => {
              if (err) {
                console.error('Error adding admin to existing room:', err);
              }
            });
          }
        });
      }
    });
  });
};

module.exports = {
  db,
  initialize
};
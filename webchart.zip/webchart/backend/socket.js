const { db } = require('./config/database');

// Store connected users
const connectedUsers = new Map();

const initializeSocket = (io) => {
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    
    // Authenticate socket connection
    socket.on('authenticate', (token) => {
      // In a real implementation, you would verify the JWT token here
      // For simplicity, we'll just accept any token for now
      socket.userId = token; // Store user ID in socket
      connectedUsers.set(token, socket.id);
      socket.emit('authenticated');
    });
    
    // Join a room
    socket.on('joinRoom', (roomId) => {
      if (!socket.userId) {
        socket.emit('error', 'Not authenticated');
        return;
      }
      
      // Check if user is member of room
      db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', 
        [roomId, socket.userId], (err, membership) => {
        if (err || !membership) {
          socket.emit('error', 'Not authorized to join this room');
          return;
        }
        
        socket.join(roomId);
        socket.currentRoom = roomId;
        
        // Notify others in room that user joined
        socket.to(roomId).emit('userJoined', {
          userId: socket.userId,
          message: 'User joined the room'
        });
      });
    });
    
    // Leave a room
    socket.on('leaveRoom', (roomId) => {
      if (!socket.userId) {
        socket.emit('error', 'Not authenticated');
        return;
      }
      
      socket.leave(roomId);
      
      // Notify others in room that user left
      socket.to(roomId).emit('userLeft', {
        userId: socket.userId,
        message: 'User left the room'
      });
      
      if (socket.currentRoom === roomId) {
        delete socket.currentRoom;
      }
    });
    
    // Send message
    socket.on('sendMessage', (data) => {
      if (!socket.userId || !socket.currentRoom) {
        socket.emit('error', 'Not authenticated or not in a room');
        return;
      }
      
      const { content, roomId } = data;
      
      if (socket.currentRoom !== roomId) {
        socket.emit('error', 'Not in this room');
        return;
      }
      
      // Check if user is member of room
      db.get('SELECT id FROM room_members WHERE room_id = ? AND user_id = ?', 
        [roomId, socket.userId], (err, membership) => {
        if (err || !membership) {
          socket.emit('error', 'Not authorized to send messages to this room');
          return;
        }
        
        // Save message to database
        const query = `
          INSERT INTO messages (room_id, user_id, content) 
          VALUES (?, ?, ?)
        `;
        
        db.run(query, [roomId, socket.userId, content], function(err) {
          if (err) {
            socket.emit('error', 'Failed to send message');
            return;
          }
          
          // Get user info for the message
          db.get('SELECT username, display_name, avatar FROM users WHERE id = ?', 
            [socket.userId], (err, user) => {
            if (err || !user) {
              socket.emit('error', 'Failed to get user info');
              return;
            }
            
            const message = {
              id: this.lastID,
              room_id: roomId,
              user_id: socket.userId,
              content: content,
              created_at: new Date().toISOString(),
              username: user.username,
              display_name: user.display_name,
              avatar: user.avatar
            };
            
            // Broadcast message to all users in room
            io.to(roomId).emit('newMessage', message);
          });
        });
      });
    });
    
    // Typing indicator
    socket.on('typing', (data) => {
      if (!socket.userId || !socket.currentRoom) {
        return;
      }
      
      const { roomId, isTyping } = data;
      
      if (socket.currentRoom !== roomId) {
        return;
      }
      
      // Get user info
      db.get('SELECT display_name FROM users WHERE id = ?', 
        [socket.userId], (err, user) => {
        if (!err && user) {
          // Broadcast typing status to all users in room except sender
          socket.to(roomId).emit('userTyping', {
            userId: socket.userId,
            username: user.display_name,
            isTyping: isTyping
          });
        }
      });
    });
    
    // Disconnect
    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
      
      // Remove user from connected users
      for (let [userId, socketId] of connectedUsers.entries()) {
        if (socketId === socket.id) {
          connectedUsers.delete(userId);
          break;
        }
      }
      
      // Notify room if user was in one
      if (socket.currentRoom) {
        socket.to(socket.currentRoom).emit('userLeft', {
          userId: socket.userId,
          message: 'User disconnected'
        });
      }
    });
  });
};

module.exports = {
  initializeSocket,
  connectedUsers
};
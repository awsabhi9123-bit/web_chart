import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import io from 'socket.io-client';
import api from '../services/api';

const ChatRoom = ({ socket, currentRoom, rooms }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [users, setUsers] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { roomId } = useParams();
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  
  const actualRoomId = roomId || currentRoom;
  
  // Find the current room name
  const currentRoomData = rooms.find(room => room.id == actualRoomId);
  const roomName = currentRoomData ? currentRoomData.name : 'Select a room';
  
  useEffect(() => {
    if (!actualRoomId) return;
    
    // Load messages
    loadMessages();
    
    // Load users in room
    loadUsers();
    
    // Join room via socket
    if (socket) {
      socket.emit('joinRoom', actualRoomId);
      
      // Listen for new messages
      socket.on('newMessage', (message) => {
        setMessages(prev => [...prev, message]);
      });
      
      // Listen for typing indicators
      socket.on('userTyping', (data) => {
        if (data.isTyping) {
          setTypingUsers(prev => {
            if (!prev.includes(data.username)) {
              return [...prev, data.username];
            }
            return prev;
          });
        } else {
          setTypingUsers(prev => prev.filter(user => user !== data.username));
        }
      });
      
      // Listen for user join/leave
      socket.on('userJoined', (data) => {
        // Reload users when someone joins
        loadUsers();
      });
      
      socket.on('userLeft', (data) => {
        // Reload users when someone leaves
        loadUsers();
      });
    }
    
    return () => {
      if (socket) {
        socket.emit('leaveRoom', actualRoomId);
        socket.off('newMessage');
        socket.off('userTyping');
        socket.off('userJoined');
        socket.off('userLeft');
      }
    };
  }, [actualRoomId, socket]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const loadMessages = async () => {
    if (!actualRoomId) return;
    
    try {
      setIsLoading(true);
      const response = await api.get(`/chat/rooms/${actualRoomId}/messages`);
      setMessages(response.data);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const loadUsers = async () => {
    if (!actualRoomId) return;
    
    try {
      const response = await api.get(`/chat/rooms/${actualRoomId}/users`);
      setUsers(response.data);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };
  
  const sendMessage = () => {
    if (!newMessage.trim() || !socket || !actualRoomId) return;
    
    socket.emit('sendMessage', {
      content: newMessage,
      roomId: actualRoomId
    });
    
    setNewMessage('');
    setIsTyping(false);
    
    // Focus input after sending
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };
  
  const handleTyping = () => {
    if (!isTyping && socket && actualRoomId) {
      setIsTyping(true);
      socket.emit('typing', {
        roomId: actualRoomId,
        isTyping: true
      });
      
      // Reset typing status after delay
      setTimeout(() => {
        setIsTyping(false);
        socket.emit('typing', {
          roomId: actualRoomId,
          isTyping: false
        });
      }, 1000);
    }
  };
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage();
  };
  
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  
  if (!actualRoomId) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center p-8 max-w-md">
          <div className="mx-auto bg-yellow-100 dark:bg-yellow-900 rounded-full w-24 h-24 flex items-center justify-center mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-xl text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Welcome to Sun Chats</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Select a room from the sidebar to start chatting with your team.
          </p>
          <div className="bg-yellow-50 dark:bg-yellow-900 rounded-lg p-4">
            <h3 className="font-medium text-gray-900 dark:text-white mb-2">Getting Started</h3>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="icon-xs mr-2 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
                Join existing rooms or create new ones
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="icon-xs mr-2 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
                Send messages in real-time
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="icon-xs mr-2 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
                Share files with your team
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="chat-container">
      <div className="chat-header">
        <div className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {roomName}
          </h2>
          <span className="ml-2 badge badge-secondary">
            {users.length} {users.length === 1 ? 'user' : 'users'}
          </span>
        </div>
        <div className="flex items-center">
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
            </svg>
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </div>
      </div>
      
      <div className="chat-messages">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <svg className="animate-spin icon-lg text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className="flex fade-in">
                {message.avatar ? (
                  <img src={message.avatar} alt="Avatar" className="avatar" />
                ) : (
                  <div className="avatar">
                    <span className="text-xs font-medium">
                      {message.display_name?.charAt(0) || message.username?.charAt(0) || 'U'}
                    </span>
                  </div>
                )}
                <div className="ml-3">
                  <div className="flex items-baseline">
                    <span className="font-medium text-gray-900 dark:text-white">
                      {message.display_name || message.username}
                    </span>
                    <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
                      {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="message-bubble received mt-1">
                    <p className="text-gray-700 dark:text-gray-300">
                      {message.content}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>
      
      {typingUsers.length > 0 && (
        <div className="px-4 py-2 text-sm text-gray-500 dark:text-gray-400 bg-white dark:bg-dark-mode-card border-t border-gray-200 dark:border-dark-mode-border flex items-center">
          <svg className="animate-pulse icon-sm mr-2" fill="none" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="3" fill="currentColor" />
          </svg>
          {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
        </div>
      )}
      
      <div className="chat-input-container">
        <form onSubmit={handleSubmit} className="flex items-end">
          <div className="flex-1 mr-2">
            <textarea
              ref={inputRef}
              rows="1"
              value={newMessage}
              onChange={(e) => {
                setNewMessage(e.target.value);
                handleTyping();
              }}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              className="textarea resize-none"
            />
          </div>
          <button
            type="submit"
            className="btn btn-primary h-10 flex items-center justify-center"
            disabled={!newMessage.trim()}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </form>
        <div className="flex mt-2 space-x-2">
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
            </svg>
          </button>
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;
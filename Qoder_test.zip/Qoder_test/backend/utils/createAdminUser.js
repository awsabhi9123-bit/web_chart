const { db } = require('../config/database');
const jwt = require('jsonwebtoken');

// Create an admin user
const createAdminUser = (username, displayName) => {
  return new Promise((resolve, reject) => {
    // Check if user already exists
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, existingUser) => {
      if (err) {
        return reject(err);
      }
      
      if (existingUser) {
        // Update existing user to admin
        db.run('UPDATE users SET role = ?, display_name = ? WHERE username = ?', 
          ['admin', displayName, username], function(err) {
          if (err) {
            return reject(err);
          }
          
          // Generate a temporary token for testing
          const token = jwt.sign(
            { id: existingUser.id, username: username, role: 'admin' },
            process.env.JWT_SECRET || 'sun_chats_secret',
            { expiresIn: '24h' }
          );
          
          console.log(`User ${username} updated to admin role`);
          console.log(`Temporary login token: ${token}`);
          resolve({ id: existingUser.id, username, role: 'admin', token });
        });
      } else {
        // Create new admin user
        db.run('INSERT INTO users (username, display_name, role) VALUES (?, ?, ?)', 
          [username, displayName, 'admin'], function(err) {
          if (err) {
            return reject(err);
          }
          
          const userId = this.lastID;
          
          // Generate a temporary token for testing
          const token = jwt.sign(
            { id: userId, username: username, role: 'admin' },
            process.env.JWT_SECRET || 'sun_chats_secret',
            { expiresIn: '24h' }
          );
          
          console.log(`Admin user ${username} created successfully`);
          console.log(`Temporary login token: ${token}`);
          resolve({ id: userId, username, role: 'admin', token });
        });
      }
    });
  });
};

// If run directly, create an admin user
if (require.main === module) {
  const username = process.argv[2] || 'admin';
  const displayName = process.argv[3] || 'Administrator';
  
  createAdminUser(username, displayName)
    .then(user => {
      console.log('Admin user created/updated successfully:');
      console.log(`ID: ${user.id}`);
      console.log(`Username: ${user.username}`);
      console.log(`Role: ${user.role}`);
      console.log('You can use this token for testing (valid for 24 hours):');
      console.log(user.token);
      process.exit(0);
    })
    .catch(err => {
      console.error('Error creating admin user:', err.message);
      process.exit(1);
    });
}

module.exports = createAdminUser;
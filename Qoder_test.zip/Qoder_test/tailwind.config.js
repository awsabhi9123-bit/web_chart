/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./frontend/index.html",
    "./frontend/src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'sun-yellow': '#FFD700',
        'sun-yellow-light': '#FFFACD',
        'sun-yellow-dark': '#DAA520',
      }
    },
  },
  plugins: [],
  darkMode: 'class',
}
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const Sidebar = ({ rooms, currentRoom, setCurrentRoom, loadRooms, onLogout, isLoading }) => {
  const [roomName, setRoomName] = useState('');
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const handleCreateRoom = async (e) => {
    e.preventDefault();
    if (!roomName.trim()) return;
    
    try {
      await api.post('/chat/rooms', { name: roomName });
      setRoomName('');
      setShowCreateRoom(false);
      loadRooms();
    } catch (error) {
      console.error('Error creating room:', error);
    }
  };
  
  const handleJoinRoom = async (roomId) => {
    try {
      await api.post(`/chat/rooms/${roomId}/join`);
      setCurrentRoom(roomId);
      loadRooms();
      navigate(`/chat/room/${roomId}`);
    } catch (error) {
      console.error('Error joining room:', error);
    }
  };
  
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-yellow-500 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-md mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            Sun Chats
          </h1>
          <button 
            onClick={() => setShowCreateRoom(!showCreateRoom)}
            className="text-yellow-500 hover:text-yellow-600 p-1 rounded-full hover:bg-yellow-100 dark:hover:bg-yellow-900"
            title="Create Room"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
        <div className="flex items-center mt-4">
          {user.avatar ? (
            <img src={user.avatar} alt="Avatar" className="avatar" />
          ) : (
            <div className="avatar">
              <span className="font-medium">
                {user.display_name?.charAt(0) || user.username?.charAt(0) || 'U'}
              </span>
            </div>
          )}
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900 dark:text-white">
              {user.display_name || user.username}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center">
              <span className={`inline-block w-2 h-2 rounded-full mr-1 ${user.role === 'admin' ? 'bg-green-500' : 'bg-gray-400'}`}></span>
              {user.role === 'admin' ? 'Administrator' : 'User'}
            </p>
          </div>
        </div>
      </div>
      
      <div className="sidebar-content">
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Rooms</h2>
            {isLoading && (
              <svg className="animate-spin icon-sm text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            )}
          </div>
          
          {showCreateRoom && (
            <form onSubmit={handleCreateRoom} className="mb-4">
              <div className="form-group mb-2">
                <input
                  type="text"
                  value={roomName}
                  onChange={(e) => setRoomName(e.target.value)}
                  placeholder="Room name"
                  className="input text-sm"
                  autoFocus
                />
              </div>
              <div className="flex space-x-2">
                <button type="submit" className="btn btn-primary btn-sm flex-1">
                  Create
                </button>
                <button 
                  type="button" 
                  className="btn btn-secondary btn-sm"
                  onClick={() => setShowCreateRoom(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
          
          <ul className="space-y-1">
            {rooms.map((room) => (
              <li key={room.id}>
                <button
                  onClick={() => handleJoinRoom(room.id)}
                  className={`room-item ${currentRoom === room.id ? 'active' : ''}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                  </svg>
                  <span className="room-name truncate">{room.name}</span>
                  {room.message_count > 0 && (
                    <span className="ml-auto badge badge-primary">
                      {room.message_count}
                    </span>
                  )}
                </button>
              </li>
            ))}
            
            {rooms.length === 0 && !isLoading && (
              <li className="text-center py-4 text-gray-500 dark:text-gray-400 text-sm">
                <p>No rooms available</p>
                <p className="mt-1">Create a new room to get started</p>
              </li>
            )}
          </ul>
        </div>
      </div>
      
      <div className="sidebar-footer">
        <Link 
          to="/chat/profile" 
          className="room-item mb-1"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          <span>Profile</span>
        </Link>
        {user.role === 'admin' && (
          <Link 
            to="/admin" 
            className="room-item mb-1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span>Admin Panel</span>
          </Link>
        )}
        <button
          onClick={onLogout}
          className="room-item"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
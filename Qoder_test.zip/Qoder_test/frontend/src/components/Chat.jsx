import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import ChatRoom from './ChatRoom';
import Profile from './Profile';
import io from 'socket.io-client';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const Chat = () => {
  const [rooms, setRooms] = useState([]);
  const [currentRoom, setCurrentRoom] = useState(null);
  const [socket, setSocket] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    // Initialize socket connection
    const newSocket = io();
    newSocket.emit('authenticate', user.id);
    setSocket(newSocket);
    
    // Load user rooms
    loadRooms();
    
    return () => {
      newSocket.close();
    };
  }, [user]);
  
  const loadRooms = async () => {
    try {
      setIsLoading(true);
      const response = await api.get('/chat/rooms');
      setRooms(response.data);
    } catch (error) {
      console.error('Error loading rooms:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar 
        rooms={rooms} 
        currentRoom={currentRoom} 
        setCurrentRoom={setCurrentRoom} 
        loadRooms={loadRooms}
        onLogout={handleLogout}
        isLoading={isLoading}
      />
      
      <div className="flex-1 flex flex-col">
        <Routes>
          <Route 
            path="/" 
            element={<ChatRoom socket={socket} currentRoom={currentRoom} rooms={rooms} />} 
          />
          <Route path="/room/:roomId" element={<ChatRoom socket={socket} rooms={rooms} />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </div>
    </div>
  );
};

export default Chat;
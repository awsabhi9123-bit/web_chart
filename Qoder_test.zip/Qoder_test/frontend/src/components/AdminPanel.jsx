import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('ldap');
  const [users, setUsers] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [messages, setMessages] = useState([]);
  const [files, setFiles] = useState([]);
  const [ldapConfig, setLdapConfig] = useState({
    server_url: '',
    base_dn: '',
    bind_dn: '',
    bind_password: '',
    user_filter: '',
    group_filter: ''
  });
  const [logo, setLogo] = useState(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const navigate = useNavigate();
  
  useEffect(() => {
    loadLdapConfig();
  }, []);
  
  const loadLdapConfig = async () => {
    try {
      const response = await api.get('/auth/ldap-config');
      setLdapConfig(response.data);
    } catch (error) {
      console.error('Error loading LDAP config:', error);
    }
  };
  
  const handleLdapConfigChange = (e) => {
    setLdapConfig({
      ...ldapConfig,
      [e.target.name]: e.target.value
    });
  };
  
  const saveLdapConfig = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    setMessageType('');
    
    try {
      await api.post('/auth/ldap-config', ldapConfig);
      setMessage('LDAP configuration saved successfully');
      setMessageType('success');
    } catch (error) {
      setMessage('Error saving LDAP configuration: ' + error.response?.data?.error || error.message);
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };
  
  const testLdapConnection = async () => {
    setLoading(true);
    setMessage('');
    setMessageType('');
    
    try {
      await api.post('/auth/test-ldap');
      setMessage('LDAP connection successful');
      setMessageType('success');
    } catch (error) {
      setMessage('LDAP connection failed: ' + error.response?.data?.error || error.message);
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };
  
  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setLogo(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };
  
  const uploadLogo = async (e) => {
    e.preventDefault();
    if (!logo) return;
    
    setLoading(true);
    setMessage('');
    setMessageType('');
    
    try {
      const formData = new FormData();
      formData.append('logo', logo);
      
      await api.post('/admin/logo', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      setMessage('Logo uploaded successfully');
      setMessageType('success');
    } catch (error) {
      setMessage('Error uploading logo: ' + error.response?.data?.error || error.message);
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };
  
  const runCleanup = async () => {
    if (!window.confirm('Are you sure you want to delete messages and files older than 3 months? This action cannot be undone.')) {
      return;
    }
    
    setLoading(true);
    setMessage('');
    setMessageType('');
    
    try {
      const response = await api.post('/admin/cleanup');
      setMessage(response.data.message);
      setMessageType('success');
    } catch (error) {
      setMessage('Error running cleanup: ' + error.response?.data?.error || error.message);
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="flex-1 bg-gray-50 dark:bg-gray-900">
      <div className="border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-dark-mode-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
              <p className="text-gray-600 dark:text-gray-400">Manage your Sun Chats installation</p>
            </div>
            <button
              onClick={() => navigate('/chat')}
              className="btn btn-secondary flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Chat
            </button>
          </div>
          <nav className="tabs">
            <button
              onClick={() => setActiveTab('ldap')}
              className={`tab ${activeTab === 'ldap' ? 'active' : ''}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
              LDAP Configuration
            </button>
            <button
              onClick={() => setActiveTab('branding')}
              className={`tab ${activeTab === 'branding' ? 'active' : ''}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
              </svg>
              Branding
            </button>
            <button
              onClick={() => setActiveTab('cleanup')}
              className={`tab ${activeTab === 'cleanup' ? 'active' : ''}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Cleanup
            </button>
          </nav>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {message && (
          <div className={`alert alert-${messageType} fade-in`}>
            <div className="flex items-center">
              {messageType === 'success' ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              )}
              <span>{message}</span>
            </div>
          </div>
        )}
        
        {activeTab === 'ldap' && (
          <div className="card">
            <div className="card-header">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">LDAP Configuration</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Configure LDAP settings for user authentication
              </p>
            </div>
            <div className="card-body">
              <form onSubmit={saveLdapConfig}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="form-group sm:col-span-2">
                    <label htmlFor="server_url" className="form-label">
                      LDAP Server URL
                    </label>
                    <input
                      type="text"
                      id="server_url"
                      name="server_url"
                      value={ldapConfig.server_url || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="ldap://ldap.example.com:389"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The URL of your LDAP server (e.g., ldap://server:389 or ldaps://server:636)
                    </p>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="base_dn" className="form-label">
                      Base DN
                    </label>
                    <input
                      type="text"
                      id="base_dn"
                      name="base_dn"
                      value={ldapConfig.base_dn || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="dc=example,dc=com"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The base distinguished name for LDAP searches
                    </p>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="bind_dn" className="form-label">
                      Bind DN
                    </label>
                    <input
                      type="text"
                      id="bind_dn"
                      name="bind_dn"
                      value={ldapConfig.bind_dn || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="cn=admin,dc=example,dc=com"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The distinguished name used to bind to the LDAP server
                    </p>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="bind_password" className="form-label">
                      Bind Password
                    </label>
                    <input
                      type="password"
                      id="bind_password"
                      name="bind_password"
                      value={ldapConfig.bind_password || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="Enter bind password"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The password for the bind DN account
                    </p>
                  </div>
                  
                  <div className="form-group sm:col-span-2">
                    <label htmlFor="user_filter" className="form-label">
                      User Search Filter
                    </label>
                    <input
                      type="text"
                      id="user_filter"
                      name="user_filter"
                      value={ldapConfig.user_filter || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="(&(objectClass=user)(sAMAccountName={username}))"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The filter used to search for users. Use {username} as a placeholder for the username.
                    </p>
                  </div>
                  
                  <div className="form-group sm:col-span-2">
                    <label htmlFor="group_filter" className="form-label">
                      Group Search Filter
                    </label>
                    <input
                      type="text"
                      id="group_filter"
                      name="group_filter"
                      value={ldapConfig.group_filter || ''}
                      onChange={handleLdapConfigChange}
                      className="input"
                      placeholder="(&(objectClass=group)(member={userdn}))"
                    />
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      The filter used to search for groups. Use {userdn} as a placeholder for the user's DN.
                    </p>
                  </div>
                </div>
                
                <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4">
                  <button
                    type="button"
                    onClick={testLdapConnection}
                    className="btn btn-secondary flex items-center justify-center"
                    disabled={loading}
                  >
                    {loading ? (
                      <svg className="animate-spin -ml-1 mr-2 icon-sm" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                    )}
                    Test Connection
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary flex items-center justify-center"
                    disabled={loading}
                  >
                    {loading ? (
                      <svg className="animate-spin -ml-1 mr-2 icon-sm" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                      </svg>
                    )}
                    Save Configuration
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        
        {activeTab === 'branding' && (
          <div className="card">
            <div className="card-header">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">App Branding</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Customize the appearance of your Sun Chats installation
              </p>
            </div>
            <div className="card-body">
              <form onSubmit={uploadLogo}>
                <div className="form-group">
                  <label className="form-label">
                    App Logo
                  </label>
                  <div className="flex items-center space-x-6">
                    <div className="flex-shrink-0">
                      {logoPreview ? (
                        <img src={logoPreview} alt="Logo preview" className="w-16 h-16 object-contain" />
                      ) : (
                        <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="icon-lg text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <input
                        type="file"
                        id="logo"
                        accept="image/*"
                        onChange={handleLogoChange}
                        className="block w-full text-sm text-gray-500
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-lg file:border-0
                          file:text-sm file:font-medium
                          file:bg-yellow-50 file:text-yellow-700
                          hover:file:bg-yellow-100
                          dark:file:bg-yellow-900 dark:file:text-yellow-200
                          dark:hover:file:bg-yellow-800"
                      />
                      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                        JPG, PNG, or GIF up to 2MB
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="btn btn-primary flex items-center"
                    disabled={loading || !logo}
                  >
                    {loading ? (
                      <svg className="animate-spin -ml-1 mr-2 icon-sm" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                    )}
                    Upload Logo
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        
        {activeTab === 'cleanup' && (
          <div className="card">
            <div className="card-header">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">Auto Cleanup</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Manage automatic cleanup of old messages and files
              </p>
            </div>
            <div className="card-body">
              <div className="bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 mb-6">
                <div className="flex">
                  <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm text-yellow-500 flex-shrink-0 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-200">Automatic Cleanup Policy</h3>
                    <div className="mt-2 text-sm text-yellow-700 dark:text-yellow-300">
                      <p>
                        Messages and files older than 3 months are automatically deleted to preserve storage space and maintain performance.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Manual Cleanup</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Run cleanup now to immediately delete messages and files older than 3 months.
                </p>
                <button
                  onClick={runCleanup}
                  className="btn btn-danger flex items-center"
                  disabled={loading}
                >
                  {loading ? (
                    <svg className="animate-spin -ml-1 mr-2 icon-sm" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  )}
                  Run Cleanup Now
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

const Profile = () => {
  const { user, login } = useAuth();
  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [avatar, setAvatar] = useState(null);
  const [preview, setPreview] = useState(user?.avatar || '');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  
  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatar(file);
      setPreview(URL.createObjectURL(file));
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    setMessageType('');
    
    try {
      // In a real implementation, you would upload the avatar and update the user
      // For now, we'll just update the display name
      
      // Update user in localStorage to reflect changes
      const updatedUser = { ...user, display_name: displayName };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      login(localStorage.getItem('token'), updatedUser);
      
      setMessage('Profile updated successfully');
      setMessageType('success');
    } catch (error) {
      setMessage('Error updating profile');
      setMessageType('error');
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="flex-1 bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Profile Settings</h1>
          <p className="text-gray-600 dark:text-gray-400">Manage your profile information and preferences</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="card">
              <div className="card-body">
                <div className="flex flex-col items-center">
                  <div className="relative">
                    {preview ? (
                      <img src={preview} alt="Avatar" className="avatar-xl" />
                    ) : (
                      <div className="avatar-xl bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <span className="text-2xl font-medium text-gray-700 dark:text-gray-300">
                          {user?.display_name?.charAt(0) || user?.username?.charAt(0) || 'U'}
                        </span>
                      </div>
                    )}
                    <label 
                      htmlFor="avatar-upload" 
                      className="absolute bottom-0 right-0 bg-yellow-400 rounded-full p-2 cursor-pointer hover:bg-yellow-500 transition-colors"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm text-gray-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </label>
                    <input
                      type="file"
                      id="avatar-upload"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      className="hidden"
                    />
                  </div>
                  <h2 className="text-xl font-semibold mt-4 text-gray-900 dark:text-white">
                    {user?.display_name || user?.username}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    {user?.username}
                  </p>
                  <div className="mt-2 flex items-center">
                    <span className={`inline-block w-3 h-3 rounded-full mr-2 ${user?.role === 'admin' ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {user?.role === 'admin' ? 'Administrator' : 'User'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <div className="card">
              <div className="card-header">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">Profile Information</h2>
              </div>
              <div className="card-body">
                {message && (
                  <div className={`alert alert-${messageType}`}>
                    <div className="flex items-center">
                      {messageType === 'success' ? (
                        <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="icon-sm mr-2" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                        </svg>
                      )}
                      <span>{message}</span>
                    </div>
                  </div>
                )}
                
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="displayName" className="form-label">
                      Display Name
                    </label>
                    <input
                      type="text"
                      id="displayName"
                      className="input"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Enter your display name"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Username
                    </label>
                    <input
                      type="text"
                      className="input bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
                      value={user?.username || ''}
                      disabled
                    />
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Role
                    </label>
                    <input
                      type="text"
                      className="input bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
                      value={user?.role === 'admin' ? 'Administrator' : 'User'}
                      disabled
                    />
                  </div>
                  
                  <div className="form-group">
                    <label className="form-label">
                      Member Since
                    </label>
                    <input
                      type="text"
                      className="input bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
                      value={user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'Unknown'}
                      disabled
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="btn btn-primary flex items-center"
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 icon-sm text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Saving...
                        </>
                      ) : (
                        'Save Changes'
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
            
            <div className="card mt-6">
              <div className="card-header">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">Security</h2>
              </div>
              <div className="card-body">
                <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white">Password</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Password is managed through your LDAP provider
                    </p>
                  </div>
                  <button className="btn btn-secondary" disabled>
                    Change Password
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Chat from './components/Chat';
import AdminPanel from './components/AdminPanel';
import { AuthProvider, useAuth } from './contexts/AuthContext';

const App = () => {
  const [theme, setTheme] = useState('light-yellow');
  
  useEffect(() => {
    // Apply theme class to body
    document.body.className = theme;
    if (theme === 'dark') {
      document.body.classList.add('dark-mode');
    }
  }, [theme]);
  
  return (
    <AuthProvider>
      <Router>
        <div className={`min-h-screen ${theme.includes('light') ? 'light-yellow-theme' : ''}`}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/chat/*" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            <Route path="/admin/*" element={<ProtectedAdminRoute><AdminPanel /></ProtectedAdminRoute>} />
            <Route path="/" element={<Navigate to="/chat" replace />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
};

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  return user ? children : <Navigate to="/login" replace />;
};

const ProtectedAdminRoute = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  return user && user.role === 'admin' ? children : <Navigate to="/chat" replace />;
};

export default App;
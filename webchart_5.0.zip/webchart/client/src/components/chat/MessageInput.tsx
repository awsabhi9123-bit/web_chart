import { useState, useRef, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Paperclip, Send, X, File } from 'lucide-react';

interface MessageInputProps {
  roomId?: string;
  userId?: string;
  isPrivateChat: boolean;
  webSocket: any;
}

export default function MessageInput({ roomId, userId, isPrivateChat, webSocket }: MessageInputProps) {
  const { token } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        handleSendMessage();
      } else if (!e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    }
  }, [message, selectedFile]);

  const handleInputChange = useCallback((value: string) => {
    setMessage(value);
    
    // Handle typing indicators
    if (webSocket.isConnected && !isPrivateChat) {
      webSocket.startTyping();
      
      // Clear previous timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // Stop typing after 1 second of inactivity
      typingTimeoutRef.current = setTimeout(() => {
        webSocket.stopTyping();
      }, 1000);
    }
  }, [webSocket, isPrivateChat]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "File size must be less than 10MB",
          variant: "destructive"
        });
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const removeSelectedFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const uploadFile = async (file: File): Promise<{ filename: string; originalName: string; size: number; url: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', userId || roomId || '');

    const response = await fetch('/api/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('File upload failed');
    }

    return response.json();
  };

  const handleSendMessage = async () => {
    const trimmedMessage = message.trim();
    
    if (!trimmedMessage && !selectedFile) return;
    
    if (!webSocket.isConnected) {
      toast({
        title: "Connection Error",
        description: "Not connected to chat server",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);

    try {
      let fileData = null;
      
      if (selectedFile) {
        fileData = await uploadFile(selectedFile);
      }

      // Send message via WebSocket
      if (isPrivateChat && userId) {
        webSocket.sendPrivateMessage(
          userId,
          fileData ? fileData.originalName : trimmedMessage,
          fileData ? 'file' : 'text',
          fileData?.originalName,
          fileData?.size
        );
      } else if (roomId) {
        webSocket.sendMessage(
          fileData ? fileData.originalName : trimmedMessage,
          fileData ? 'file' : 'text',
          fileData?.originalName,
          fileData?.size
        );
      }

      // Clear input
      setMessage('');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      // Stop typing indicator
      if (!isPrivateChat) {
        webSocket.stopTyping();
      }

      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }

    } catch (error) {
      toast({
        title: "Send Failed",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Auto-resize textarea
  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 128) + 'px';
    handleInputChange(textarea.value);
  };

  return (
    <div className="px-6 py-4 border-t border-border bg-card" data-testid="message-input">
      {/* File Upload Preview */}
      {selectedFile && (
        <div className="mb-3 p-3 bg-muted rounded-lg flex items-center gap-3">
          <File className="h-4 w-4 text-primary" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{selectedFile.name}</p>
            <p className="text-xs text-muted-foreground">
              {Math.round(selectedFile.size / 1024)} KB
            </p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6"
            onClick={removeSelectedFile}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      <div className="flex items-end gap-3">
        {/* File Upload Button */}
        <div className="relative">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-10 w-10"
            title="Upload File"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            data-testid="button-upload-file"
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          <Input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileSelect}
            accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.txt"
          />
        </div>

        {/* Message Input */}
        <div className="flex-1">
          <Textarea
            ref={textareaRef}
            placeholder="Type a message..."
            value={message}
            onChange={handleTextareaInput}
            onKeyDown={handleKeyDown}
            disabled={isUploading}
            className="min-h-[44px] max-h-32 resize-none"
            data-testid="textarea-message"
          />
        </div>

        {/* Send Button */}
        <Button
          onClick={handleSendMessage}
          disabled={(!message.trim() && !selectedFile) || isUploading || !webSocket.isConnected}
          className="h-10 px-4"
          data-testid="button-send-message"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

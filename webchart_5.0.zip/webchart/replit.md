# Sun Chats - Team Communication Platform

## Overview

Sun Chats is a local, offline-hosted team communication platform designed as an alternative to Microsoft Teams. The application provides real-time messaging capabilities with WebSocket support, user authentication through LDAP integration, and comprehensive administrative features. Built as a full-stack web application, it emphasizes local deployment without requiring internet connectivity for core functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development experience
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: Radix UI primitives with shadcn/ui components for consistent design
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for both frontend and backend consistency
- **Real-time Communication**: WebSocket implementation for live messaging and typing indicators
- **Authentication**: JWT-based authentication with LDAP integration support
- **File Handling**: Multer for file uploads with configurable storage limits
- **API Design**: RESTful endpoints with consistent error handling and logging

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon serverless database adapter for scalable connections
- **Schema Management**: Drizzle Kit for migrations and schema synchronization
- **File Storage**: Local filesystem storage for uploaded files and avatars

### Authentication and Authorization
- **Primary Auth**: LDAP integration for Active Directory authentication
- **Fallback Auth**: Local user accounts with bcrypt password hashing
- **Session Management**: JWT tokens with configurable expiration
- **Role-based Access**: Admin and user roles with granular permissions
- **Admin Features**: Dedicated admin panel with user management and system monitoring

### External Dependencies
- **Database Provider**: Neon PostgreSQL for cloud-hosted database
- **UI Components**: Extensive Radix UI ecosystem for accessible components
- **Development Tools**: ESBuild for server bundling, TypeScript compiler for type checking
- **Real-time Features**: Native WebSocket implementation without external services
- **File Processing**: Native Node.js file system operations for uploads and cleanup

### Key Design Patterns
- **Monorepo Structure**: Shared schema and types between client and server
- **Type Safety**: End-to-end TypeScript with Zod validation schemas
- **Component Architecture**: Modular React components with clear separation of concerns
- **Database Patterns**: Relational design with proper foreign key relationships
- **Error Handling**: Centralized error management with user-friendly messages
- **Security**: Input validation, file type restrictions, and secure authentication flows

### Operational Features
- **Auto-cleanup**: Scheduled deletion of old messages and files (3-month retention)
- **Admin Monitoring**: Real-time system statistics and user activity tracking
- **Branding**: Customizable application name, colors, and logo
- **Search**: Global search across messages, users, and rooms
- **Private Messaging**: One-on-one chat capabilities alongside group rooms
- **File Sharing**: Support for multiple file types with size restrictions
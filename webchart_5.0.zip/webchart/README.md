# Sun Chats - Team Communication Platform

Sun Chats is a local, offline-hosted team communication platform designed as an alternative to Microsoft Teams. The application provides real-time messaging capabilities with WebSocket support, user authentication through LDAP integration, and comprehensive administrative features.

## Table of Contents

- [Features](#features)
- [Prerequisites](#prerequisites)
- [Development Setup](#development-setup)
- [Database Setup](#database-setup)
- [Environment Configuration](#environment-configuration)
- [Running the Application](#running-the-application)
- [Production Deployment](#production-deployment)
- [Admin Panel](#admin-panel)
- [User Management](#user-management)
- [Troubleshooting](#troubleshooting)
- [API Documentation](#api-documentation)

## Features

### Core Functionality
- **Real-time Messaging**: WebSocket-powered instant messaging with typing indicators
- **User Authentication**: JWT-based authentication with LDAP integration support
- **Room Management**: Create public/private rooms with member management
- **Private Messaging**: Direct messaging between users
- **File Sharing**: Upload and share files with size restrictions and type validation
- **Global Search**: Search across messages, users, and rooms
- **User Profiles**: Customizable user profiles with avatar upload

### Administrative Features
- **User Management**: Create, edit, ban/unban, and delete users
- **Room Administration**: Full control over room creation, management, and ownership
- **Message Monitoring**: View and manage all messages with search functionality
- **System Statistics**: Real-time monitoring of system usage and activity
- **LDAP Configuration**: Setup and manage LDAP integration for enterprise authentication
- **Branding**: Customize application name, colors, and logo
- **Data Cleanup**: Automated cleanup of old messages and files

### Security Features
- **Input Validation**: Comprehensive validation on both client and server side
- **File Type Restrictions**: Secure file upload with type and size validation
- **Role-based Access**: Admin and user roles with granular permissions
- **Session Management**: Secure JWT token handling with expiration
- **Password Security**: Strong password requirements and bcrypt hashing

## Prerequisites

Before setting up Sun Chats, ensure you have the following installed on your system:

- **Node.js**: Version 20.x or higher
- **npm**: Version 9.x or higher (comes with Node.js)
- **PostgreSQL**: Version 14.x or higher
- **Git**: For version control and deployment

### System Requirements

#### Development Environment
- **CPU**: 2+ cores
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 2GB free space
- **OS**: Windows 10+, macOS 10.15+, or Linux (Ubuntu 20.04+)

#### Production Environment
- **CPU**: 4+ cores recommended
- **RAM**: 8GB minimum, 16GB recommended for high usage
- **Storage**: 10GB+ free space (depending on file uploads and message history)
- **Network**: Stable internet connection for LDAP (if used)

## Development Setup

### 1. Clone the Repository

```bash
git clone <repository-url>
cd sun-chats
```

### 2. Install Dependencies

```bash
npm install
```

This will install all necessary dependencies including:
- React and TypeScript for the frontend
- Express.js and Node.js libraries for the backend
- Drizzle ORM for database operations
- WebSocket libraries for real-time communication
- UI components and styling libraries

### 3. Development Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/sunchats

# Session Secret (use a strong random string in production)
SESSION_SECRET=your-super-secret-key-change-this-in-production

# Application Configuration
NODE_ENV=development
PORT=5000

# File Upload Configuration (optional)
MAX_FILE_SIZE=10485760  # 10MB in bytes
UPLOAD_PATH=./uploads

# LDAP Configuration (optional)
LDAP_URL=ldap://your-ldap-server.com
LDAP_BIND_DN=cn=admin,dc=company,dc=com
LDAP_BIND_PASSWORD=your-ldap-password
LDAP_BASE_DN=dc=company,dc=com
```

## Database Setup

Sun Chats uses PostgreSQL as its primary database. Follow these steps to set up the database:

### Local PostgreSQL Installation

#### On Ubuntu/Debian:
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### On macOS (using Homebrew):
```bash
brew install postgresql@14
brew services start postgresql@14
```

#### On Windows:
Download and install PostgreSQL from the [official website](https://www.postgresql.org/download/windows/).

### Database Configuration

1. **Create Database User**:
```bash
sudo -u postgres psql
CREATE USER sunchats WITH PASSWORD 'your-secure-password';
CREATE DATABASE sunchats OWNER sunchats;
GRANT ALL PRIVILEGES ON DATABASE sunchats TO sunchats;
\q
```

2. **Update Connection String**:
Update your `.env` file with the correct database connection string:
```env
DATABASE_URL=postgresql://sunchats:your-secure-password@localhost:5432/sunchats
```

3. **Initialize Database Schema**:
```bash
npm run db:push
```

This command will create all necessary tables and indexes in your database.

### Database Schema Overview

The application creates the following main tables:
- **users**: User accounts and authentication information
- **rooms**: Chat rooms and channels
- **room_members**: Room membership relationships
- **messages**: All messages (room and private)
- **private_chats**: Private conversation tracking
- **app_settings**: Application configuration
- **ldap_config**: LDAP authentication settings

## Environment Configuration

### Development Configuration

For development, the application uses the following default settings:

- **Frontend Server**: Runs on port 5000 with Vite dev server
- **Backend API**: Integrated with frontend server
- **WebSocket**: Uses the same port as the main server
- **Database**: Local PostgreSQL instance
- **File Uploads**: Stored in `./uploads` directory

### Production Configuration

For production deployment, additional considerations include:

```env
NODE_ENV=production
SESSION_SECRET=<strong-random-string-min-32-chars>
DATABASE_URL=postgresql://user:pass@prod-db-host:5432/dbname

# Security Settings
SECURE_COOKIES=true
TRUST_PROXY=true

# Performance Settings
NODE_OPTIONS="--max-old-space-size=4096"
```

## Running the Application

### Development Mode

To start the application in development mode:

```bash
npm run dev
```

This will:
- Start the Vite development server on port 5000
- Enable hot module reloading for instant code updates
- Start the Express backend server
- Initialize WebSocket connections
- Create demo admin user (admin/admin123) if no users exist

### Accessing the Application

- **Web Interface**: http://localhost:5000
- **Default Admin Credentials**:
  - Username: `admin`
  - Password: `admin123`

⚠️ **Important**: Change the default admin password immediately after first login!

### Build for Production

To create a production build:

```bash
npm run build
```

This creates optimized files in the `dist/` directory.

### Production Mode

To start in production mode:

```bash
npm start
```

## Production Deployment

### Option 1: Direct Server Deployment

1. **Prepare the Server**:
```bash
# Install Node.js and PostgreSQL on your server
# Clone the repository
git clone <repository-url> /var/www/sunchats
cd /var/www/sunchats
```

2. **Install Dependencies**:
```bash
npm ci --production
```

3. **Configure Environment**:
```bash
cp .env.example .env
# Edit .env with production values
nano .env
```

4. **Build Application**:
```bash
npm run build
```

5. **Setup Database**:
```bash
npm run db:push
```

6. **Create Service File** (systemd):
```ini
[Unit]
Description=Sun Chats
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/sunchats
Environment=NODE_ENV=production
ExecStart=/usr/bin/node dist/index.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

7. **Start Service**:
```bash
sudo systemctl enable sunchats
sudo systemctl start sunchats
```

### Option 2: Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --production

COPY . .
RUN npm run build

EXPOSE 5000

CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t sunchats .
docker run -d -p 5000:5000 --env-file .env sunchats
```

### Reverse Proxy Configuration (Nginx)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
}
```

## Admin Panel

### Accessing Admin Features

1. Log in with an admin account
2. Navigate to the admin panel (look for the admin icon in the interface)
3. Access various administrative functions

### Admin Panel Features

#### User Management
- **Create Users**: Add new users with manual or LDAP authentication
- **Edit Users**: Modify user profiles, roles, and settings
- **Ban/Unban**: Temporarily restrict user access
- **Delete Users**: Permanently remove user accounts
- **View Activity**: Monitor user login and activity patterns

#### Room Management
- **Create Rooms**: Set up new chat rooms and channels
- **Edit Rooms**: Modify room settings and descriptions
- **Transfer Ownership**: Change room ownership between users
- **Delete Rooms**: Remove rooms and their message history
- **Member Management**: Add/remove users from rooms

#### System Monitoring
- **System Statistics**: View real-time usage statistics
- **Message Logs**: Search and monitor all messages
- **File Management**: Monitor uploaded files and storage usage
- **Cleanup Tools**: Configure automatic data cleanup

#### Configuration
- **LDAP Setup**: Configure enterprise authentication
- **Branding**: Customize application appearance
- **Security Settings**: Configure password policies and restrictions

## User Management

### Creating New Users

The admin panel includes a comprehensive user creation system:

#### Manual User Creation
1. Access Admin Panel → User Management
2. Click "Add User" button
3. Fill in the user creation form:
   - **Username**: Unique username for login
   - **Display Name**: Full name shown in the interface
   - **Email**: User's email address (optional)
   - **Password**: Secure password (min 8 chars, must include uppercase, lowercase, and number)
   - **Role**: User or Admin
   - **Department**: Organizational department (optional)
   - **LDAP User**: Toggle for LDAP-authenticated users

#### LDAP User Integration
- Enable LDAP verification for users who authenticate via LDAP
- LDAP users cannot change their passwords through the interface
- User information syncs automatically from LDAP server

### User Roles

#### Standard User
- Create and join rooms
- Send messages and files
- Update their own profile
- Change password (manual users only)
- Search messages and users

#### Administrator
- All standard user permissions
- Full user management capabilities
- Room administration
- System configuration
- Message monitoring and moderation
- LDAP configuration
- Application branding and settings

## Troubleshooting

### Common Issues

#### Database Connection Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test database connection
psql $DATABASE_URL -c "SELECT 1;"

# Reset database schema
npm run db:push --force
```

#### Permission Issues
```bash
# Fix file permissions
sudo chown -R www-data:www-data /var/www/sunchats
sudo chmod -R 755 /var/www/sunchats
```

#### Port Already in Use
```bash
# Check what's using port 5000
sudo netstat -tlnp | grep :5000
sudo lsof -i :5000

# Kill process if needed
sudo kill -9 <PID>
```

#### WebSocket Connection Issues
- Ensure your reverse proxy supports WebSocket upgrades
- Check firewall settings for WebSocket connections
- Verify the CLIENT_URL environment variable matches your domain

#### File Upload Issues
- Check disk space: `df -h`
- Verify upload directory permissions
- Check MAX_FILE_SIZE configuration
- Ensure upload directory exists and is writable

### Debug Mode

Enable debug logging:
```env
NODE_ENV=development
DEBUG=*
```

### Performance Optimization

#### Database Performance
```sql
-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
```

#### File Storage
- Consider using cloud storage (AWS S3, etc.) for production
- Implement CDN for file serving
- Regular cleanup of old files

## API Documentation

### Authentication Endpoints

- `POST /api/auth/login` - User authentication
- `GET /api/users/me` - Get current user information

### User Management Endpoints

- `GET /api/users` - List all users (admin only)
- `POST /api/users` - Create new user (admin only)
- `PUT /api/users/:id` - Update user (admin only)
- `DELETE /api/users/:id` - Delete user (admin only)
- `POST /api/users/:id/ban` - Ban user (admin only)
- `POST /api/users/:id/unban` - Unban user (admin only)

### Room Management Endpoints

- `GET /api/rooms` - Get user's rooms
- `POST /api/rooms` - Create new room
- `POST /api/rooms/:id/join` - Join room
- `POST /api/rooms/:id/leave` - Leave room

### Message Endpoints

- `GET /api/rooms/:id/messages` - Get room messages
- `GET /api/private-messages/:userId` - Get private messages

### File Upload Endpoints

- `POST /api/upload` - Upload file
- `PUT /api/users/avatar` - Upload user avatar

## Support and Maintenance

### Regular Maintenance Tasks

1. **Database Backup**:
```bash
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql
```

2. **Log Rotation**:
```bash
# Setup logrotate for application logs
sudo nano /etc/logrotate.d/sunchats
```

3. **Update Dependencies**:
```bash
npm update
npm audit fix
```

4. **Security Updates**:
```bash
npm audit
# Review and apply security updates
```

### Monitoring

Consider implementing:
- Application performance monitoring (APM)
- Database monitoring
- File system monitoring
- Network monitoring for WebSocket connections

### Backup Strategy

1. **Database**: Regular PostgreSQL backups
2. **Files**: Backup uploads directory
3. **Configuration**: Backup environment files and configuration
4. **Application**: Keep deployment scripts and configurations in version control

---

For additional support or questions, refer to the project documentation or contact your system administrator.
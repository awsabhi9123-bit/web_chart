import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { LdapConfig } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle, XCircle, Save, TestTube } from 'lucide-react';

export default function LDAPConfig() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    userCount?: number;
  } | null>(null);

  const { data: config, isLoading } = useQuery({
    queryKey: ['/api/admin/ldap'],
    queryFn: async () => {
      const response = await fetch('/api/admin/ldap', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) return null;
      return response.json() as Promise<LdapConfig>;
    },
    enabled: !!token
  });

  const [formData, setFormData] = useState({
    serverUrl: config?.serverUrl || '',
    port: config?.port || 389,
    bindDn: config?.bindDn || '',
    bindPassword: '',
    baseDn: config?.baseDn || '',
    searchFilter: config?.searchFilter || '(&(objectClass=user)(sAMAccountName={username}))',
    usernameAttribute: config?.usernameAttribute || 'sAMAccountName',
    emailAttribute: config?.emailAttribute || 'mail',
    displayNameAttribute: config?.displayNameAttribute || 'displayName',
    departmentAttribute: config?.departmentAttribute || 'department',
    sslEnabled: config?.sslEnabled || false,
    connectionTimeout: config?.connectionTimeout || 5000,
    isEnabled: config?.isEnabled || false
  });

  // Update form data when config loads
  useState(() => {
    if (config) {
      setFormData({
        serverUrl: config.serverUrl || '',
        port: config.port || 389,
        bindDn: config.bindDn || '',
        bindPassword: '',
        baseDn: config.baseDn || '',
        searchFilter: config.searchFilter || '(&(objectClass=user)(sAMAccountName={username}))',
        usernameAttribute: config.usernameAttribute || 'sAMAccountName',
        emailAttribute: config.emailAttribute || 'mail',
        displayNameAttribute: config.displayNameAttribute || 'displayName',
        departmentAttribute: config.departmentAttribute || 'department',
        sslEnabled: config.sslEnabled || false,
        connectionTimeout: config.connectionTimeout || 5000,
        isEnabled: config.isEnabled || false
      });
    }
  });

  const testConnectionMutation = useMutation({
    mutationFn: async (testConfig: typeof formData) => {
      const response = await fetch('/api/admin/ldap/test', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(testConfig)
      });
      if (!response.ok) throw new Error('Test failed');
      return response.json();
    },
    onSuccess: (data) => {
      setTestResult(data);
      if (data.success) {
        toast({
          title: "Connection Successful",
          description: `Found ${data.userCount || 0} users in the directory`
        });
      }
    },
    onError: (error) => {
      setTestResult({
        success: false,
        message: error instanceof Error ? error.message : 'Connection test failed'
      });
      toast({
        title: "Connection Failed",
        description: "Failed to connect to LDAP server",
        variant: "destructive"
      });
    }
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (configData: typeof formData) => {
      const response = await fetch('/api/admin/ldap', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(configData)
      });
      if (!response.ok) throw new Error('Failed to save configuration');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/ldap'] });
      toast({
        title: "Configuration Saved",
        description: "LDAP configuration has been updated"
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save LDAP configuration",
        variant: "destructive"
      });
    }
  });

  const handleInputChange = (field: keyof typeof formData, value: string | number | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setTestResult(null); // Clear test result when config changes
  };

  const handleTestConnection = () => {
    testConnectionMutation.mutate(formData);
  };

  const handleSaveConfig = () => {
    saveConfigMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="ldap-config">
      <h3 className="text-lg font-semibold">LDAP Configuration</h3>

      {/* Enable/Disable LDAP */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">LDAP Authentication</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Switch
              id="ldap-enabled"
              checked={formData.isEnabled}
              onCheckedChange={(checked) => handleInputChange('isEnabled', checked)}
              data-testid="switch-ldap-enabled"
            />
            <Label htmlFor="ldap-enabled">Enable LDAP Authentication</Label>
          </div>
        </CardContent>
      </Card>

      {/* Connection Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Connection Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="server-url">LDAP Server</Label>
              <Input
                id="server-url"
                placeholder="ldap://your-domain-controller.company.com"
                value={formData.serverUrl}
                onChange={(e) => handleInputChange('serverUrl', e.target.value)}
                data-testid="input-server-url"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="port">Port</Label>
              <Input
                id="port"
                type="number"
                placeholder="389"
                value={formData.port}
                onChange={(e) => handleInputChange('port', parseInt(e.target.value) || 389)}
                data-testid="input-port"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="base-dn">Base DN</Label>
              <Input
                id="base-dn"
                placeholder="DC=company,DC=com"
                value={formData.baseDn}
                onChange={(e) => handleInputChange('baseDn', e.target.value)}
                data-testid="input-base-dn"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bind-dn">Bind DN</Label>
              <Input
                id="bind-dn"
                placeholder="CN=sunchats,CN=Users,DC=company,DC=com"
                value={formData.bindDn}
                onChange={(e) => handleInputChange('bindDn', e.target.value)}
                data-testid="input-bind-dn"
              />
            </div>
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="bind-password">Bind Password</Label>
              <Input
                id="bind-password"
                type="password"
                placeholder="Service account password"
                value={formData.bindPassword}
                onChange={(e) => handleInputChange('bindPassword', e.target.value)}
                data-testid="input-bind-password"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* User Mapping */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">User Attribute Mapping</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username-attr">Username Attribute</Label>
              <Input
                id="username-attr"
                placeholder="sAMAccountName"
                value={formData.usernameAttribute}
                onChange={(e) => handleInputChange('usernameAttribute', e.target.value)}
                data-testid="input-username-attribute"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email-attr">Email Attribute</Label>
              <Input
                id="email-attr"
                placeholder="mail"
                value={formData.emailAttribute}
                onChange={(e) => handleInputChange('emailAttribute', e.target.value)}
                data-testid="input-email-attribute"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="display-name-attr">Display Name Attribute</Label>
              <Input
                id="display-name-attr"
                placeholder="displayName"
                value={formData.displayNameAttribute}
                onChange={(e) => handleInputChange('displayNameAttribute', e.target.value)}
                data-testid="input-display-name-attribute"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department-attr">Department Attribute</Label>
              <Input
                id="department-attr"
                placeholder="department"
                value={formData.departmentAttribute}
                onChange={(e) => handleInputChange('departmentAttribute', e.target.value)}
                data-testid="input-department-attribute"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Connection Test */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Connection Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button
              onClick={handleTestConnection}
              disabled={testConnectionMutation.isPending || !formData.serverUrl || !formData.baseDn}
              data-testid="button-test-connection"
            >
              {testConnectionMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <TestTube className="mr-2 h-4 w-4" />
              )}
              Test Connection
            </Button>
            <Button 
              onClick={handleSaveConfig}
              disabled={saveConfigMutation.isPending}
              data-testid="button-save-config"
            >
              {saveConfigMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save Configuration
            </Button>
          </div>

          {/* Test Results */}
          {testResult && (
            <div className={`p-3 rounded-md border ${
              testResult.success 
                ? 'bg-green-50 border-green-200 text-green-800' 
                : 'bg-red-50 border-red-200 text-red-800'
            }`}>
              <div className="flex items-center gap-2">
                {testResult.success ? (
                  <CheckCircle className="h-4 w-4" />
                ) : (
                  <XCircle className="h-4 w-4" />
                )}
                <span className="font-medium">
                  {testResult.success ? 'Connection Successful!' : 'Connection Failed'}
                </span>
              </div>
              <p className="text-sm mt-1">{testResult.message}</p>
              {testResult.success && testResult.userCount && (
                <p className="text-sm mt-1">Found {testResult.userCount} users in the directory.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export interface User {
  id: string;
  username: string;
  displayName: string;
  email?: string;
  avatar?: string;
  role: 'admin' | 'user';
  department?: string;
  isActive: boolean;
  isBanned: boolean;
  lastActive?: string;
}

export interface Room {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  isPrivate: boolean;
  createdBy: string;
  createdAt: string;
}

export interface Message {
  id: string;
  roomId?: string;
  senderId: string;
  recipientId?: string;
  content?: string;
  filePath?: string;
  fileName?: string;
  fileSize?: number;
  messageType: 'text' | 'file' | 'system';
  isPrivate: boolean;
  createdAt: string;
  sender?: User;
}

export interface PrivateChat {
  id: string;
  user1Id: string;
  user2Id: string;
  lastMessageAt?: string;
  createdAt: string;
  otherUser?: User;
  lastMessage?: Message;
}

export interface AppSettings {
  id: string;
  logoPath?: string;
  appName: string;
  primaryColor: string;
  createdAt: string;
  updatedAt: string;
}

export interface LdapConfig {
  id: string;
  serverUrl?: string;
  port?: number;
  bindDn?: string;
  baseDn?: string;
  searchFilter?: string;
  usernameAttribute?: string;
  emailAttribute?: string;
  displayNameAttribute?: string;
  departmentAttribute?: string;
  sslEnabled?: boolean;
  connectionTimeout?: number;
  isEnabled?: boolean;
  updatedAt: string;
}

export interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export interface TypingUser {
  userId: string;
  username: string;
  displayName: string;
}

export interface SearchResults {
  users: User[];
  rooms: Room[];
  messages: Array<Message & { room: Room | null }>;
}

export interface SystemStats {
  totalUsers: number;
  activeRooms: number;
  messagesToday: number;
  filesUploaded: number;
  connectedUsers?: number;
}

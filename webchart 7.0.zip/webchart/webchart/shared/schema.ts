import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, blob } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = sqliteTable("users", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email"),
  avatar: text("avatar"),
  role: text("role").notNull().default("user"), // admin, user
  department: text("department"),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  isBanned: integer("is_banned", { mode: "boolean" }).notNull().default(false),
  ldapVerified: integer("ldap_verified", { mode: "boolean" }).notNull().default(false),
  lastActive: integer("last_active", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// Rooms table
export const rooms = sqliteTable("rooms", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon"),
  isPrivate: integer("is_private", { mode: "boolean" }).notNull().default(false),
  createdBy: text("created_by").notNull().references(() => users.id),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// Room members table
export const roomMembers = sqliteTable("room_members", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  roomId: text("room_id").notNull().references(() => rooms.id),
  userId: text("user_id").notNull().references(() => users.id),
  joinedAt: integer("joined_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// Messages table
export const messages = sqliteTable("messages", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  roomId: text("room_id").references(() => rooms.id),
  senderId: text("sender_id").notNull().references(() => users.id),
  recipientId: text("recipient_id").references(() => users.id), // for private messages
  content: text("content"),
  filePath: text("file_path"),
  fileName: text("file_name"),
  fileSize: integer("file_size"),
  messageType: text("message_type").notNull().default("text"), // text, file, system
  isPrivate: integer("is_private", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// Private chats table
export const privateChats = sqliteTable("private_chats", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  user1Id: text("user1_id").notNull().references(() => users.id),
  user2Id: text("user2_id").notNull().references(() => users.id),
  lastMessageAt: integer("last_message_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// App settings table
export const appSettings = sqliteTable("app_settings", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  logoPath: text("logo_path"),
  appName: text("app_name").notNull().default("Sun Chats"),
  primaryColor: text("primary_color").notNull().default("#FFEB3B"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// LDAP config table
export const ldapConfig = sqliteTable("ldap_config", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  serverUrl: text("server_url"),
  port: integer("port").default(389),
  bindDn: text("bind_dn"),
  bindPassword: text("bind_password"),
  baseDn: text("base_dn"),
  searchFilter: text("search_filter").default("(&(objectClass=user)(sAMAccountName={username}))"),
  usernameAttribute: text("username_attribute").default("sAMAccountName"),
  emailAttribute: text("email_attribute").default("mail"),
  displayNameAttribute: text("display_name_attribute").default("displayName"),
  departmentAttribute: text("department_attribute").default("department"),
  sslEnabled: integer("ssl_enabled", { mode: "boolean" }).default(false),
  connectionTimeout: integer("connection_timeout").default(5000),
  isEnabled: integer("is_enabled", { mode: "boolean" }).default(false),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  sentMessages: many(messages, { relationName: "sender" }),
  receivedMessages: many(messages, { relationName: "recipient" }),
  roomMemberships: many(roomMembers),
  createdRooms: many(rooms),
}));

export const roomsRelations = relations(rooms, ({ one, many }) => ({
  creator: one(users, { fields: [rooms.createdBy], references: [users.id] }),
  members: many(roomMembers),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, { fields: [messages.senderId], references: [users.id], relationName: "sender" }),
  recipient: one(users, { fields: [messages.recipientId], references: [users.id], relationName: "recipient" }),
  room: one(rooms, { fields: [messages.roomId], references: [rooms.id] }),
}));

export const roomMembersRelations = relations(roomMembers, ({ one }) => ({
  room: one(rooms, { fields: [roomMembers.roomId], references: [rooms.id] }),
  user: one(users, { fields: [roomMembers.userId], references: [users.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertRoomMemberSchema = createInsertSchema(roomMembers).omit({ id: true, joinedAt: true });
export const insertPrivateChatSchema = createInsertSchema(privateChats).omit({ id: true, createdAt: true });
export const insertAppSettingsSchema = createInsertSchema(appSettings).omit({ id: true, createdAt: true, updatedAt: true });
export const insertLdapConfigSchema = createInsertSchema(ldapConfig).omit({ id: true, updatedAt: true });

// Types
export type User = typeof users.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type RoomMember = typeof roomMembers.$inferSelect;
export type PrivateChat = typeof privateChats.$inferSelect;
export type AppSettings = typeof appSettings.$inferSelect;
export type LdapConfig = typeof ldapConfig.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertRoomMember = z.infer<typeof insertRoomMemberSchema>;
export type InsertPrivateChat = z.infer<typeof insertPrivateChatSchema>;
export type InsertAppSettings = z.infer<typeof insertAppSettingsSchema>;
export type InsertLdapConfig = z.infer<typeof insertLdapConfigSchema>;

import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import { UnreadMessagesContext, useUnreadMessagesProvider } from "./hooks/useUnreadMessages";
import Login from "./pages/login";
import Dashboard from "./pages/dashboard";
import NotFound from "@/pages/not-found";

function Router() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-background">
        <div className="animate-pulse">
          <div className="w-16 h-16 mx-auto bg-primary rounded-full flex items-center justify-center mb-4">
            <i className="fas fa-sun text-2xl text-primary-foreground"></i>
          </div>
          <p className="text-muted-foreground">Loading Sun Chats...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      {user ? (
        <Route path="/*" component={Dashboard} />
      ) : (
        <Route component={Login} />
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function AppWithProviders() {
  const unreadMessagesProvider = useUnreadMessagesProvider();
  
  return (
    <UnreadMessagesContext.Provider value={unreadMessagesProvider}>
      <Toaster />
      <Router />
    </UnreadMessagesContext.Provider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <AppWithProviders />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

import { useState } from 'react';
import { Switch, Route, useLocation } from 'wouter';
import Sidebar from '@/components/sidebar/Sidebar';
import ChatArea from '@/components/chat/ChatArea';
import AdminPanel from '@/components/admin/AdminPanel';
import ProfileSettings from '@/components/profile/ProfileSettings';
import { useWebSocket } from '@/hooks/useWebSocket';

export default function Dashboard() {
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const [activeRoom, setActiveRoom] = useState<string | null>(null);
  const [activePrivateChat, setActivePrivateChat] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const webSocket = useWebSocket();

  const handleJoinRoom = (roomId: string) => {
    setActivePrivateChat(null);
    setActiveRoom(roomId);
    webSocket.joinRoom(roomId);
    setLocation(`/room/${roomId}`);
  };

  const handleStartPrivateChat = (userId: string) => {
    setActiveRoom(null);
    setActivePrivateChat(userId);
    webSocket.leaveRoom();
    setLocation(`/chat/${userId}`);
  };

  return (
    <div className="h-screen flex bg-background" data-testid="dashboard-main">
      <Sidebar
        onJoinRoom={handleJoinRoom}
        onStartPrivateChat={handleStartPrivateChat}
        onOpenAdminPanel={() => setShowAdminPanel(true)}
        onOpenProfileSettings={() => setShowProfileSettings(true)}
        activeRoom={activeRoom}
        activePrivateChat={activePrivateChat}
      />
      
      <div className="flex-1">
        <Switch>
          <Route path="/room/:roomId">
            {(params) => (
              <ChatArea 
                roomId={params.roomId}
                isPrivateChat={false}
                webSocket={webSocket}
                onStartPrivateChat={handleStartPrivateChat}
              />
            )}
          </Route>
          <Route path="/chat/:userId">
            {(params) => (
              <ChatArea 
                userId={params.userId}
                isPrivateChat={true}
                webSocket={webSocket}
                onStartPrivateChat={handleStartPrivateChat}
              />
            )}
          </Route>
          <Route>
            <div className="flex-1 flex items-center justify-center bg-background">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <i className="fas fa-comments text-primary text-2xl"></i>
                </div>
                <h2 className="text-xl font-semibold text-foreground mb-2">Welcome to Sun Chats</h2>
                <p className="text-muted-foreground">Select a room or start a conversation to begin messaging</p>
              </div>
            </div>
          </Route>
        </Switch>
      </div>

      {showAdminPanel && (
        <AdminPanel onClose={() => setShowAdminPanel(false)} />
      )}
      
      {showProfileSettings && (
        <ProfileSettings onClose={() => setShowProfileSettings(false)} />
      )}
    </div>
  );
}

import { useState, useEffect, useRef, useCallback } from 'react';
import { WebSocketMessage, Message, TypingUser } from '../types';
import { useAuth } from './useAuth';
import { useUnreadMessages } from './useUnreadMessages';

export function useWebSocket() {
  const { user, token } = useAuth();
  const { addUnreadMessage } = useUnreadMessages();
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const currentRoomRef = useRef<string | null>(null);
  const currentPrivateChatRef = useRef<string | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (!user || !token) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      
      // Authenticate
      ws.send(JSON.stringify({
        type: 'auth',
        userId: user.id,
        username: user.username
      }));
    };

    ws.onclose = () => {
      setIsConnected(false);
      
      // Reconnect after 3 seconds
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 3000);
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };

    ws.onmessage = (event) => {
      try {
        const data: WebSocketMessage = JSON.parse(event.data);
        handleMessage(data);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };
  }, [user, token]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    
    setIsConnected(false);
  }, []);

  const handleMessage = (data: WebSocketMessage) => {
    switch (data.type) {
      case 'auth_success':
        console.log('WebSocket authenticated');
        break;
        
      case 'room_joined':
        setMessages(data.messages || []);
        break;
        
      case 'new_message':
        if (data.message.roomId === currentRoomRef.current) {
          setMessages(prev => [...prev, data.message]);
        } else if (data.message.senderId !== user?.id) {
          // Add to unread count if message is from someone else and not in current room
          addUnreadMessage(data.message.roomId, data.message);
        }
        break;
        
      case 'new_private_message':
        // Handle private messages differently
        if (data.message.isPrivate) {
          const otherUserId = data.message.senderId === user?.id ? data.message.recipientId : data.message.senderId;
          
          if (otherUserId === currentPrivateChatRef.current) {
            setMessages(prev => [...prev, data.message]);
          } else if (data.message.senderId !== user?.id) {
            // Add to unread count if message is from someone else and not in current private chat
            addUnreadMessage(`private_${otherUserId}`, data.message);
          }
        }
        break;
        
      case 'typing_start':
        setTypingUsers(prev => {
          const filtered = prev.filter(u => u.userId !== data.userId);
          return [...filtered, {
            userId: data.userId,
            username: data.username,
            displayName: data.displayName
          }];
        });
        break;
        
      case 'typing_stop':
        setTypingUsers(prev => prev.filter(u => u.userId !== data.userId));
        break;
        
      case 'error':
        console.error('WebSocket error:', data.message);
        break;
    }
  };

  const joinRoom = useCallback((roomId: string) => {
    if (!wsRef.current || !isConnected) return;
    
    currentRoomRef.current = roomId;
    wsRef.current.send(JSON.stringify({
      type: 'join_room',
      roomId
    }));
  }, [isConnected]);

  const leaveRoom = useCallback(() => {
    if (!wsRef.current || !isConnected || !currentRoomRef.current) return;
    
    wsRef.current.send(JSON.stringify({
      type: 'leave_room',
      roomId: currentRoomRef.current
    }));
    
    currentRoomRef.current = null;
    setMessages([]);
    setTypingUsers([]);
  }, [isConnected]);

  const sendMessage = useCallback((content: string, messageType = 'text', fileName?: string, fileSize?: number) => {
    if (!wsRef.current || !isConnected || !currentRoomRef.current) return;
    
    wsRef.current.send(JSON.stringify({
      type: 'send_message',
      roomId: currentRoomRef.current,
      content,
      messageType,
      fileName,
      fileSize
    }));
  }, [isConnected]);

  const sendPrivateMessage = useCallback((recipientId: string, content: string, messageType = 'text', fileName?: string, fileSize?: number) => {
    if (!wsRef.current || !isConnected) return;
    
    // Set current private chat reference
    currentPrivateChatRef.current = recipientId;
    
    wsRef.current.send(JSON.stringify({
      type: 'send_private_message',
      recipientId,
      content,
      messageType,
      fileName,
      fileSize
    }));
  }, [isConnected]);

  const startTyping = useCallback(() => {
    if (!wsRef.current || !isConnected || !currentRoomRef.current) return;
    
    wsRef.current.send(JSON.stringify({
      type: 'typing_start',
      roomId: currentRoomRef.current
    }));
  }, [isConnected]);

  const stopTyping = useCallback(() => {
    if (!wsRef.current || !isConnected || !currentRoomRef.current) return;
    
    wsRef.current.send(JSON.stringify({
      type: 'typing_stop',
      roomId: currentRoomRef.current
    }));
  }, [isConnected]);

  useEffect(() => {
    if (user && token) {
      connect();
    } else {
      disconnect();
    }

    return () => {
      disconnect();
    };
  }, [user, token, connect, disconnect]);

  return {
    isConnected,
    messages,
    typingUsers,
    joinRoom,
    leaveRoom,
    sendMessage,
    sendPrivateMessage,
    startTyping,
    stopTyping,
    currentRoom: currentRoomRef.current,
    currentPrivateChat: currentPrivateChatRef.current
  };
}

import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { Message } from '@/types';

interface UnreadMessageCounts {
  [key: string]: number; // key can be roomId or userId for private chats
}

interface UnreadMessagesContextType {
  unreadCounts: UnreadMessageCounts;
  addUnreadMessage: (roomId: string, message: Message) => void;
  markAsRead: (roomId: string) => void;
  clearAllUnread: () => void;
  getTotalUnread: () => number;
  hasUnread: (roomId: string) => boolean;
}

export const UnreadMessagesContext = createContext<UnreadMessagesContextType | null>(null);

export function useUnreadMessages() {
  const context = useContext(UnreadMessagesContext);
  if (!context) {
    throw new Error('useUnreadMessages must be used within UnreadMessagesProvider');
  }
  return context;
}

export function useUnreadMessagesProvider() {
  const [unreadCounts, setUnreadCounts] = useState<UnreadMessageCounts>({});

  const addUnreadMessage = useCallback((chatId: string, message: Message) => {
    setUnreadCounts(prev => ({
      ...prev,
      [chatId]: (prev[chatId] || 0) + 1
    }));
  }, []);

  const markAsRead = useCallback((chatId: string) => {
    setUnreadCounts(prev => {
      const newCounts = { ...prev };
      delete newCounts[chatId];
      return newCounts;
    });
  }, []);

  const clearAllUnread = useCallback(() => {
    setUnreadCounts({});
  }, []);

  const getTotalUnread = useCallback(() => {
    return Object.values(unreadCounts).reduce((total, count) => total + count, 0);
  }, [unreadCounts]);

  const hasUnread = useCallback((chatId: string) => {
    return (unreadCounts[chatId] || 0) > 0;
  }, [unreadCounts]);

  return {
    unreadCounts,
    addUnreadMessage,
    markAsRead,
    clearAllUnread,
    getTotalUnread,
    hasUnread
  };
}
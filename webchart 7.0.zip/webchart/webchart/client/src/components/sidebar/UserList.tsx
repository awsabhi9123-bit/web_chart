import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { User } from '@/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { groupBy } from 'lodash-es';

interface UserListProps {
  onStartPrivateChat: (userId: string) => void;
}

const getStatusColor = (lastActive?: string) => {
  if (!lastActive) return 'bg-gray-400';
  
  const lastActiveDate = new Date(lastActive);
  const now = new Date();
  const diffInMinutes = (now.getTime() - lastActiveDate.getTime()) / (1000 * 60);
  
  if (diffInMinutes < 5) return 'bg-green-500';
  if (diffInMinutes < 30) return 'bg-yellow-500';
  return 'bg-gray-400';
};

const getStatusTitle = (lastActive?: string) => {
  if (!lastActive) return 'Offline';
  
  const lastActiveDate = new Date(lastActive);
  const now = new Date();
  const diffInMinutes = (now.getTime() - lastActiveDate.getTime()) / (1000 * 60);
  
  if (diffInMinutes < 5) return 'Online';
  if (diffInMinutes < 30) return 'Away';
  return 'Offline';
};

export default function UserList({ onStartPrivateChat }: UserListProps) {
  const { token, user: currentUser } = useAuth();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<User[]>;
    },
    enabled: !!token
  });

  if (isLoading) {
    return (
      <div className="px-4 py-2">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="space-y-2">
                {[...Array(2)].map((_, j) => (
                  <div key={j} className="h-12 bg-muted rounded-md"></div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Filter out current user and group by department
  const otherUsers = users.filter(user => user.id !== currentUser?.id);
  const usersByDepartment = groupBy(otherUsers, 'department');

  return (
    <div className="px-4 space-y-4">
      {Object.entries(usersByDepartment).map(([department, departmentUsers]) => (
        <div key={department || 'Other'}>
          <h4 className="text-xs font-semibold text-muted-foreground mb-2 px-3 uppercase">
            {department || 'Other'}
          </h4>
          <div className="space-y-1">
            {departmentUsers.map((user) => (
              <div
                key={user.id}
                className="p-3 hover:bg-accent rounded-md cursor-pointer group transition-colors"
                onClick={() => onStartPrivateChat(user.id)}
                data-testid={`user-item-${user.id}`}
              >
                <div className="flex items-center gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user.avatar} alt={user.displayName} />
                    <AvatarFallback>
                      {user.displayName.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-medium truncate">{user.displayName}</h3>
                      {user.role === 'admin' && (
                        <Badge variant="secondary" className="text-xs">Admin</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{user.username}</p>
                  </div>
                  <div 
                    className={`w-2 h-2 rounded-full ${getStatusColor(user.lastActive)}`}
                    title={getStatusTitle(user.lastActive)}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

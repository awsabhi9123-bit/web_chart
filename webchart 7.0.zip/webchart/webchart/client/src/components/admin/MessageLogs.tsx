import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Message, User, Room } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Search, Trash2, MessageSquare, Users, Calendar, Hash, Code, Megaphone, Lock, User as UserIcon, File } from 'lucide-react';
import { format } from 'date-fns';

interface MessageWithDetails extends Message {
  sender: User;
  recipient: User | null;
  room: Room | null;
}

interface MessageStats {
  totalMessages: number;
  roomMessages: number;
  privateMessages: number;
  todayMessages: number;
}

export default function MessageLogs() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [messageFilter, setMessageFilter] = useState('all');
  const [deleteConfirm, setDeleteConfirm] = useState<MessageWithDetails | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const messagesPerPage = 50;

  // Fetch message statistics
  const { data: messageStats } = useQuery({
    queryKey: ['/api/admin/messages/stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/messages/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch message statistics');
      return response.json() as Promise<MessageStats>;
    },
    enabled: !!token
  });

  // Fetch messages
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['/api/admin/messages', searchTerm, currentPage],
    queryFn: async () => {
      const params = new URLSearchParams({
        limit: messagesPerPage.toString(),
        offset: (currentPage * messagesPerPage).toString(),
      });
      
      if (searchTerm.trim()) {
        params.append('search', searchTerm.trim());
      }
      
      const response = await fetch(`/api/admin/messages?${params}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json() as Promise<MessageWithDetails[]>;
    },
    enabled: !!token
  });

  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId: string) => {
      const response = await fetch(`/api/admin/messages/${messageId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to delete message');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/messages'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/messages/stats'] });
      toast({
        title: "Success",
        description: "Message has been deleted"
      });
      setDeleteConfirm(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete message",
        variant: "destructive"
      });
    }
  });

  const filteredMessages = messages.filter((message) => {
    if (messageFilter === 'room' && message.isPrivate) return false;
    if (messageFilter === 'private' && !message.isPrivate) return false;
    if (messageFilter === 'files' && message.messageType !== 'file') return false;
    return true;
  });

  const getRoomIcon = (iconName?: string) => {
    switch (iconName) {
      case 'code':
        return <Code className="h-3 w-3" />;
      case 'bullhorn':
        return <Megaphone className="h-3 w-3" />;
      default:
        return <Hash className="h-3 w-3" />;
    }
  };

  const getMessageContent = (message: MessageWithDetails) => {
    if (message.messageType === 'file') {
      return (
        <div className="flex items-center gap-2 text-sm">
          <File className="h-4 w-4" />
          <span className="font-medium">{message.fileName}</span>
          {message.fileSize && (
            <span className="text-muted-foreground">
              ({Math.round(message.fileSize / 1024)} KB)
            </span>
          )}
        </div>
      );
    }
    return (
      <div className="max-w-md">
        <p className="text-sm truncate">{message.content}</p>
      </div>
    );
  };

  const getMessageLocation = (message: MessageWithDetails) => {
    if (message.isPrivate && message.recipient) {
      return (
        <div className="flex items-center gap-2">
          <Lock className="h-3 w-3 text-muted-foreground" />
          <span className="text-sm">
            Direct message to {message.recipient.displayName}
          </span>
        </div>
      );
    } else if (message.room) {
      return (
        <div className="flex items-center gap-2">
          {getRoomIcon(message.room.icon)}
          <span className="text-sm">{message.room.name}</span>
        </div>
      );
    }
    return <span className="text-sm text-muted-foreground">Unknown location</span>;
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-muted rounded-md"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Message Logs</h2>
          <p className="text-muted-foreground">
            Monitor and manage all messages across the platform
          </p>
        </div>
        <Badge variant="secondary" className="text-sm">
          {filteredMessages.length} messages
        </Badge>
      </div>

      {/* Statistics Cards */}
      {messageStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messageStats.totalMessages.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Room Messages</CardTitle>
              <Hash className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messageStats.roomMessages.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Private Messages</CardTitle>
              <Lock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messageStats.privateMessages.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Messages</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messageStats.todayMessages.toLocaleString()}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search messages..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(0); // Reset to first page when searching
            }}
            className="pl-10"
          />
        </div>
        <Select value={messageFilter} onValueChange={setMessageFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Messages</SelectItem>
            <SelectItem value="room">Room Messages</SelectItem>
            <SelectItem value="private">Private Messages</SelectItem>
            <SelectItem value="files">File Messages</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Messages Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Sender</TableHead>
              <TableHead>Content</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMessages.map((message) => (
              <TableRow key={message.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={message.sender.avatar || undefined} />
                      <AvatarFallback>
                        {message.sender.displayName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-sm">{message.sender.displayName}</div>
                      <div className="text-xs text-muted-foreground">@{message.sender.username}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  {getMessageContent(message)}
                </TableCell>
                <TableCell>
                  {getMessageLocation(message)}
                </TableCell>
                <TableCell>
                  <Badge variant={message.isPrivate ? "secondary" : "outline"}>
                    {message.isPrivate ? (
                      <>
                        <Lock className="h-3 w-3 mr-1" />
                        Private
                      </>
                    ) : message.messageType === 'file' ? (
                      <>
                        <File className="h-3 w-3 mr-1" />
                        File
                      </>
                    ) : (
                      <>
                        <MessageSquare className="h-3 w-3 mr-1" />
                        Room
                      </>
                    )}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    {format(new Date(message.createdAt), 'MMM d, yyyy')}
                    <div className="text-xs text-muted-foreground">
                      {format(new Date(message.createdAt), 'HH:mm')}
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setDeleteConfirm(message)}
                    title="Delete Message"
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {currentPage * messagesPerPage + 1} to {Math.min((currentPage + 1) * messagesPerPage, filteredMessages.length)} of {filteredMessages.length} messages
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
            disabled={currentPage === 0}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentPage(currentPage + 1)}
            disabled={filteredMessages.length < messagesPerPage}
          >
            Next
          </Button>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Message</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this message from{' '}
              <strong>{deleteConfirm?.sender.displayName}</strong>?
              <br /><br />
              {deleteConfirm && (
                <div className="bg-muted p-3 rounded-md mt-2">
                  {getMessageContent(deleteConfirm)}
                </div>
              )}
              <br />
              <strong>This action cannot be undone.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteConfirm(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && deleteMessageMutation.mutate(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Message
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
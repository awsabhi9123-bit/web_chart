import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Message, TypingUser } from '@/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Download, File } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';

interface MessageListProps {
  roomId?: string;
  userId?: string;
  isPrivateChat: boolean;
  webSocket: any;
  onStartPrivateChat?: (userId: string) => void;
}

export default function MessageList({ roomId, userId, isPrivateChat, webSocket, onStartPrivateChat }: MessageListProps) {
  const { token, user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [localMessages, setLocalMessages] = useState<Message[]>([]);

  // Fetch initial messages
  const { data: initialMessages = [] } = useQuery({
    queryKey: isPrivateChat ? ['/api/private-messages', userId] : ['/api/rooms', roomId, 'messages'],
    queryFn: async () => {
      const url = isPrivateChat 
        ? `/api/private-messages/${userId}?limit=50`
        : `/api/rooms/${roomId}/messages?limit=50`;
      
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json() as Promise<Message[]>;
    },
    enabled: !!(roomId || userId) && !!token
  });

  // Update local messages when WebSocket messages change
  useEffect(() => {
    if (webSocket.messages) {
      setLocalMessages(webSocket.messages);
    }
  }, [webSocket.messages]);

  // Set initial messages
  useEffect(() => {
    if (initialMessages.length > 0 && localMessages.length === 0) {
      setLocalMessages(initialMessages);
    }
  }, [initialMessages, localMessages.length]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [localMessages]);

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return format(date, 'HH:mm');
    } else if (isYesterday(date)) {
      return `Yesterday ${format(date, 'HH:mm')}`;
    } else {
      return format(date, 'MMM d, HH:mm');
    }
  };

  const isOwnMessage = (message: Message) => {
    return message.senderId === user?.id;
  };

  const handleFileDownload = async (message: Message) => {
    if (!message.fileName || !message.content) return;
    
    try {
      const response = await fetch(`/api/download/${encodeURIComponent(message.content)}`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
        }
      });

      if (!response.ok) {
        throw new Error('Download failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = message.fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('File download failed:', error);
    }
  };

  const renderFileMessage = (message: Message) => {
    const isImage = message.fileName && /\.(jpg|jpeg|png|gif|webp)$/i.test(message.fileName);
    
    return (
      <div className="bg-card border border-border rounded-lg p-3 max-w-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            {isImage ? (
              <i className="fas fa-file-image text-primary"></i>
            ) : (
              <File className="h-5 w-5 text-primary" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{message.fileName}</p>
            <p className="text-xs text-muted-foreground">
              {message.fileSize ? `${Math.round(message.fileSize / 1024)} KB` : 'Unknown size'}
            </p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8"
            onClick={() => handleFileDownload(message)}
            title="Download file"
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const renderMessage = (message: Message, index: number) => {
    const isOwn = isOwnMessage(message);
    const showAvatar = !isOwn && (index === 0 || localMessages[index - 1]?.senderId !== message.senderId);
    
    if (message.messageType === 'system') {
      return (
        <div key={message.id} className="text-center my-4">
          <span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
            {message.content}
          </span>
        </div>
      );
    }

    return (
      <div 
        key={message.id} 
        className={`flex gap-3 message-animation mb-4 ${isOwn ? 'justify-end' : ''}`}
        data-testid={`message-${message.id}`}
      >
        {!isOwn && showAvatar && (
          <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
            <AvatarImage src={message.sender?.avatar} alt={message.sender?.displayName} />
            <AvatarFallback>
              {message.sender?.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
        
        {!isOwn && !showAvatar && <div className="w-8" />}
        
        <div className={`flex-1 min-w-0 ${isOwn ? 'max-w-2xl' : ''}`}>
          {showAvatar && !isOwn && (
            <div className="flex items-center gap-2 mb-1">
              <span 
                className="font-medium text-sm hover:underline cursor-pointer text-blue-600 hover:text-blue-800"
                onClick={() => onStartPrivateChat?.(message.senderId)}
                title="Click to chat with this user"
              >
                {message.sender?.displayName}
              </span>
            </div>
          )}
          
          <div className={`${isOwn ? 'flex justify-end' : ''}`}>
            {message.messageType === 'file' ? (
              renderFileMessage(message)
            ) : (
              <div className={`rounded-2xl px-4 py-2 text-sm max-w-prose shadow-sm ${
                isOwn 
                  ? 'bg-green-500 text-white rounded-br-md' 
                  : 'bg-white text-gray-900 border border-gray-200 rounded-bl-md'
              }`}>
                <div className="break-words">{message.content}</div>
                <div className={`text-xs mt-1 ${isOwn ? 'text-green-100' : 'text-gray-500'}`}>
                  {formatMessageTime(message.createdAt)}
                  {isOwn && (
                    <span className="ml-1">
                      <svg className="inline w-4 h-4" viewBox="0 0 16 16" fill="currentColor">
                        <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.061L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
                      </svg>
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
        
        {isOwn && (
          <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
            <AvatarImage src={user?.avatar} alt={user?.displayName} />
            <AvatarFallback>
              {user?.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
      </div>
    );
  };

  const renderTypingIndicators = () => {
    if (!webSocket.typingUsers || webSocket.typingUsers.length === 0) return null;
    
    return webSocket.typingUsers.map((typingUser: TypingUser) => (
      <div key={typingUser.userId} className="flex gap-3 typing-indicator mb-4">
        <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
          <AvatarFallback>
            {typingUser.displayName.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">{typingUser.displayName}</span>
            <span className="text-xs text-muted-foreground">is typing...</span>
          </div>
          <div className="typing-indicator">
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
          </div>
        </div>
      </div>
    ));
  };

  return (
    <div 
      className="h-full overflow-y-auto px-6 py-4 scroll-smooth"
      data-testid="message-list"
    >
      <div className="space-y-1">
        {localMessages.map((message, index) => renderMessage(message, index))}
        {renderTypingIndicators()}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

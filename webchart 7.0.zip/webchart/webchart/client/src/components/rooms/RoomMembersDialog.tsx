import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { User } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, UserMinus, Search } from 'lucide-react';

interface RoomMembersDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  roomId: string;
  roomName: string;
  webSocket: any;
}

export default function RoomMembersDialog({
  open,
  onOpenChange,
  roomId,
  roomName,
  webSocket
}: RoomMembersDialogProps) {
  const { token, user } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch room members
  const { data: members = [], refetch: refetchMembers } = useQuery({
    queryKey: ['/api/rooms', roomId, 'members'],
    queryFn: async () => {
      const response = await fetch(`/api/rooms/${roomId}/members`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch members');
      return response.json() as Promise<User[]>;
    },
    enabled: !!token && !!roomId && open
  });

  // Fetch all users for adding
  const { data: allUsers = [] } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json() as Promise<User[]>;
    },
    enabled: !!token && open
  });

  // Filter users that can be added
  const memberIds = new Set(members.map(m => m.id));
  const availableUsers = allUsers.filter(u => 
    !memberIds.has(u.id) &&
    u.id !== user?.id &&
    (searchQuery === '' || 
     u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
     u.username.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleAddMember = async (userId: string) => {
    if (!webSocket.isConnected) {
      toast({
        title: "Connection Error",
        description: "Not connected to chat server",
        variant: "destructive"
      });
      return;
    }

    try {
      webSocket.sendMessage(JSON.stringify({
        type: 'add_room_member',
        roomId,
        userId
      }));

      toast({
        title: "Member Added",
        description: "User has been added to the room",
      });

      // Refetch members to update the list
      setTimeout(() => refetchMembers(), 500);
    } catch (error) {
      toast({
        title: "Failed to Add Member",
        description: "Could not add user to room",
        variant: "destructive"
      });
    }
  };

  const handleRemoveMember = async (userId: string) => {
    if (!webSocket.isConnected) {
      toast({
        title: "Connection Error",
        description: "Not connected to chat server",
        variant: "destructive"
      });
      return;
    }

    try {
      webSocket.sendMessage(JSON.stringify({
        type: 'remove_room_member',
        roomId,
        userId
      }));

      toast({
        title: "Member Removed",
        description: "User has been removed from the room",
      });

      // Refetch members to update the list
      setTimeout(() => refetchMembers(), 500);
    } catch (error) {
      toast({
        title: "Failed to Remove Member",
        description: "Could not remove user from room",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>Manage Members - {roomName}</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-6 max-h-[60vh] overflow-hidden">
          {/* Current Members */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Current Members ({members.length})</h3>
            <div className="max-h-48 overflow-y-auto space-y-2">
              {members.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={member.avatar} alt={member.displayName} />
                      <AvatarFallback>
                        {member.displayName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{member.displayName}</span>
                        {member.role === 'admin' && (
                          <Badge variant="secondary">Admin</Badge>
                        )}
                        {member.id === user?.id && (
                          <Badge variant="outline">You</Badge>
                        )}
                      </div>
                      <span className="text-sm text-gray-500">@{member.username}</span>
                    </div>
                  </div>
                  
                  {member.id !== user?.id && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleRemoveMember(member.id)}
                      className="flex items-center gap-2"
                    >
                      <UserMinus className="w-4 h-4" />
                      Remove
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Add New Members */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Add New Members</h3>
            
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search users to add..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Available Users */}
            <div className="max-h-48 overflow-y-auto space-y-2">
              {availableUsers.length === 0 ? (
                <p className="text-center text-gray-500 py-4">
                  {searchQuery ? 'No users found' : 'All users are already members'}
                </p>
              ) : (
                availableUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={user.avatar} alt={user.displayName} />
                        <AvatarFallback>
                          {user.displayName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{user.displayName}</span>
                          {user.role === 'admin' && (
                            <Badge variant="secondary">Admin</Badge>
                          )}
                        </div>
                        <span className="text-sm text-gray-500">@{user.username}</span>
                      </div>
                    </div>
                    
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleAddMember(user.id)}
                      className="flex items-center gap-2"
                    >
                      <UserPlus className="w-4 h-4" />
                      Add
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
import { eq, desc, and, or, like, sql, count } from "drizzle-orm";
import { db } from "./db";
import fs from 'fs';
import path from 'path';
import { 
  users, rooms, messages, roomMembers, privateChats, appSettings, ldapConfig,
  type User, type Room, type Message, type RoomMember, type PrivateChat, type AppSettings, type LdapConfig,
  type InsertUser, type InsertRoom, type InsertMessage, type InsertRoomMember, type InsertPrivateChat, type InsertAppSettings, type InsertLdapConfig
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByDepartment(department: string): Promise<User[]>;
  banUser(id: string): Promise<void>;
  unbanUser(id: string): Promise<void>;
  deactivateUser(id: string): Promise<void>;
  activateUser(id: string): Promise<void>;
  updateUserLastActive(id: string): Promise<void>;

  // Room methods
  createRoom(room: InsertRoom): Promise<Room>;
  getRoom(id: string): Promise<Room | undefined>;
  getAllRooms(): Promise<Room[]>;
  getUserRooms(userId: string): Promise<Room[]>;
  updateRoom(id: string, updates: Partial<InsertRoom>): Promise<Room>;
  deleteRoom(id: string): Promise<void>;
  
  // Room member methods
  addRoomMember(member: InsertRoomMember): Promise<RoomMember>;
  removeRoomMember(roomId: string, userId: string): Promise<void>;
  getRoomMembers(roomId: string): Promise<User[]>;
  isRoomMember(roomId: string, userId: string): Promise<boolean>;

  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getRoomMessages(roomId: string, limit?: number): Promise<Array<Message & { sender: User }>>;
  getPrivateMessages(user1Id: string, user2Id: string, limit?: number): Promise<Array<Message & { sender: User }>>;
  deleteMessage(id: string): Promise<void>;
  getMessagesOlderThan(months: number): Promise<Message[]>;
  deleteMessagesOlderThan(months: number): Promise<number>;
  searchMessages(query: string, userId: string): Promise<Array<Message & { sender: User, room: Room | null }>>;

  // Private chat methods
  getOrCreatePrivateChat(user1Id: string, user2Id: string): Promise<PrivateChat>;
  getUserPrivateChats(userId: string): Promise<Array<PrivateChat & { otherUser: User, lastMessage: Message | null }>>;

  // App settings methods
  getAppSettings(): Promise<AppSettings | undefined>;
  updateAppSettings(settings: Partial<InsertAppSettings>): Promise<AppSettings>;

  // LDAP config methods
  getLdapConfig(): Promise<LdapConfig | undefined>;
  updateLdapConfig(config: Partial<InsertLdapConfig>): Promise<LdapConfig>;

  // Search methods
  globalSearch(query: string, userId: string): Promise<{
    users: User[];
    rooms: Room[];
    messages: Array<Message & { sender: User, room: Room | null }>;
  }>;

  // Statistics
  getSystemStats(): Promise<{
    totalUsers: number;
    activeRooms: number;
    messagesToday: number;
    filesUploaded: number;
  }>;

  // File management methods
  getFileStats(): Promise<{
    totalFiles: number;
    totalSize: number;
    imageFiles: number;
    documentFiles: number;
    otherFiles: number;
    todayFiles: number;
  }>;
  getFilesList(options: {
    search?: string;
    type?: string;
    limit: number;
    offset: number;
  }): Promise<Array<Message & {
    sender: User;
    recipient: User | null;
    room: Room | null;
  }>>;
  deleteFileAndMessage(messageId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isActive, true));
  }

  async getUsersByDepartment(department: string): Promise<User[]> {
    return await db.select().from(users).where(and(eq(users.department, department), eq(users.isActive, true)));
  }

  async banUser(id: string): Promise<void> {
    await db.update(users).set({ isBanned: true }).where(eq(users.id, id));
  }

  async unbanUser(id: string): Promise<void> {
    await db.update(users).set({ isBanned: false }).where(eq(users.id, id));
  }

  async deleteUser(id: string): Promise<void> {
    // Delete user permanently from database with proper cascading
    // 1. Delete all messages where user is sender or recipient
    await db.delete(messages).where(
      or(
        eq(messages.senderId, id),
        eq(messages.recipientId, id)
      )
    );
    
    // 2. Delete all room memberships
    await db.delete(roomMembers).where(eq(roomMembers.userId, id));
    
    // 3. Delete all private chats involving this user
    await db.delete(privateChats).where(
      or(
        eq(privateChats.user1Id, id),
        eq(privateChats.user2Id, id)
      )
    );
    
    // 4. Finally delete the user
    await db.delete(users).where(eq(users.id, id));
  }

  async deactivateUser(id: string): Promise<void> {
    await db.update(users).set({ isActive: false }).where(eq(users.id, id));
  }

  async activateUser(id: string): Promise<void> {
    await db.update(users).set({ isActive: true }).where(eq(users.id, id));
  }

  async updateUserLastActive(id: string): Promise<void> {
    await db.update(users).set({ lastActive: sql`CURRENT_TIMESTAMP` }).where(eq(users.id, id));
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const [room] = await db.insert(rooms).values(insertRoom).returning();
    return room;
  }

  async getRoom(id: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async getAllRooms(): Promise<Room[]> {
    return await db.select().from(rooms);
  }

  async getUserRooms(userId: string): Promise<Room[]> {
    return await db.select({
      id: rooms.id,
      name: rooms.name,
      description: rooms.description,
      icon: rooms.icon,
      isPrivate: rooms.isPrivate,
      createdBy: rooms.createdBy,
      createdAt: rooms.createdAt,
    }).from(rooms)
    .innerJoin(roomMembers, eq(rooms.id, roomMembers.roomId))
    .where(eq(roomMembers.userId, userId));
  }

  async updateRoom(id: string, updates: Partial<InsertRoom>): Promise<Room> {
    const [room] = await db.update(rooms).set(updates).where(eq(rooms.id, id)).returning();
    return room;
  }

  async deleteRoom(id: string): Promise<void> {
    // Delete room with proper cascading
    // 1. Delete all messages in the room
    await db.delete(messages).where(eq(messages.roomId, id));
    
    // 2. Delete all room memberships
    await db.delete(roomMembers).where(eq(roomMembers.roomId, id));
    
    // 3. Finally delete the room
    await db.delete(rooms).where(eq(rooms.id, id));
  }

  async addRoomMember(member: InsertRoomMember): Promise<RoomMember> {
    const [roomMember] = await db.insert(roomMembers).values(member).returning();
    return roomMember;
  }

  async removeRoomMember(roomId: string, userId: string): Promise<void> {
    await db.delete(roomMembers).where(and(eq(roomMembers.roomId, roomId), eq(roomMembers.userId, userId)));
  }

  async getRoomMembers(roomId: string): Promise<User[]> {
    return await db.select({
      id: users.id,
      username: users.username,
      password: users.password,
      displayName: users.displayName,
      email: users.email,
      avatar: users.avatar,
      role: users.role,
      department: users.department,
      isActive: users.isActive,
      isBanned: users.isBanned,
      ldapVerified: users.ldapVerified,
      lastActive: users.lastActive,
      createdAt: users.createdAt,
    }).from(users)
    .innerJoin(roomMembers, eq(users.id, roomMembers.userId))
    .where(eq(roomMembers.roomId, roomId));
  }

  async isRoomMember(roomId: string, userId: string): Promise<boolean> {
    const [member] = await db.select().from(roomMembers)
      .where(and(eq(roomMembers.roomId, roomId), eq(roomMembers.userId, userId)));
    return !!member;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    return message;
  }

  async getRoomMessages(roomId: string, limit: number = 50): Promise<Array<Message & { sender: User }>> {
    return await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: users,
    }).from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .where(and(eq(messages.roomId, roomId), eq(messages.isPrivate, false)))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  }

  async getPrivateMessages(user1Id: string, user2Id: string, limit: number = 50): Promise<Array<Message & { sender: User }>> {
    return await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: users,
    }).from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .where(and(
      eq(messages.isPrivate, true),
      or(
        and(eq(messages.senderId, user1Id), eq(messages.recipientId, user2Id)),
        and(eq(messages.senderId, user2Id), eq(messages.recipientId, user1Id))
      )
    ))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  }

  async deleteMessage(id: string): Promise<void> {
    await db.delete(messages).where(eq(messages.id, id));
  }

  async getMessagesOlderThan(months: number): Promise<Message[]> {
    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - months);
    
    return await db.select().from(messages)
      .where(sql`${messages.createdAt} < ${cutoffDate.toISOString()}`);
  }

  async deleteMessagesOlderThan(months: number): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - months);
    
    const result = await db.delete(messages)
      .where(sql`${messages.createdAt} < ${cutoffDate.toISOString()}`);
    
    return result.changes || 0;
  }

  async searchMessages(query: string, userId: string): Promise<Array<Message & { sender: User, room: Room | null }>> {
    return await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: users,
      room: rooms,
    }).from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .leftJoin(rooms, eq(messages.roomId, rooms.id))
    .where(
      and(
        sql`${messages.content} LIKE '%' || ${query} || '%' COLLATE NOCASE`,
        or(
          eq(messages.isPrivate, false),
          or(eq(messages.senderId, userId), eq(messages.recipientId, userId))
        )
      )
    )
    .orderBy(desc(messages.createdAt))
    .limit(50);
  }

  // Admin message methods
  async getAllMessages(limit: number = 100, offset: number = 0): Promise<Array<Message & { sender: User, recipient: User | null, room: Room | null }>> {
    const results = await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: {
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        department: users.department,
        role: users.role,
        isActive: users.isActive,
        isBanned: users.isBanned,
        email: users.email,
        ldapVerified: users.ldapVerified,
        createdAt: users.createdAt,
        lastActive: users.lastActive,
        avatar: users.avatar,
        password: users.password,
      }
    }).from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .orderBy(desc(messages.createdAt))
    .limit(limit)
    .offset(offset);

    // Fetch recipient and room data separately to avoid complex SQL issues
    const enrichedResults = await Promise.all(
      results.map(async (result) => {
        let recipient: User | null = null;
        let room: Room | null = null;

        if (result.recipientId) {
          recipient = await this.getUser(result.recipientId) || null;
        }

        if (result.roomId) {
          room = await this.getRoom(result.roomId) || null;
        }

        return {
          ...result,
          recipient,
          room
        };
      })
    );

    return enrichedResults;
  }

  async searchAllMessages(query: string, limit: number = 100): Promise<Array<Message & { sender: User, recipient: User | null, room: Room | null }>> {
    const results = await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: {
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        department: users.department,
        role: users.role,
        isActive: users.isActive,
        isBanned: users.isBanned,
        email: users.email,
        ldapVerified: users.ldapVerified,
        createdAt: users.createdAt,
        lastActive: users.lastActive,
        avatar: users.avatar,
        password: users.password,
      }
    }).from(messages)
    .innerJoin(users, eq(messages.senderId, users.id))
    .where(sql`${messages.content} LIKE '%' || ${query} || '%' COLLATE NOCASE`)
    .orderBy(desc(messages.createdAt))
    .limit(limit);

    // Fetch recipient and room data separately to avoid complex SQL issues
    const enrichedResults = await Promise.all(
      results.map(async (result) => {
        let recipient: User | null = null;
        let room: Room | null = null;

        if (result.recipientId) {
          recipient = await this.getUser(result.recipientId) || null;
        }

        if (result.roomId) {
          room = await this.getRoom(result.roomId) || null;
        }

        return {
          ...result,
          recipient,
          room
        };
      })
    );

    return enrichedResults;
  }

  async getMessageStats(): Promise<{
    totalMessages: number;
    roomMessages: number;
    privateMessages: number;
    todayMessages: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(messages);
    const [roomResult] = await db.select({ count: sql<number>`count(*)` }).from(messages).where(eq(messages.isPrivate, false));
    const [privateResult] = await db.select({ count: sql<number>`count(*)` }).from(messages).where(eq(messages.isPrivate, true));
    const [todayResult] = await db.select({ count: sql<number>`count(*)` }).from(messages).where(sql`${messages.createdAt} >= ${today.toISOString()}`);

    return {
      totalMessages: totalResult?.count || 0,
      roomMessages: roomResult?.count || 0,
      privateMessages: privateResult?.count || 0,
      todayMessages: todayResult?.count || 0,
    };
  }

  async getOrCreatePrivateChat(user1Id: string, user2Id: string): Promise<PrivateChat> {
    const [existingChat] = await db.select().from(privateChats)
      .where(
        or(
          and(eq(privateChats.user1Id, user1Id), eq(privateChats.user2Id, user2Id)),
          and(eq(privateChats.user1Id, user2Id), eq(privateChats.user2Id, user1Id))
        )
      );

    if (existingChat) {
      return existingChat;
    }

    const [newChat] = await db.insert(privateChats)
      .values({ user1Id, user2Id })
      .returning();
    
    return newChat;
  }

  async getUserPrivateChats(userId: string): Promise<Array<PrivateChat & { otherUser: User, lastMessage: Message | null }>> {
    const chats = await db.select().from(privateChats)
      .where(or(eq(privateChats.user1Id, userId), eq(privateChats.user2Id, userId)));

    const result = [];
    for (const chat of chats) {
      const otherUserId = chat.user1Id === userId ? chat.user2Id : chat.user1Id;
      const [otherUser] = await db.select().from(users).where(eq(users.id, otherUserId));
      
      const [lastMessage] = await db.select().from(messages)
        .where(
          and(
            eq(messages.isPrivate, true),
            or(
              and(eq(messages.senderId, userId), eq(messages.recipientId, otherUserId)),
              and(eq(messages.senderId, otherUserId), eq(messages.recipientId, userId))
            )
          )
        )
        .orderBy(desc(messages.createdAt))
        .limit(1);

      result.push({
        ...chat,
        otherUser,
        lastMessage: lastMessage || null,
      });
    }

    return result;
  }

  async getAppSettings(): Promise<AppSettings | undefined> {
    const [settings] = await db.select().from(appSettings).limit(1);
    return settings || undefined;
  }

  async updateAppSettings(updates: Partial<InsertAppSettings>): Promise<AppSettings> {
    const existing = await this.getAppSettings();
    
    if (existing) {
      const [updated] = await db.update(appSettings)
        .set({ ...updates, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(appSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(appSettings)
        .values(updates)
        .returning();
      return created;
    }
  }

  async getLdapConfig(): Promise<LdapConfig | undefined> {
    const [config] = await db.select().from(ldapConfig).limit(1);
    return config || undefined;
  }

  async updateLdapConfig(updates: Partial<InsertLdapConfig>): Promise<LdapConfig> {
    const existing = await this.getLdapConfig();
    
    if (existing) {
      const [updated] = await db.update(ldapConfig)
        .set({ ...updates, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(ldapConfig.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(ldapConfig)
        .values(updates)
        .returning();
      return created;
    }
  }

  async globalSearch(query: string, userId: string): Promise<{
    users: User[];
    rooms: Room[];
    messages: Array<Message & { sender: User, room: Room | null }>;
  }> {
    const searchUsers = await db.select().from(users)
      .where(
        and(
          eq(users.isActive, true),
          or(
            sql`${users.displayName} LIKE '%' || ${query} || '%' COLLATE NOCASE`,
            sql`${users.username} LIKE '%' || ${query} || '%' COLLATE NOCASE`,
            sql`${users.email} LIKE '%' || ${query} || '%' COLLATE NOCASE`
          )
        )
      )
      .limit(10);

    const searchRooms = await db.select().from(rooms)
      .where(
        or(
          sql`${rooms.name} LIKE '%' || ${query} || '%' COLLATE NOCASE`,
          sql`${rooms.description} LIKE '%' || ${query} || '%' COLLATE NOCASE`
        )
      )
      .limit(10);

    const searchMessages = await this.searchMessages(query, userId);

    return {
      users: searchUsers,
      rooms: searchRooms,
      messages: searchMessages,
    };
  }

  async getSystemStats(): Promise<{
    totalUsers: number;
    activeRooms: number;
    messagesToday: number;
    filesUploaded: number;
  }> {
    const [totalUsersResult] = await db.select({ count: count() }).from(users).where(eq(users.isActive, true));
    const [activeRoomsResult] = await db.select({ count: count() }).from(rooms);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [messagesTodayResult] = await db.select({ count: count() }).from(messages)
      .where(sql`${messages.createdAt} >= ${today.toISOString()}`);
    
    const [filesUploadedResult] = await db.select({ count: count() }).from(messages)
      .where(eq(messages.messageType, 'file'));

    return {
      totalUsers: totalUsersResult.count,
      activeRooms: activeRoomsResult.count,
      messagesToday: messagesTodayResult.count,
      filesUploaded: filesUploadedResult.count,
    };
  }

  async getFileStats(): Promise<{
    totalFiles: number;
    totalSize: number;
    imageFiles: number;
    documentFiles: number;
    otherFiles: number;
    todayFiles: number;
  }> {
    // Get total files count
    const [totalFilesResult] = await db.select({ count: count() }).from(messages)
      .where(eq(messages.messageType, 'file'));

    // Get total file size
    const [totalSizeResult] = await db.select({ 
      totalSize: sql<number>`COALESCE(SUM(${messages.fileSize}), 0)` 
    }).from(messages)
      .where(eq(messages.messageType, 'file'));

    // Get files uploaded today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [todayFilesResult] = await db.select({ count: count() }).from(messages)
      .where(
        and(
          eq(messages.messageType, 'file'),
          sql`${messages.createdAt} >= ${today.toISOString()}`
        )
      );

    // Get image files count
    const [imageFilesResult] = await db.select({ count: count() }).from(messages)
      .where(
        and(
          eq(messages.messageType, 'file'),
          or(
            like(messages.fileName, '%.jpg'),
            like(messages.fileName, '%.jpeg'),
            like(messages.fileName, '%.png'),
            like(messages.fileName, '%.gif'),
            like(messages.fileName, '%.webp'),
            like(messages.fileName, '%.svg')
          )
        )
      );

    // Get document files count
    const [documentFilesResult] = await db.select({ count: count() }).from(messages)
      .where(
        and(
          eq(messages.messageType, 'file'),
          or(
            like(messages.fileName, '%.pdf'),
            like(messages.fileName, '%.doc'),
            like(messages.fileName, '%.docx'),
            like(messages.fileName, '%.xls'),
            like(messages.fileName, '%.xlsx'),
            like(messages.fileName, '%.txt')
          )
        )
      );

    const totalFiles = totalFilesResult.count;
    const imageFiles = imageFilesResult.count;
    const documentFiles = documentFilesResult.count;
    const otherFiles = totalFiles - imageFiles - documentFiles;

    return {
      totalFiles,
      totalSize: totalSizeResult.totalSize || 0,
      imageFiles,
      documentFiles,
      otherFiles,
      todayFiles: todayFilesResult.count,
    };
  }

  async getFilesList(options: {
    search?: string;
    type?: string;
    limit: number;
    offset: number;
  }): Promise<Array<Message & {
    sender: User;
    recipient: User | null;
    room: Room | null;
  }>> {
    // Build where conditions
    let whereConditions = [eq(messages.messageType, 'file')];

    // Add search condition
    if (options.search) {
      const searchCondition = or(
        sql`${messages.fileName} LIKE '%' || ${options.search} || '%' COLLATE NOCASE`,
        sql`${users.displayName} LIKE '%' || ${options.search} || '%' COLLATE NOCASE`,
        sql`${users.username} LIKE '%' || ${options.search} || '%' COLLATE NOCASE`
      );
      if (searchCondition) {
        whereConditions.push(searchCondition);
      }
    }

    // Add type filter condition
    if (options.type && options.type !== 'all') {
      let typeCondition;
      if (options.type === 'images') {
        typeCondition = or(
          like(messages.fileName, '%.jpg'),
          like(messages.fileName, '%.jpeg'),
          like(messages.fileName, '%.png'),
          like(messages.fileName, '%.gif'),
          like(messages.fileName, '%.webp'),
          like(messages.fileName, '%.svg')
        );
      } else if (options.type === 'documents') {
        typeCondition = or(
          like(messages.fileName, '%.pdf'),
          like(messages.fileName, '%.doc'),
          like(messages.fileName, '%.docx'),
          like(messages.fileName, '%.xls'),
          like(messages.fileName, '%.xlsx'),
          like(messages.fileName, '%.txt')
        );
      } else if (options.type === 'other') {
        typeCondition = sql`NOT (${messages.fileName} LIKE '%.jpg' OR ${messages.fileName} LIKE '%.jpeg' OR ${messages.fileName} LIKE '%.png' OR ${messages.fileName} LIKE '%.gif' OR ${messages.fileName} LIKE '%.webp' OR ${messages.fileName} LIKE '%.svg' OR ${messages.fileName} LIKE '%.pdf' OR ${messages.fileName} LIKE '%.doc' OR ${messages.fileName} LIKE '%.docx' OR ${messages.fileName} LIKE '%.xls' OR ${messages.fileName} LIKE '%.xlsx' OR ${messages.fileName} LIKE '%.txt')`;
      }

      if (typeCondition) {
        whereConditions.push(typeCondition);
      }
    }

    const results = await db.select({
      id: messages.id,
      roomId: messages.roomId,
      senderId: messages.senderId,
      recipientId: messages.recipientId,
      content: messages.content,
      filePath: messages.filePath,
      fileName: messages.fileName,
      fileSize: messages.fileSize,
      messageType: messages.messageType,
      isPrivate: messages.isPrivate,
      createdAt: messages.createdAt,
      sender: {
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        email: users.email,
        avatar: users.avatar,
        role: users.role,
        department: users.department,
        isActive: users.isActive,
        isBanned: users.isBanned,
        ldapVerified: users.ldapVerified,
        lastActive: users.lastActive,
        createdAt: users.createdAt,
        password: users.password
      }
    })
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id))
      .where(and(...whereConditions))
      .orderBy(desc(messages.createdAt))
      .limit(options.limit)
      .offset(options.offset);

    // Get recipient and room data for each message
    const enrichedResults = await Promise.all(
      results.map(async (result) => {
        let recipient: User | null = null;
        let room: Room | null = null;

        if (result.recipientId) {
          recipient = await this.getUser(result.recipientId) || null;
        }

        if (result.roomId) {
          room = await this.getRoom(result.roomId) || null;
        }

        return {
          ...result,
          recipient,
          room
        };
      })
    );

    return enrichedResults;
  }

  async deleteFileAndMessage(messageId: string): Promise<void> {
    // Get the message to find the file path
    const [message] = await db.select().from(messages).where(eq(messages.id, messageId));

    if (!message) {
      throw new Error('Message not found');
    }

    // Delete the physical file if it exists
    if (message.filePath) {
      const fullPath = path.join(process.cwd(), message.filePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
    }

    // Delete the message from the database
    await db.delete(messages).where(eq(messages.id, messageId));
  }
}

export const storage = new DatabaseStorage();

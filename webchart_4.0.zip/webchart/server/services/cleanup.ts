import cron from 'node-cron';
import { storage } from '../storage';
import { deleteOldFiles } from './fileUpload';

export class CleanupService {
  private isRunning = false;

  startScheduledCleanup(): void {
    // Run cleanup every day at 2 AM
    cron.schedule('0 2 * * *', async () => {
      console.log('Starting scheduled cleanup...');
      await this.performAutoCleanup();
    });
  }

  async performAutoCleanup(): Promise<{
    messagesDeleted: number;
    filesDeleted: number;
    spaceFreed: number;
  }> {
    if (this.isRunning) {
      throw new Error('Cleanup is already in progress');
    }

    this.isRunning = true;

    try {
      const RETENTION_MONTHS = 3;

      // Clean up old messages
      const messagesDeleted = await storage.deleteMessagesOlderThan(RETENTION_MONTHS);

      // Clean up old files
      const { deletedCount: filesDeleted, freedSpace } = deleteOldFiles(RETENTION_MONTHS);

      console.log(`Cleanup completed: ${messagesDeleted} messages, ${filesDeleted} files deleted, ${Math.round(freedSpace / 1024 / 1024)}MB freed`);

      return {
        messagesDeleted,
        filesDeleted,
        spaceFreed: freedSpace
      };
    } finally {
      this.isRunning = false;
    }
  }

  async getCleanupPreview(months: number = 3): Promise<{
    oldMessages: number;
    oldFiles: number;
    estimatedSpaceFreed: number;
  }> {
    const oldMessages = await storage.getMessagesOlderThan(months);
    const oldFilesList = await import('./fileUpload').then(m => m.getFilesOlderThan(months));
    
    let estimatedSpaceFreed = 0;
    const fs = await import('fs');
    
    for (const filePath of oldFilesList) {
      try {
        const stats = fs.statSync(filePath);
        estimatedSpaceFreed += stats.size;
      } catch (error) {
        // File might have been deleted, ignore
      }
    }

    return {
      oldMessages: oldMessages.length,
      oldFiles: oldFilesList.length,
      estimatedSpaceFreed
    };
  }

  isCleanupRunning(): boolean {
    return this.isRunning;
  }
}

export const cleanupService = new CleanupService();

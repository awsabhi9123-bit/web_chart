import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { X, BarChart3, Users, MessageSquare, FileText, Trash, Server, Palette } from 'lucide-react';
import UserManagement from './UserManagement';
import RoomManagement from './RoomManagement';
import MessageLogs from './MessageLogs';
import FileManagement from './FileManagement';
import LDAPConfig from './LDAPConfig';
import CleanupConfig from './CleanupConfig';
import BrandingConfig from './BrandingConfig';
import DashboardTab from './DashboardTab';

interface AdminPanelProps {
  onClose: () => void;
}

type AdminTab = 'dashboard' | 'users' | 'rooms' | 'messages' | 'files' | 'cleanup' | 'ldap' | 'branding';

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');

  const tabs = [
    { id: 'dashboard' as AdminTab, label: 'Dashboard', icon: BarChart3 },
    { id: 'users' as AdminTab, label: 'User Management', icon: Users },
    { id: 'rooms' as AdminTab, label: 'Room Monitoring', icon: MessageSquare },
    { id: 'messages' as AdminTab, label: 'Message Logs', icon: MessageSquare },
    { id: 'files' as AdminTab, label: 'File Management', icon: FileText },
    { id: 'cleanup' as AdminTab, label: 'Auto-Cleanup', icon: Trash },
    { id: 'ldap' as AdminTab, label: 'LDAP Config', icon: Server },
    { id: 'branding' as AdminTab, label: 'Branding', icon: Palette },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardTab />;
      case 'users':
        return <UserManagement />;
      case 'rooms':
        return <RoomManagement />;
      case 'messages':
        return <MessageLogs />;
      case 'files':
        return <FileManagement />;
      case 'cleanup':
        return <CleanupConfig />;
      case 'ldap':
        return <LDAPConfig />;
      case 'branding':
        return <BrandingConfig />;
      default:
        return (
          <div className="flex items-center justify-center h-64">
            <p className="text-muted-foreground">This section is under development</p>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" data-testid="admin-panel">
      <Card className="w-full max-w-6xl h-5/6 flex flex-col mx-4">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Admin Panel</h2>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onClose}
              data-testid="button-close-admin"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-64 bg-muted border-r border-border p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <Button
                    key={tab.id}
                    variant={activeTab === tab.id ? 'default' : 'ghost'}
                    className="w-full justify-start"
                    onClick={() => setActiveTab(tab.id)}
                    data-testid={`admin-tab-${tab.id}`}
                  >
                    <Icon className="mr-3 h-4 w-4" />
                    {tab.label}
                  </Button>
                );
              })}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            {renderTabContent()}
          </div>
        </div>
      </Card>
    </div>
  );
}

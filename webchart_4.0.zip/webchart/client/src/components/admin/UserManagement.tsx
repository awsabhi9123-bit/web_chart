import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { User } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Edit, Ban, Trash2, UserPlus, Search, UserX, UserCheck } from 'lucide-react';
import { format } from 'date-fns';

export default function UserManagement() {
  const { token, user: currentUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [userTypeFilter, setUserTypeFilter] = useState('all');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ user: User; action: 'ban' | 'unban' | 'delete' } | null>(null);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<User[]>;
    },
    enabled: !!token
  });

  const banUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/users/${userId}/ban`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to ban user');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User has been banned"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to ban user",
        variant: "destructive"
      });
    }
  });

  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/users/${userId}/unban`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to unban user');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User has been unbanned"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to unban user",
        variant: "destructive"
      });
    }
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete user');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User has been permanently deleted"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Filter users based on search and filters
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesDepartment = departmentFilter === 'all' || user.department === departmentFilter;
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    const matchesUserType = userTypeFilter === 'all' || 
                           (userTypeFilter === 'ldap' && user.ldapVerified) ||
                           (userTypeFilter === 'manual' && !user.ldapVerified);
    
    return matchesSearch && matchesDepartment && matchesRole && matchesUserType;
  });

  // Get unique departments for filter
  const departments = Array.from(new Set(users.map(user => user.department).filter(Boolean))) as string[];

  const formatLastActive = (lastActive?: string) => {
    if (!lastActive) return 'Never';
    const date = new Date(lastActive);
    const now = new Date();
    const diffInMinutes = (now.getTime() - date.getTime()) / (1000 * 60);
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${Math.floor(diffInMinutes)} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return format(date, 'MMM d, yyyy');
  };

  // Handle user editing
  useEffect(() => {
    if (editingUser) {
      toast({
        title: "Edit User",
        description: `Editing ${editingUser.displayName} (${editingUser.ldapVerified ? 'LDAP' : 'Manual'} user)`,
      });
      // Reset editing state for now - full edit dialog can be implemented later
      setEditingUser(null);
    }
  }, [editingUser, toast]);

  const handleBanToggle = (user: User) => {
    // Prevent self-banning
    if (user.id === currentUser?.id) {
      toast({
        title: "Error",
        description: "You cannot ban or unban yourself",
        variant: "destructive"
      });
      return;
    }

    // Show confirmation dialog
    setConfirmAction({
      user,
      action: user.isBanned ? 'unban' : 'ban'
    });
  };

  const handleDeleteUser = (user: User) => {
    // Prevent self-deletion
    if (user.id === currentUser?.id) {
      toast({
        title: "Error",
        description: "You cannot delete your own account",
        variant: "destructive"
      });
      return;
    }

    // Show confirmation dialog for delete
    setConfirmAction({
      user,
      action: 'delete'
    });
  };

  const handleConfirmAction = () => {
    if (!confirmAction) return;

    const { user, action } = confirmAction;
    
    if (action === 'ban') {
      banUserMutation.mutate(user.id);
    } else if (action === 'unban') {
      unbanUserMutation.mutate(user.id);
    } else if (action === 'delete') {
      deleteUserMutation.mutate(user.id);
    }
    
    setConfirmAction(null);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">User Management</h3>
          <div className="animate-pulse h-10 w-24 bg-muted rounded-md"></div>
        </div>
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse h-16 bg-muted rounded-md"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="user-management">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">User Management</h3>
        <Button data-testid="button-add-user">
          <UserPlus className="mr-2 h-4 w-4" />
          Add User
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search-users"
          />
        </div>
        <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All Departments" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(dept => (
              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="All Roles" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Roles</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
            <SelectItem value="user">User</SelectItem>
          </SelectContent>
        </Select>
        <Select value={userTypeFilter} onValueChange={setUserTypeFilter}>
          <SelectTrigger className="w-36">
            <SelectValue placeholder="All Users" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
            <SelectItem value="ldap">LDAP</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Users Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>User Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Active</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.map((user) => (
              <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.avatar} alt={user.displayName} />
                      <AvatarFallback>
                        {user.displayName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.displayName}</p>
                      <p className="text-sm text-muted-foreground">{user.email || user.username}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{user.department || 'N/A'}</TableCell>
                <TableCell>
                  <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                    {user.role}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant={user.ldapVerified ? 'outline' : 'default'}
                    className={user.ldapVerified ? 'text-blue-600 border-blue-200' : 'text-green-600 bg-green-50 border-green-200'}
                  >
                    {user.ldapVerified ? 'LDAP' : 'Manual'}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant={
                      user.isBanned ? 'destructive' :
                      user.isActive ? 'default' : 'secondary'
                    }
                  >
                    {user.isBanned ? 'Banned' : user.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {formatLastActive(user.lastActive)}
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      title="Edit User"
                      onClick={() => setEditingUser(user)}
                      data-testid={`button-edit-${user.id}`}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      title={user.isBanned ? "Unban User" : "Ban User"}
                      onClick={() => handleBanToggle(user)}
                      disabled={banUserMutation.isPending || unbanUserMutation.isPending}
                      data-testid={`button-ban-${user.id}`}
                    >
                      <Ban className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      title="Delete User"
                      onClick={() => handleDeleteUser(user)}
                      disabled={deleteUserMutation.isPending}
                      className="text-destructive hover:text-destructive"
                      data-testid={`button-delete-${user.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No users found matching your criteria</p>
        </div>
      )}

      {/* Confirmation Dialog */}
      <AlertDialog open={!!confirmAction} onOpenChange={() => setConfirmAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction?.action === 'ban' ? 'Ban User' : 
               confirmAction?.action === 'unban' ? 'Unban User' : 'Delete User'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction?.action === 'ban' ? (
                <>
                  Are you sure you want to ban <strong>{confirmAction.user.displayName}</strong>? 
                  This will prevent them from accessing the platform until they are unbanned.
                </>
              ) : confirmAction?.action === 'unban' ? (
                <>
                  Are you sure you want to unban <strong>{confirmAction?.user.displayName}</strong>? 
                  This will restore their access to the platform.
                </>
              ) : (
                <>
                  <div className="text-red-600 font-semibold mb-2">⚠️ WARNING: This action cannot be undone!</div>
                  Are you sure you want to permanently delete <strong>{confirmAction?.user.displayName}</strong>?
                  <br /><br />
                  This will:
                  <ul className="list-disc ml-4 mt-2">
                    <li>Permanently remove their account and all associated data</li>
                    <li>Remove them from all chat rooms and conversations</li>
                    <li>Delete their message history</li>
                  </ul>
                  <br />
                  <strong>This action cannot be reversed.</strong>
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirmAction(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmAction}
              className={
                confirmAction?.action === 'ban' ? 'bg-destructive hover:bg-destructive/90' :
                confirmAction?.action === 'unban' ? 'bg-green-600 hover:bg-green-700' :
                'bg-red-600 hover:bg-red-700'
              }
            >
              {confirmAction?.action === 'ban' ? 'Ban User' : 
               confirmAction?.action === 'unban' ? 'Unban User' : 'Permanently Delete User'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

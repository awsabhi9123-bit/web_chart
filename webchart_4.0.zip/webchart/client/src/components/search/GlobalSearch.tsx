import { useState, useRef, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from 'wouter';
import { SearchResults } from '@/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Search, X, Hash, MessageSquare, User, File } from 'lucide-react';
import { format } from 'date-fns';

export default function GlobalSearch() {
  const { token } = useAuth();
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [results, setResults] = useState<SearchResults | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  const searchMutation = useMutation({
    mutationFn: async (searchQuery: string) => {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Search failed');
      return response.json() as Promise<SearchResults>;
    },
    onSuccess: (data) => {
      setResults(data);
      setIsOpen(true);
    }
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        inputRef.current?.focus();
      }
      if (event.key === 'Escape') {
        setIsOpen(false);
        inputRef.current?.blur();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInputChange = (value: string) => {
    setQuery(value);

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    if (value.trim().length >= 2) {
      debounceRef.current = setTimeout(() => {
        searchMutation.mutate(value.trim());
      }, 300);
    } else {
      setIsOpen(false);
      setResults(null);
    }
  };

  const handleClear = () => {
    setQuery('');
    setIsOpen(false);
    setResults(null);
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }
  };

  const handleUserClick = (userId: string) => {
    setLocation(`/chat/${userId}`);
    setIsOpen(false);
    setQuery('');
  };

  const handleRoomClick = (roomId: string) => {
    setLocation(`/room/${roomId}`);
    setIsOpen(false);
    setQuery('');
  };

  const handleMessageClick = (message: any) => {
    if (message.isPrivate) {
      // Navigate to private chat
      const otherUserId = message.senderId; // Assuming we want to chat with the sender
      setLocation(`/chat/${otherUserId}`);
    } else if (message.roomId) {
      // Navigate to room
      setLocation(`/room/${message.roomId}`);
    }
    setIsOpen(false);
    setQuery('');
  };

  const formatMessageTime = (timestamp: string) => {
    return format(new Date(timestamp), 'MMM d, HH:mm');
  };

  const getRoomIcon = (iconName?: string) => {
    switch (iconName) {
      case 'code':
        return <i className="fas fa-code text-xs"></i>;
      case 'bullhorn':
        return <i className="fas fa-bullhorn text-xs"></i>;
      default:
        return <Hash className="h-3 w-3" />;
    }
  };

  return (
    <div className="relative" ref={searchRef} data-testid="global-search">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          ref={inputRef}
          type="text"
          placeholder="Search users, rooms, messages... (Ctrl+K)"
          value={query}
          onChange={(e) => handleInputChange(e.target.value)}
          className="pl-9 pr-9"
          data-testid="input-global-search"
        />
        {query && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6"
            onClick={handleClear}
            data-testid="button-clear-search"
          >
            <X className="h-3 w-3" />
          </Button>
        )}
      </div>

      {/* Search Results Dropdown */}
      {isOpen && results && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 max-h-96 overflow-hidden">
          <CardContent className="p-0">
            <div className="max-h-96 overflow-y-auto">
              {/* Users Section */}
              {results.users.length > 0 && (
                <div>
                  <div className="px-3 py-2 border-b bg-muted/50">
                    <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                      <User className="h-3 w-3" />
                      USERS
                    </div>
                  </div>
                  {results.users.map((user) => (
                    <div
                      key={user.id}
                      className="px-3 py-2 hover:bg-accent cursor-pointer border-b last:border-b-0"
                      onClick={() => handleUserClick(user.id)}
                      data-testid={`search-user-${user.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={user.avatar} alt={user.displayName} />
                          <AvatarFallback className="text-xs">
                            {user.displayName.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{user.displayName}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            @{user.username}
                            {user.department && ` • ${user.department}`}
                          </p>
                        </div>
                        {user.role === 'admin' && (
                          <Badge variant="secondary" className="text-xs">Admin</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Rooms Section */}
              {results.rooms.length > 0 && (
                <div>
                  <div className="px-3 py-2 border-b bg-muted/50">
                    <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                      <MessageSquare className="h-3 w-3" />
                      ROOMS
                    </div>
                  </div>
                  {results.rooms.map((room) => (
                    <div
                      key={room.id}
                      className="px-3 py-2 hover:bg-accent cursor-pointer border-b last:border-b-0"
                      onClick={() => handleRoomClick(room.id)}
                      data-testid={`search-room-${room.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 bg-secondary rounded flex items-center justify-center text-secondary-foreground">
                          {getRoomIcon(room.icon)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{room.name}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {room.description || 'No description'}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Messages Section */}
              {results.messages.length > 0 && (
                <div>
                  <div className="px-3 py-2 border-b bg-muted/50">
                    <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                      <File className="h-3 w-3" />
                      MESSAGES
                    </div>
                  </div>
                  {results.messages.map((message) => (
                    <div
                      key={message.id}
                      className="px-3 py-2 hover:bg-accent cursor-pointer border-b last:border-b-0"
                      onClick={() => handleMessageClick(message)}
                      data-testid={`search-message-${message.id}`}
                    >
                      <div className="flex items-start gap-3">
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={message.sender?.avatar} alt={message.sender?.displayName} />
                          <AvatarFallback className="text-xs">
                            {message.sender?.displayName.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-sm font-medium truncate">
                              {message.sender?.displayName}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {formatMessageTime(message.createdAt)}
                            </span>
                            {message.room && (
                              <span className="text-xs text-muted-foreground">
                                in #{message.room.name}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {message.content}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* No Results */}
              {results.users.length === 0 && results.rooms.length === 0 && results.messages.length === 0 && (
                <div className="px-3 py-8 text-center text-sm text-muted-foreground">
                  No results found for "{query}"
                </div>
              )}

              {searchMutation.isPending && (
                <div className="px-3 py-8 text-center text-sm text-muted-foreground">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mx-auto mb-2"></div>
                  Searching...
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Room, User, RoomMember } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Users, UserPlus, UserMinus, Crown, Settings } from 'lucide-react';

interface RoomManagementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room: Room | null;
}

export default function RoomManagementDialog({ open, onOpenChange, room }: RoomManagementDialogProps) {
  const { token, user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [newOwner, setNewOwner] = useState<string>('');

  // Fetch all users for adding to room
  const { data: allUsers = [] } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<User[]>;
    },
    enabled: !!token && open
  });

  // Fetch room members (we'll need to add this API endpoint)
  const { data: roomMembers = [] } = useQuery({
    queryKey: ['/api/rooms', room?.id, 'members'],
    queryFn: async () => {
      const response = await fetch(`/api/rooms/${room?.id}/members`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch room members');
      }
      return response.json() as Promise<User[]>;
    },
    enabled: !!token && !!room?.id && open
  });

  // Add member mutation
  const addMemberMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/rooms/${room?.id}/members`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ userId })
      });
      
      if (!response.ok) {
        throw new Error('Failed to add member');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms', room?.id, 'members'] });
      toast({
        title: 'Member Added',
        description: 'User has been added to the room successfully!',
      });
      setSelectedUser('');
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to add member',
        variant: 'destructive',
      });
    }
  });

  // Remove member mutation
  const removeMemberMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await fetch(`/api/rooms/${room?.id}/members/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to remove member');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms', room?.id, 'members'] });
      toast({
        title: 'Member Removed',
        description: 'User has been removed from the room successfully!',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to remove member',
        variant: 'destructive',
      });
    }
  });

  // Transfer ownership mutation
  const transferOwnershipMutation = useMutation({
    mutationFn: async (newOwnerId: string) => {
      const response = await fetch(`/api/rooms/${room?.id}/transfer-ownership`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ newOwnerId })
      });
      
      if (!response.ok) {
        throw new Error('Failed to transfer ownership');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms'] });
      queryClient.invalidateQueries({ queryKey: ['/api/rooms', room?.id, 'members'] });
      toast({
        title: 'Ownership Transferred',
        description: 'Room ownership has been transferred successfully!',
      });
      setNewOwner('');
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to transfer ownership',
        variant: 'destructive',
      });
    }
  });

  const isOwner = room?.createdBy === user?.id;
  const availableUsers = allUsers.filter(u => 
    !roomMembers.some(member => member.id === u.id) && u.id !== user?.id
  );
  const eligibleOwners = roomMembers.filter(member => member.id !== user?.id);

  const handleAddMember = () => {
    if (!selectedUser) return;
    addMemberMutation.mutate(selectedUser);
  };

  const handleRemoveMember = (userId: string) => {
    removeMemberMutation.mutate(userId);
  };

  const handleTransferOwnership = () => {
    if (!newOwner) return;
    transferOwnershipMutation.mutate(newOwner);
  };

  if (!room) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Manage Room: {room.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Room Members */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Users className="h-4 w-4" />
              Room Members ({roomMembers.length})
            </h3>
            
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {roomMembers.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-2 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={member.avatar} alt={member.displayName} />
                      <AvatarFallback>
                        {member.displayName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{member.displayName}</p>
                      <p className="text-sm text-muted-foreground">@{member.username}</p>
                    </div>
                    {member.id === room.createdBy && (
                      <Badge variant="secondary" className="ml-2">
                        <Crown className="h-3 w-3 mr-1" />
                        Owner
                      </Badge>
                    )}
                  </div>
                  
                  {isOwner && member.id !== room.createdBy && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Remove Member</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to remove {member.displayName} from this room?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleRemoveMember(member.id)}>
                            Remove
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Add Members (Only for room owner) */}
          {isOwner && (
            <div>
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <UserPlus className="h-4 w-4" />
                Add Members
              </h3>
              
              <div className="flex gap-2">
                <Select value={selectedUser} onValueChange={setSelectedUser}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select a user to add" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableUsers.map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6">
                            <AvatarImage src={user.avatar} alt={user.displayName} />
                            <AvatarFallback>
                              {user.displayName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span>{user.displayName} (@{user.username})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleAddMember}
                  disabled={!selectedUser || addMemberMutation.isPending}
                >
                  Add
                </Button>
              </div>
            </div>
          )}

          {/* Transfer Ownership (Only for room owner) */}
          {isOwner && eligibleOwners.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Crown className="h-4 w-4" />
                Transfer Ownership
              </h3>
              
              <div className="flex gap-2">
                <Select value={newOwner} onValueChange={setNewOwner}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select new owner" />
                  </SelectTrigger>
                  <SelectContent>
                    {eligibleOwners.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6">
                            <AvatarImage src={member.avatar} alt={member.displayName} />
                            <AvatarFallback>
                              {member.displayName.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span>{member.displayName} (@{member.username})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="outline"
                      disabled={!newOwner || transferOwnershipMutation.isPending}
                    >
                      Transfer
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Transfer Ownership</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to transfer ownership of this room? You will no longer be able to manage this room.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleTransferOwnership}>
                        Transfer Ownership
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          )}

          {!isOwner && (
            <div className="text-center py-4 text-muted-foreground">
              <p>Only the room owner can manage members and permissions.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
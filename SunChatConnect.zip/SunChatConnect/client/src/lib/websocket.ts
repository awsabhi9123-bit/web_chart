// This file serves as a centralized WebSocket utility
// Most WebSocket functionality is handled in useWebSocket hook
// This file provides additional WebSocket utilities if needed

export interface WebSocketConnectionOptions {
  url?: string;
  protocols?: string | string[];
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export class WebSocketConnection {
  private ws: WebSocket | null = null;
  private url: string;
  private protocols?: string | string[];
  private reconnectInterval: number;
  private maxReconnectAttempts: number;
  private reconnectAttempts: number = 0;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private isConnecting: boolean = false;
  private listeners: Map<string, Function[]> = new Map();

  constructor(options: WebSocketConnectionOptions = {}) {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    this.url = options.url || `${protocol}//${window.location.host}/ws`;
    this.protocols = options.protocols;
    this.reconnectInterval = options.reconnectInterval || 3000;
    this.maxReconnectAttempts = options.maxReconnectAttempts || 5;
  }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isConnecting || (this.ws && this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }

      this.isConnecting = true;
      
      try {
        this.ws = new WebSocket(this.url, this.protocols);
        
        this.ws.onopen = () => {
          this.isConnecting = false;
          this.reconnectAttempts = 0;
          this.emit('open');
          resolve();
        };

        this.ws.onclose = (event) => {
          this.isConnecting = false;
          this.emit('close', event);
          this.handleReconnect();
        };

        this.ws.onerror = (error) => {
          this.isConnecting = false;
          this.emit('error', error);
          reject(error);
        };

        this.ws.onmessage = (event) => {
          this.emit('message', event);
        };

      } catch (error) {
        this.isConnecting = false;
        reject(error);
      }
    });
  }

  disconnect(): void {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }

    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    
    this.reconnectAttempts = 0;
  }

  send(data: string | ArrayBufferLike | Blob | ArrayBufferView): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(data);
    }
  }

  on(event: string, callback: Function): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);
  }

  off(event: string, callback: Function): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      const index = listeners.indexOf(callback);
      if (index !== -1) {
        listeners.splice(index, 1);
      }
    }
  }

  private emit(event: string, data?: any): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      listeners.forEach(callback => callback(data));
    }
  }

  private handleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.emit('maxReconnectAttemptsReached');
      return;
    }

    this.reconnectAttempts++;
    this.reconnectTimeout = setTimeout(() => {
      this.connect().catch(() => {
        // Connection failed, will try again
      });
    }, this.reconnectInterval);
  }

  get readyState(): number {
    return this.ws?.readyState || WebSocket.CLOSED;
  }

  get isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

// Utility functions for WebSocket message handling
export const createWebSocketMessage = (type: string, data: any = {}) => {
  return JSON.stringify({ type, ...data });
};

export const parseWebSocketMessage = (message: string) => {
  try {
    return JSON.parse(message);
  } catch (error) {
    console.error('Failed to parse WebSocket message:', error);
    return null;
  }
};

// WebSocket message types
export const WebSocketMessageTypes = {
  AUTH: 'auth',
  JOIN_ROOM: 'join_room',
  LEAVE_ROOM: 'leave_room',
  SEND_MESSAGE: 'send_message',
  SEND_PRIVATE_MESSAGE: 'send_private_message',
  TYPING_START: 'typing_start',
  TYPING_STOP: 'typing_stop',
  NEW_MESSAGE: 'new_message',
  NEW_PRIVATE_MESSAGE: 'new_private_message',
  USER_JOINED: 'user_joined',
  USER_LEFT: 'user_left',
  ERROR: 'error'
} as const;

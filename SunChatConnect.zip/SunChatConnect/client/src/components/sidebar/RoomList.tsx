import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Room, PrivateChat } from '@/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Hash, Code, Megaphone } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RoomListProps {
  onJoinRoom: (roomId: string) => void;
  onStartPrivateChat: (userId: string) => void;
  activeRoom: string | null;
  activePrivateChat: string | null;
}

const getRoomIcon = (iconName?: string) => {
  switch (iconName) {
    case 'code':
      return <Code className="h-4 w-4" />;
    case 'bullhorn':
      return <Megaphone className="h-4 w-4" />;
    default:
      return <Hash className="h-4 w-4" />;
  }
};

export default function RoomList({ 
  onJoinRoom, 
  onStartPrivateChat,
  activeRoom,
  activePrivateChat
}: RoomListProps) {
  const { token } = useAuth();

  const { data: rooms = [], isLoading: roomsLoading } = useQuery({
    queryKey: ['/api/rooms'],
    queryFn: async () => {
      const response = await fetch('/api/rooms', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<Room[]>;
    },
    enabled: !!token
  });

  const { data: privateChats = [], isLoading: chatsLoading } = useQuery({
    queryKey: ['/api/private-chats'],
    queryFn: async () => {
      const response = await fetch('/api/private-chats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      return response.json() as Promise<PrivateChat[]>;
    },
    enabled: !!token
  });

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${diffInMinutes}m`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`;
    return `${Math.floor(diffInMinutes / 1440)}d`;
  };

  if (roomsLoading || chatsLoading) {
    return (
      <div className="px-4 py-2">
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="h-12 bg-muted rounded-md"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4">
      {/* Chat Rooms */}
      <div className="space-y-1 mb-6">
        {rooms.map((room) => (
          <div
            key={room.id}
            className={cn(
              "p-3 hover:bg-accent rounded-md cursor-pointer group transition-colors",
              activeRoom === room.id && "bg-accent"
            )}
            onClick={() => onJoinRoom(room.id)}
            data-testid={`room-item-${room.id}`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground">
                {getRoomIcon(room.icon)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium truncate">{room.name}</h3>
                  <span className="text-xs text-muted-foreground">
                    {formatTime(room.createdAt)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground truncate">
                  {room.description || 'No recent messages'}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Private Messages */}
      {privateChats.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground mb-3 px-3">
            DIRECT MESSAGES
          </h4>
          <div className="space-y-1">
            {privateChats.map((chat) => (
              <div
                key={chat.id}
                className={cn(
                  "p-3 hover:bg-accent rounded-md cursor-pointer group transition-colors",
                  activePrivateChat === chat.otherUser?.id && "bg-accent"
                )}
                onClick={() => chat.otherUser && onStartPrivateChat(chat.otherUser.id)}
                data-testid={`private-chat-${chat.otherUser?.id}`}
              >
                <div className="flex items-center gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={chat.otherUser?.avatar} alt={chat.otherUser?.displayName} />
                    <AvatarFallback>
                      {chat.otherUser?.displayName.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-medium truncate">
                        {chat.otherUser?.displayName}
                      </h3>
                      {chat.lastMessage && (
                        <span className="text-xs text-muted-foreground">
                          {formatTime(chat.lastMessage.createdAt)}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {chat.lastMessage?.content || 'No messages yet'}
                    </p>
                  </div>
                  <div className="w-2 h-2 bg-green-500 rounded-full" title="Online"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

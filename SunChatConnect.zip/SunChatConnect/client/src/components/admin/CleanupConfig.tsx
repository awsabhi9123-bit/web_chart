import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Trash, Eye, Loader2, AlertTriangle } from 'lucide-react';

interface CleanupPreview {
  oldMessages: number;
  oldFiles: number;
  estimatedSpaceFreed: number;
}

export default function CleanupConfig() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [cleanupType, setCleanupType] = useState<'messages' | 'files' | 'both'>('both');

  const { data: preview, isLoading: previewLoading } = useQuery({
    queryKey: ['/api/admin/cleanup/preview'],
    queryFn: async () => {
      const response = await fetch('/api/admin/cleanup/preview?months=3', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch cleanup preview');
      return response.json() as Promise<CleanupPreview>;
    },
    enabled: !!token
  });

  const cleanupMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/admin/cleanup', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Cleanup failed');
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/cleanup/preview'] });
      toast({
        title: "Cleanup Completed",
        description: `Deleted ${data.messagesDeleted} messages and ${data.filesDeleted} files, freed ${Math.round(data.spaceFreed / 1024 / 1024)}MB`
      });
    },
    onError: () => {
      toast({
        title: "Cleanup Failed",
        description: "An error occurred during cleanup",
        variant: "destructive"
      });
    }
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleCleanup = () => {
    cleanupMutation.mutate();
  };

  if (previewLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="cleanup-config">
      <h3 className="text-lg font-semibold">Auto-Cleanup Configuration</h3>

      {/* Current Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Current Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Message Retention</p>
              <p className="font-medium">3 months</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">File Retention</p>
              <p className="font-medium">3 months</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Manual Cleanup */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Manual Cleanup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Delete all messages and files older than the specified retention period.
          </p>

          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium mb-3 block">Cleanup Type</Label>
              <RadioGroup value={cleanupType} onValueChange={(value: 'messages' | 'files' | 'both') => setCleanupType(value)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="messages" id="messages" />
                  <Label htmlFor="messages" className="text-sm">Messages only</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="files" id="files" />
                  <Label htmlFor="files" className="text-sm">Files only</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="both" id="both" />
                  <Label htmlFor="both" className="text-sm">Both messages and files</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="flex gap-4">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="destructive"
                    disabled={cleanupMutation.isPending}
                    data-testid="button-start-cleanup"
                  >
                    {cleanupMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Trash className="mr-2 h-4 w-4" />
                    )}
                    Start Cleanup
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-destructive/10 rounded-full flex items-center justify-center">
                        <AlertTriangle className="h-6 w-6 text-destructive" />
                      </div>
                      <div>
                        <AlertDialogTitle>Confirm Data Cleanup</AlertDialogTitle>
                        <AlertDialogDescription>This action cannot be undone</AlertDialogDescription>
                      </div>
                    </div>
                  </AlertDialogHeader>
                  <div className="py-4">
                    <p className="text-sm text-foreground mb-3">
                      Are you sure you want to delete the following data?
                    </p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {preview && cleanupType !== 'files' && (
                        <li>• {preview.oldMessages.toLocaleString()} messages older than 3 months</li>
                      )}
                      {preview && cleanupType !== 'messages' && (
                        <li>• {preview.oldFiles.toLocaleString()} files ({formatFileSize(preview.estimatedSpaceFreed)}) older than 3 months</li>
                      )}
                    </ul>
                  </div>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleCleanup}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      <Trash className="mr-2 h-4 w-4" />
                      Delete Data
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              <Button 
                variant="outline"
                data-testid="button-preview-cleanup"
              >
                <Eye className="mr-2 h-4 w-4" />
                Preview Items to Delete
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Cleanup Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          {preview ? (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Messages older than 3 months</p>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-destructive">
                    {preview.oldMessages.toLocaleString()} messages
                  </p>
                  {preview.oldMessages > 0 && (
                    <Badge variant="destructive">Ready for cleanup</Badge>
                  )}
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Files older than 3 months</p>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-destructive">
                    {preview.oldFiles.toLocaleString()} files ({formatFileSize(preview.estimatedSpaceFreed)})
                  </p>
                  {preview.oldFiles > 0 && (
                    <Badge variant="destructive">Ready for cleanup</Badge>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="animate-pulse h-4 bg-muted rounded"></div>
              <div className="animate-pulse h-4 bg-muted rounded w-3/4"></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

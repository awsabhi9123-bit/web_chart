import { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { AppSettings } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Upload, RotateCcw, Save, Loader2, Sun } from 'lucide-react';

export default function BrandingConfig() {
  const { token } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    appName: 'Sun Chats',
    primaryColor: '#FFEB3B'
  });

  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/admin/settings'],
    queryFn: async () => {
      const response = await fetch('/api/admin/settings', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) return null;
      return response.json() as Promise<AppSettings>;
    },
    enabled: !!token
  });

  // Update form data when settings load
  useState(() => {
    if (settings) {
      setFormData({
        appName: settings.appName || 'Sun Chats',
        primaryColor: settings.primaryColor || '#FFEB3B'
      });
    }
  });

  const uploadLogoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formDataUpload = new FormData();
      formDataUpload.append('logo', file);

      const response = await fetch('/api/admin/upload/logo', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formDataUpload
      });
      
      if (!response.ok) throw new Error('Logo upload failed');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/settings'] });
      toast({
        title: "Logo Updated",
        description: "Your application logo has been updated successfully"
      });
    },
    onError: () => {
      toast({
        title: "Upload Failed",
        description: "Failed to upload logo. Please try again.",
        variant: "destructive"
      });
    }
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (settingsData: typeof formData) => {
      const response = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settingsData)
      });
      
      if (!response.ok) throw new Error('Failed to save settings');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/settings'] });
      toast({
        title: "Settings Saved",
        description: "Your branding settings have been updated"
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save settings. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      toast({
        title: "Invalid File Type",
        description: "Please select a JPEG, PNG, WebP, or SVG image",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (1MB limit)
    if (file.size > 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Logo file must be less than 1MB",
        variant: "destructive"
      });
      return;
    }

    uploadLogoMutation.mutate(file);
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(formData);
  };

  const handleResetLogo = () => {
    // Implementation would remove custom logo and revert to default
    toast({
      title: "Logo Reset",
      description: "Logo has been reset to default"
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="branding-config">
      <h3 className="text-lg font-semibold">Branding & Customization</h3>

      {/* Logo Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Application Logo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start gap-6">
            <div className="flex-shrink-0 text-center">
              <div className="w-20 h-20 bg-primary rounded-lg flex items-center justify-center mb-2">
                {settings?.logoPath ? (
                  <img 
                    src={settings.logoPath} 
                    alt="App Logo" 
                    className="w-full h-full object-contain rounded-lg"
                  />
                ) : (
                  <Sun className="h-8 w-8 text-primary-foreground" />
                )}
              </div>
              <p className="text-xs text-muted-foreground">Current Logo</p>
            </div>
            
            <div className="flex-1">
              <p className="text-sm text-muted-foreground mb-3">
                Upload a custom logo that will be displayed across all pages. 
                Recommended size: 64x64 pixels. Supported formats: JPEG, PNG, WebP, SVG.
              </p>
              <div className="flex gap-3">
                <Button 
                  onClick={handleUploadClick}
                  disabled={uploadLogoMutation.isPending}
                  data-testid="button-upload-logo"
                >
                  {uploadLogoMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="mr-2 h-4 w-4" />
                  )}
                  Upload New Logo
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleResetLogo}
                  data-testid="button-reset-logo"
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reset to Default
                </Button>
              </div>
              <Input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".jpg,.jpeg,.png,.webp,.svg"
                onChange={handleFileSelect}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Theme Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Theme Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="primary-color">Primary Color</Label>
              <div className="flex items-center gap-3">
                <input
                  id="primary-color"
                  type="color"
                  value={formData.primaryColor}
                  onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                  className="w-12 h-10 border border-input rounded cursor-pointer"
                  data-testid="input-primary-color"
                />
                <div className="flex-1">
                  <Input
                    value={formData.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    placeholder="#FFEB3B"
                    data-testid="input-color-hex"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Light Yellow Theme</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="app-name">Application Name</Label>
              <Input
                id="app-name"
                value={formData.appName}
                onChange={(e) => handleInputChange('appName', e.target.value)}
                placeholder="Sun Chats"
                data-testid="input-app-name"
              />
            </div>
          </div>
          
          <div className="pt-4">
            <Button 
              onClick={handleSaveSettings}
              disabled={saveSettingsMutation.isPending}
              data-testid="button-save-settings"
            >
              {saveSettingsMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Apply Changes
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Preview Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 border rounded-lg bg-card">
            <div className="flex items-center gap-3">
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ backgroundColor: formData.primaryColor }}
              >
                {settings?.logoPath ? (
                  <img 
                    src={settings.logoPath} 
                    alt="Preview Logo" 
                    className="w-full h-full object-contain rounded-full"
                  />
                ) : (
                  <Sun className="h-4 w-4" style={{ color: '#000' }} />
                )}
              </div>
              <h4 className="font-semibold">{formData.appName}</h4>
              <Badge style={{ backgroundColor: formData.primaryColor, color: '#000' }}>
                New Theme
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

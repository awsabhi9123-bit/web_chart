import { useEffect, useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Room, User, Message } from '@/types';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import { Settings, Users, Search } from 'lucide-react';

interface ChatAreaProps {
  roomId?: string;
  userId?: string;
  isPrivateChat: boolean;
  webSocket: any;
}

export default function ChatArea({ roomId, userId, isPrivateChat, webSocket }: ChatAreaProps) {
  const { token } = useAuth();
  const [room, setRoom] = useState<Room | null>(null);
  const [otherUser, setOtherUser] = useState<User | null>(null);

  // Fetch room data for room chats
  const { data: roomData } = useQuery({
    queryKey: ['/api/rooms', roomId],
    queryFn: async () => {
      const response = await fetch(`/api/rooms/${roomId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch room');
      return response.json() as Promise<Room>;
    },
    enabled: !!roomId && !isPrivateChat && !!token
  });

  // Fetch user data for private chats
  const { data: userData } = useQuery({
    queryKey: ['/api/users', userId],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('Failed to fetch users');
      const users = await response.json() as User[];
      return users.find(u => u.id === userId);
    },
    enabled: !!userId && isPrivateChat && !!token
  });

  useEffect(() => {
    if (roomData) {
      setRoom(roomData);
    }
  }, [roomData]);

  useEffect(() => {
    if (userData) {
      setOtherUser(userData);
    }
  }, [userData]);

  const getRoomIcon = (iconName?: string) => {
    switch (iconName) {
      case 'code':
        return <i className="fas fa-code text-xs text-secondary-foreground"></i>;
      case 'bullhorn':
        return <i className="fas fa-bullhorn text-xs text-secondary-foreground"></i>;
      default:
        return <i className="fas fa-hashtag text-xs text-secondary-foreground"></i>;
    }
  };

  const chatTitle = isPrivateChat ? otherUser?.displayName : room?.name;
  const chatSubtitle = isPrivateChat 
    ? `@${otherUser?.username}` 
    : `${room?.description || 'No description'}`;

  if (!chatTitle) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
            <i className="fas fa-spinner fa-spin text-muted-foreground text-xl"></i>
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-background" data-testid="chat-area">
      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isPrivateChat ? (
              <Avatar className="w-8 h-8">
                <AvatarImage src={otherUser?.avatar} alt={otherUser?.displayName} />
                <AvatarFallback>
                  {otherUser?.displayName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            ) : (
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                {getRoomIcon(room?.icon)}
              </div>
            )}
            <div>
              <h1 className="text-lg font-semibold" data-testid="chat-title">
                {chatTitle}
              </h1>
              <p className="text-sm text-muted-foreground" data-testid="chat-subtitle">
                {chatSubtitle}
              </p>
            </div>
          </div>
          
          {!isPrivateChat && (
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" title="Room Settings" data-testid="button-room-settings">
                <Settings className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" title="Room Members" data-testid="button-room-members">
                <Users className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" title="Search in Room" data-testid="button-search-room">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <MessageList 
        roomId={roomId}
        userId={userId}
        isPrivateChat={isPrivateChat}
        webSocket={webSocket}
      />

      {/* Message Input */}
      <MessageInput 
        roomId={roomId}
        userId={userId}
        isPrivateChat={isPrivateChat}
        webSocket={webSocket}
      />
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { Message, TypingUser } from '@/types';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Download, File } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';

interface MessageListProps {
  roomId?: string;
  userId?: string;
  isPrivateChat: boolean;
  webSocket: any;
}

export default function MessageList({ roomId, userId, isPrivateChat, webSocket }: MessageListProps) {
  const { token, user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [localMessages, setLocalMessages] = useState<Message[]>([]);

  // Fetch initial messages
  const { data: initialMessages = [] } = useQuery({
    queryKey: isPrivateChat ? ['/api/private-messages', userId] : ['/api/rooms', roomId, 'messages'],
    queryFn: async () => {
      const url = isPrivateChat 
        ? `/api/private-messages/${userId}?limit=50`
        : `/api/rooms/${roomId}/messages?limit=50`;
      
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json() as Promise<Message[]>;
    },
    enabled: !!(roomId || userId) && !!token
  });

  // Update local messages when WebSocket messages change
  useEffect(() => {
    if (webSocket.messages) {
      setLocalMessages(webSocket.messages);
    }
  }, [webSocket.messages]);

  // Set initial messages
  useEffect(() => {
    if (initialMessages.length > 0 && localMessages.length === 0) {
      setLocalMessages(initialMessages);
    }
  }, [initialMessages, localMessages.length]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [localMessages]);

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return format(date, 'HH:mm');
    } else if (isYesterday(date)) {
      return `Yesterday ${format(date, 'HH:mm')}`;
    } else {
      return format(date, 'MMM d, HH:mm');
    }
  };

  const isOwnMessage = (message: Message) => {
    return message.senderId === user?.id;
  };

  const renderFileMessage = (message: Message) => {
    const isImage = message.fileName && /\.(jpg|jpeg|png|gif|webp)$/i.test(message.fileName);
    
    return (
      <div className="bg-card border border-border rounded-lg p-3 max-w-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            {isImage ? (
              <i className="fas fa-file-image text-primary"></i>
            ) : (
              <File className="h-5 w-5 text-primary" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{message.fileName}</p>
            <p className="text-xs text-muted-foreground">
              {message.fileSize ? `${Math.round(message.fileSize / 1024)} KB` : 'Unknown size'}
            </p>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const renderMessage = (message: Message, index: number) => {
    const isOwn = isOwnMessage(message);
    const showAvatar = !isOwn && (index === 0 || localMessages[index - 1]?.senderId !== message.senderId);
    
    if (message.messageType === 'system') {
      return (
        <div key={message.id} className="text-center my-4">
          <span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
            {message.content}
          </span>
        </div>
      );
    }

    return (
      <div 
        key={message.id} 
        className={`flex gap-3 message-animation mb-4 ${isOwn ? 'justify-end' : ''}`}
        data-testid={`message-${message.id}`}
      >
        {!isOwn && showAvatar && (
          <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
            <AvatarImage src={message.sender?.avatar} alt={message.sender?.displayName} />
            <AvatarFallback>
              {message.sender?.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
        
        {!isOwn && !showAvatar && <div className="w-8" />}
        
        <div className={`flex-1 min-w-0 ${isOwn ? 'max-w-2xl' : ''}`}>
          {showAvatar && (
            <div className={`flex items-center gap-2 mb-1 ${isOwn ? 'justify-end' : ''}`}>
              {!isOwn && (
                <span className="font-medium text-sm">
                  {message.sender?.displayName}
                </span>
              )}
              <span className="text-xs text-muted-foreground">
                {formatMessageTime(message.createdAt)}
              </span>
              {isOwn && (
                <span className="font-medium text-sm">
                  {message.sender?.displayName} (You)
                </span>
              )}
            </div>
          )}
          
          <div className={`${isOwn ? 'flex justify-end' : ''}`}>
            {message.messageType === 'file' ? (
              renderFileMessage(message)
            ) : (
              <div className={`rounded-lg px-4 py-2 text-sm max-w-prose ${
                isOwn 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card text-card-foreground border border-border'
              }`}>
                {message.content}
              </div>
            )}
          </div>
        </div>
        
        {isOwn && (
          <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
            <AvatarImage src={user?.avatar} alt={user?.displayName} />
            <AvatarFallback>
              {user?.displayName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
      </div>
    );
  };

  const renderTypingIndicators = () => {
    if (!webSocket.typingUsers || webSocket.typingUsers.length === 0) return null;
    
    return webSocket.typingUsers.map((typingUser: TypingUser) => (
      <div key={typingUser.userId} className="flex gap-3 typing-indicator mb-4">
        <Avatar className="w-8 h-8 flex-shrink-0 mt-1">
          <AvatarFallback>
            {typingUser.displayName.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">{typingUser.displayName}</span>
            <span className="text-xs text-muted-foreground">is typing...</span>
          </div>
          <div className="typing-indicator">
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
          </div>
        </div>
      </div>
    ));
  };

  return (
    <div 
      className="flex-1 overflow-y-auto px-6 py-4 scroll-smooth"
      data-testid="message-list"
    >
      <div className="space-y-1">
        {localMessages.map((message, index) => renderMessage(message, index))}
        {renderTypingIndicators()}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}

import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketService } from './services/websocket';
import { storage } from "./storage";
import { ldapService } from './services/ldap';
import { cleanupService } from './services/cleanup';
import { upload, uploadAvatar, uploadLogo, getFileUrl } from './services/fileUpload';
import { insertUserSchema, insertRoomSchema, insertMessageSchema, insertLdapConfigSchema, insertAppSettingsSchema } from '@shared/schema';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';

const JWT_SECRET = process.env.SESSION_SECRET || 'your-secret-key';

// Middleware to verify JWT token
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    
    if (!user || !user.isActive || user.isBanned) {
      return res.status(403).json({ message: 'User account is inactive or banned' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
};

// Admin middleware
const requireAdmin = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wsService = new WebSocketService(httpServer);

  // Initialize cleanup service
  cleanupService.startScheduledCleanup();

  // Initialize demo users
  await initializeDemoUsers();

  // Authentication routes
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password, useLDAP } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }

      let user;
      let authSuccess = false;

      if (useLDAP) {
        // Try LDAP authentication
        const ldapResult = await ldapService.authenticateUser(username, password);
        
        if (ldapResult.success && ldapResult.user) {
          await ldapService.syncUser(ldapResult.user);
          user = await storage.getUserByUsername(username);
          authSuccess = true;
        }
      } else {
        // Local authentication
        user = await storage.getUserByUsername(username);
        
        if (user && await bcrypt.compare(password, user.password)) {
          authSuccess = true;
        }
      }

      if (!authSuccess || !user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      if (!user.isActive || user.isBanned) {
        return res.status(403).json({ message: 'Account is inactive or banned' });
      }

      // Update last active
      await storage.updateUserLastActive(user.id);

      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          email: user.email,
          avatar: user.avatar,
          role: user.role,
          department: user.department
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // User routes
  app.get('/api/users/me', authenticateToken, async (req: any, res) => {
    res.json(req.user);
  });

  app.get('/api/users', authenticateToken, async (req: any, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users.map(u => ({
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        email: u.email,
        avatar: u.avatar,
        role: u.role,
        department: u.department,
        isActive: u.isActive,
        lastActive: u.lastActive
      })));
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  app.put('/api/users/:id', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }
      
      const user = await storage.updateUser(id, updates);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  app.post('/api/users/:id/ban', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      await storage.banUser(req.params.id);
      res.json({ message: 'User banned successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to ban user' });
    }
  });

  app.post('/api/users/:id/unban', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      await storage.unbanUser(req.params.id);
      res.json({ message: 'User unbanned successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to unban user' });
    }
  });

  // Room routes
  app.get('/api/rooms', authenticateToken, async (req: any, res) => {
    try {
      const rooms = await storage.getUserRooms(req.user.id);
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch rooms' });
    }
  });

  app.post('/api/rooms', authenticateToken, async (req: any, res) => {
    try {
      const roomData = insertRoomSchema.parse({ ...req.body, createdBy: req.user.id });
      const room = await storage.createRoom(roomData);
      
      // Add creator as member
      await storage.addRoomMember({ roomId: room.id, userId: req.user.id });
      
      res.json(room);
    } catch (error) {
      res.status(400).json({ message: 'Invalid room data' });
    }
  });

  app.post('/api/rooms/:id/join', authenticateToken, async (req: any, res) => {
    try {
      await storage.addRoomMember({ roomId: req.params.id, userId: req.user.id });
      res.json({ message: 'Joined room successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to join room' });
    }
  });

  app.post('/api/rooms/:id/leave', authenticateToken, async (req: any, res) => {
    try {
      await storage.removeRoomMember(req.params.id, req.user.id);
      res.json({ message: 'Left room successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to leave room' });
    }
  });

  app.get('/api/rooms/:id/messages', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const isMember = await storage.isRoomMember(id, req.user.id);
      if (!isMember) {
        return res.status(403).json({ message: 'Not a member of this room' });
      }
      
      const messages = await storage.getRoomMessages(id, limit);
      res.json(messages.reverse());
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  // Private message routes
  app.get('/api/private-chats', authenticateToken, async (req: any, res) => {
    try {
      const chats = await storage.getUserPrivateChats(req.user.id);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch private chats' });
    }
  });

  app.get('/api/private-messages/:userId', authenticateToken, async (req: any, res) => {
    try {
      const { userId } = req.params;
      const limit = parseInt(req.query.limit as string) || 50;
      
      const messages = await storage.getPrivateMessages(req.user.id, userId, limit);
      res.json(messages.reverse());
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch private messages' });
    }
  });

  // File upload routes
  app.post('/api/upload', authenticateToken, upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      res.json({
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        url: getFileUrl(req.file.path)
      });
    } catch (error) {
      res.status(500).json({ message: 'File upload failed' });
    }
  });

  app.post('/api/upload/avatar', authenticateToken, uploadAvatar.single('avatar'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No avatar uploaded' });
      }

      const avatarUrl = getFileUrl(req.file.path);
      await storage.updateUser(req.user.id, { avatar: avatarUrl });

      res.json({ avatar: avatarUrl });
    } catch (error) {
      res.status(500).json({ message: 'Avatar upload failed' });
    }
  });

  // Search routes
  app.get('/api/search', authenticateToken, async (req: any, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ message: 'Search query required' });
      }

      const results = await storage.globalSearch(q, req.user.id);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: 'Search failed' });
    }
  });

  // Admin routes
  app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const stats = await storage.getSystemStats();
      res.json({
        ...stats,
        connectedUsers: wsService.getConnectedUsers()
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch statistics' });
    }
  });

  app.get('/api/admin/cleanup/preview', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const months = parseInt(req.query.months as string) || 3;
      const preview = await cleanupService.getCleanupPreview(months);
      res.json(preview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get cleanup preview' });
    }
  });

  app.post('/api/admin/cleanup', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      if (cleanupService.isCleanupRunning()) {
        return res.status(409).json({ message: 'Cleanup is already in progress' });
      }

      const result = await cleanupService.performAutoCleanup();
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: 'Cleanup failed' });
    }
  });

  // LDAP configuration routes
  app.get('/api/admin/ldap', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const config = await storage.getLdapConfig();
      if (config) {
        // Don't send password in response
        const { bindPassword, ...safeConfig } = config;
        res.json(safeConfig);
      } else {
        res.json(null);
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch LDAP config' });
    }
  });

  app.post('/api/admin/ldap', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const configData = insertLdapConfigSchema.parse(req.body);
      const config = await storage.updateLdapConfig(configData);
      
      // Don't send password in response
      const { bindPassword, ...safeConfig } = config;
      res.json(safeConfig);
    } catch (error) {
      res.status(400).json({ message: 'Invalid LDAP configuration' });
    }
  });

  app.post('/api/admin/ldap/test', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const result = await ldapService.testConnection(req.body);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: 'LDAP test failed' });
    }
  });

  // App settings routes
  app.get('/api/admin/settings', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch app settings' });
    }
  });

  app.post('/api/admin/settings', authenticateToken, requireAdmin, async (req: any, res) => {
    try {
      const settingsData = insertAppSettingsSchema.parse(req.body);
      const settings = await storage.updateAppSettings(settingsData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: 'Invalid app settings' });
    }
  });

  app.post('/api/admin/upload/logo', authenticateToken, requireAdmin, uploadLogo.single('logo'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No logo uploaded' });
      }

      const logoUrl = getFileUrl(req.file.path);
      await storage.updateAppSettings({ logoPath: logoUrl });

      res.json({ logoPath: logoUrl });
    } catch (error) {
      res.status(500).json({ message: 'Logo upload failed' });
    }
  });

  // File serving route
  app.get('/api/files/*', (req, res) => {
    const filePath = path.join(process.cwd(), 'uploads', req.params[0]);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    res.sendFile(filePath);
  });

  return httpServer;
}

// Initialize demo users
async function initializeDemoUsers() {
  try {
    // Check if admin user exists
    const adminUser = await storage.getUserByUsername('admin');
    
    if (!adminUser) {
      // Create admin user
      const hashedPassword = await bcrypt.hash('admin@!0', 10);
      await storage.createUser({
        username: 'admin',
        password: hashedPassword,
        displayName: 'Administrator',
        email: 'admin@sunchats.local',
        role: 'admin',
        department: 'IT'
      });
      console.log('Admin user created');
    }

    // Create demo users
    const demoUsers = [
      { username: 'user1', password: 'password', displayName: 'John Doe', email: 'john@company.com', department: 'Engineering' },
      { username: 'user2', password: 'password', displayName: 'Sarah Wilson', email: 'sarah@company.com', department: 'Engineering' },
      { username: 'user3', password: 'password', displayName: 'Mike Chen', email: 'mike@company.com', department: 'Engineering' },
      { username: 'user4', password: 'password', displayName: 'Emily Davis', email: 'emily@company.com', department: 'Marketing' }
    ];

    for (const demoUser of demoUsers) {
      const existingUser = await storage.getUserByUsername(demoUser.username);
      if (!existingUser) {
        const hashedPassword = await bcrypt.hash(demoUser.password, 10);
        await storage.createUser({
          username: demoUser.username,
          password: hashedPassword,
          displayName: demoUser.displayName,
          email: demoUser.email,
          role: 'user',
          department: demoUser.department
        });
      }
    }

    // Create default rooms
    const generalRoom = await storage.createRoom({
      name: 'General',
      description: 'General discussions',
      icon: 'hashtag',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    const devRoom = await storage.createRoom({
      name: 'Development',
      description: 'Engineering team discussions',
      icon: 'code',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    const announcementsRoom = await storage.createRoom({
      name: 'Announcements',
      description: 'Company announcements',
      icon: 'bullhorn',
      createdBy: (await storage.getUserByUsername('admin'))!.id
    });

    console.log('Demo data initialized');
  } catch (error) {
    console.error('Failed to initialize demo data:', error);
  }
}
